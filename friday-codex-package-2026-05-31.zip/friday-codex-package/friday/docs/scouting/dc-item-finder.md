# Dropship Calendar Item Finder Scouting Report

Date: 2026-05-27

Status: initial scouting complete through the Item Finder shops list. No store product page has been scanned yet.

Credentials note: login credentials were provided by the user for this scouting pass and are intentionally omitted from this report.

## Login Page

Entry URL:

- `https://autopilot.dropshipcalendar.io`

Observed behavior:

- Redirects to `/login`.
- Browser title is `Dropship Calendar`.
- Login UI contains:
  - `Email` textbox
  - `Password` textbox
  - `Log In` button
  - `Discord Log In` button
  - `Reset password` link at `/reset-password`

Automation handles:

- Email field: label `Email`
- Password field: label `Password`
- Submit: button named `Log In`

## Dashboard Shell

After login:

- Landing URL: `/dashboard/home`
- Browser title: `Dropship Calendar`

Persistent left navigation:

- `Dashboard`: `/dashboard/home`
- `Item Finder`: `/dashboard/item-finder`
- `Import List`: `/dashboard/import-list`
- `My Products`: `/dashboard/my-products`
- `My Orders`: `/dashboard/my-orders`
- `Help Center`: `https://dropshipcalendar.zendesk.com/`
- `Billing`: `/dashboard/billing`
- `Settings`: `/dashboard/settings`

Observed dashboard content:

- Welcome message
- Reports overview
- Revenue/profit chart controls
- Posted products, total sold, recent orders, and top sellers

Relevant workflow note:

- The dashboard itself is not required for the Friday flow except as confirmation that login succeeded and the left navigation is loaded.

## Item Finder Shops Page

Route:

- `/dashboard/item-finder`

Header:

- Label: `Item Finder`
- Heading: `Discover winning products to sell.`
- Supporting text: tracks total shops, total products found, and shops updated in the last 24 hours.

Stats observed:

- Total Shops: `43`
- Total products: `53,826`
- Shops Updated Last 24h: `0`

Top-level controls:

- Select all shops checkbox
- `Bulk actions` button
- `Search shops` textbox
- `Sort shops` button
- `Add shops` button

Automation handles:

- Item Finder nav: `a[href="/dashboard/item-finder"]`
- Select all checkbox: `#isallchecked-select-all-shops`
- Search shops: input with `aria-label="Search shops"`
- Bulk actions: button with `aria-label="Bulk actions"`
- Sort shops: button with `aria-label="Sort shops"`
- Add Shops button: visible text `Add shops`

## Shop Cards

The shop list is card-based. Shop rows are rendered as `article` elements after the three stat cards.

Each shop card contains:

- Invisible/open-area product link with accessible label `Open products for {shop}`
- Shop checkbox
- Shop display name
- `View Shop` label
- `Open eBay shop` external link
- Added At date
- Last Update date
- Available matches count
- Member/import-count pill such as `Only you`, `1 other member`, etc.
- Progress state, usually `Ready`
- Scanned count, for example `394 / 394 scanned`
- `More actions` button

Shop product-page link pattern:

- `/dashboard/item-finder/shops/{shopId}`

Shop checkbox pattern:

- `#selectedproducts-{shopId}`

eBay shop link pattern:

- `https://www.ebay.com/sch/{seller}/m.html?_nkw=&_armrs=1&_ipg=240&_from=`

Example page 1 shops observed:

- `Dd`: `/dashboard/item-finder/shops/180`, 282 available matches, 384 / 384 scanned
- `barfire`: `/dashboard/item-finder/shops/4027`, 322 available matches, 394 / 394 scanned, Only you
- `larrsap_1`: `/dashboard/item-finder/shops/4026`, 342 available matches, 537 / 537 scanned, Only you
- `sr_logistics_solutions`: `/dashboard/item-finder/shops/208`, 678 available matches, 1,021 / 1,021 scanned
- `muzi_premium_mart`: `/dashboard/item-finder/shops/4024`, 470 available matches, 670 / 670 scanned
- `ke_293497`: `/dashboard/item-finder/shops/4025`, 624 available matches, 709 / 709 scanned

## Pagination

Pagination is explicit, not infinite scroll.

Observed controls:

- Previous page: `<`
- Page 1
- Page 2
- Page 3
- Next page: `>`
- Items on page switch: `20`

Observed counts:

- Page 1: 20 shops
- Page 2: 20 shops
- Page 3: 3 shops

Useful handles from visible DOM:

- Page buttons appear as links with `role="button"` and labels like:
  - `Page 1`
  - `Page 2`
  - `Page 3`
  - `Page 2 is your current page`
  - `Next page`
  - `Previous page`

Implementation note:

- The scrollable area is the app content panel, not the window. Browser automation may need coordinate or DOM-CUA scrolling to reach pagination controls.

## Search Behavior

Search textbox:

- Input with `aria-label="Search shops"`
- Placeholder: `Search shops...`

Observed behavior:

- Searching `barfire` filtered the list to only the `barfire` shop after a short delay.
- Clearing the input with a simple programmatic fill did not reliably update the app state.
- Clearing worked with keyboard behavior: focus search input, select all, press backspace.

Automation recommendation:

- Use real typing/keyboard events for search and clear operations.
- After search or clear, wait for the shop link count or first visible shop to change.

## Sort Menu

Sort control:

- Button with `aria-label="Sort shops"`
- Class observed: `sort-trigger`

Menu:

- Role: `menu`
- Class observed: `action-menu-panel sort-panel`

Options:

- `Recently updated`
- `Recently added`

Read-only note:

- Opening the menu is safe.
- Selecting an option changes list ordering and is acceptable during scouting, but should be recorded as state-changing UI behavior.

## Bulk Actions Menu

Bulk action control:

- Button with `aria-label="Bulk actions"`
- Class observed: `bulk-action-trigger`

Menu:

- Role: `menu`
- Class observed: `action-menu-panel bulk-action-panel`

Option observed:

- `Bulk remove`

Automation warning:

- Do not click `Bulk remove` without explicit user approval.

## Per-Shop More Actions Menu

Control:

- Button with `aria-label="More actions"`
- Class observed: `action-menu-trigger`

Menu:

- Role: `menu`
- Class observed: `action-menu-panel`

Options:

- `Refresh`
- `Delete`

Automation warning:

- Do not click `Refresh` or `Delete` without explicit user approval.
- `Refresh` may trigger server work or update shop data.
- `Delete` is destructive.

## Add Shops Modal

Open control:

- `Add shops` button

Modal content:

- Title: `Add Shops`
- Subtitle: `Paste one or more seller IDs, one per line.`
- Section: `Seller IDs`
- Note: `One line works for a single shop. You can add up to 10 shops at a time.`

Textarea:

- ID: `#ifv2-sellers-string`
- Name: `sellersString`
- Placeholder examples:
  - `gearhousedeals`
  - `modernmercantileco`
  - `urbanutilitysupply`
  - `freshfindsseller`

Buttons:

- Close button with `aria-label="Close add shop modal"`
- Submit button text: `Add shops`

Automation warning:

- Opening and closing the modal is safe.
- Do not type seller IDs or submit from automation unless the user explicitly approves that workflow.

## Browser Tooling Notes

OpenClaw CLI browser status showed a configuration issue:

- Configured executable path: `/Applications/Google Chrome 2.app/Contents/MacOS/Google Chrome`
- That app path was missing on this machine.
- Available browser apps observed: `Google Chrome.app`, `Brave Browser.app`

This scouting pass used the Codex in-app browser tooling instead of changing OpenClaw configuration.

Before implementing a true OpenClaw skill/run, choose one of these:

- Fix OpenClaw browser executable path to the installed `Google Chrome.app`
- Create/configure a dedicated OpenClaw browser profile such as `dc-hunter`
- Continue using the in-app browser for manual scouting only

## Store Scan Prep

Initial store product-page scouting has now been completed for `barfire`. The original candidate list remains below for choosing future stores to compare against.

Recommended first stores for product-page scouting:

- `barfire`: 322 matches, Only you, 394 / 394 scanned
- `larrsap_1`: 342 matches, Only you, 537 / 537 scanned
- `muzi_premium_mart`: 470 matches, 1 other member, 670 / 670 scanned
- `ke_293497`: 624 matches, 1 other member, 709 / 709 scanned
- `sr_logistics_solutions`: 678 matches, 2 other members, 1,021 / 1,021 scanned

Suggested first choice:

- `barfire`, because it is fully scanned, has a manageable number of matches, and is marked `Only you`.

Completed first scouting target:

- Open `/dashboard/item-finder/shops/4027`
- Map product list layout
- Identify product row/card fields
- Identify filters/sorts/search controls
- Find safe seed-product extraction criteria
- Do not add/import/delete/refresh anything

## Store Product Page Scouting: `barfire`

Route:

- `/dashboard/item-finder/shops/4027`

External shop link:

- Visible text: `Visit eBay store`
- URL: `https://www.ebay.com/sch/barfire/m.html?_nkw=&_armrs=1&_ipg=240&_from=`
- Opens in a new tab if clicked.

Store header:

- Label: `Store Overview`
- Heading: `barfire`
- Scan status: `Last completed scan: 2 days ago`

Observed store stats:

- Total Products: `322`
- Avg Profit: `-$1.91`
- Sold Last 30 Days: `119`
- Sell-Through (30 Days): `1.3%`

Top-level product controls:

- Select all products checkbox
- `Bulk actions` button
- `Search products` textbox
- `Product filters` button
- `Sort products` button
- `Automator` button
- `Customize Automator` icon button
- `0 ready` status near Automator

Automation handles:

- Select all products checkbox: `#isallchecked-select-all-products`
- Search products: input with `aria-label="Search products"` and placeholder `Search products...`
- Bulk actions: button with `aria-label="Bulk actions"`
- Product filters: button with `aria-label="Product filters"`
- Sort products: button with `aria-label="Sort products"`
- Automator main button: class `automator-main-button`
- Customize Automator: button with `aria-label="Customize Automator"`

Automation warnings:

- Do not click `Automator` or `Customize Automator` until its behavior is explicitly approved.
- Do not click `Add to Import List`.
- Do not click `Add selected to import list`.
- Do not click marketplace search menu links during seed scouting unless the next phase explicitly calls for opening eBay/Amazon.

## Store Product Page Virtualization

The `barfire` product page uses a virtualized or windowed product list.

Observed behavior:

- Total products is `322`.
- At the top, the DOM rendered only the visible/buffered product cards, not all 322.
- Initial rendered product cards included product IDs:
  - `163825`
  - `169489`
  - `164787`
  - `168417`
  - `163875`
  - `166671`
- After scrolling, the rendered/buffered set changed and included product IDs:
  - `163881`
  - `163835`
  - `169125`
  - `168665`
  - `168439`
  - `167337`
- The app content panel is the scroll container, not the browser window.
- Scroll container class observed: `Page_page__A7lqB SearchProductsPage_ifv2PageBackground__39kyp dark`

Extraction implication:

- Do not attempt a one-shot DOM scrape.
- Use controlled scrolling.
- Dedupe products by `selectedProducts` checkbox value.
- Stop only when scroll position no longer advances or no new product IDs appear after multiple scroll attempts.

## Product Card Structure

Product cards are rendered as `article.product-card`.

Common card classes:

- `product-card`
- `product-card-mirrored`
- `has-corner-status`
- `has-product-status-badges` when status badges are present

Stable product ID:

- Product checkbox pattern: `#selectedproducts-{productId}`
- Checkbox name: `selectedProducts`
- Example: `#selectedproducts-163825`

Each product card contains:

- Updated timestamp, for example `Updated: 2 days ago`
- Optional status badges, for example `Sold 30d`, `Not listed`
- Product checkbox
- Product Titles section
- eBay title link
- Copy eBay title button
- Amazon/supplier title link
- Copy Amazon title button
- eBay image link
- Amazon image link
- eBay Price
- Retail Price
- Profit
- Members Listed
- Sales Rank
- Root category and subcategory tooltip
- Lifetime Sales
- `Add to Import List` button
- `Search` dropdown button

Automation handles inside a product card:

- Product card: `article.product-card`
- Product ID: `input[name="selectedProducts"]`
- eBay title link: `.product-store-title.is-ebay`
- Amazon/supplier title link: `.product-store-title.is-supplier`
- eBay image link: `.product-shot.ebay`
- Amazon image link: `.product-shot.amazon`
- Copy eBay title button: `button[aria-label="Copy eBay title"]`
- Copy Amazon title button: `button[aria-label="Copy Amazon title"]`
- Add button: `.product-import-button`
- Search dropdown button: `.product-search-trigger`

## Product Card Sample: Top Product

Product ID:

- `163825`

Status:

- `Sold 30d`

eBay title:

- `Replacement Hose Handle for Shark Vacuums for ONLY Models ZU62 ZU62C ZU60 ZU102`

Amazon/supplier title:

- `Replacement Hose Handle for Shark Vacuums for ONLY Models ZU62 ZU62C ZU60 ZU102 - Hose Handle for Navigator - Shark Rotator Professional Lift-Away Accessories - Upright Bagless Vacuum Cleaners`

Links:

- eBay item: `https://www.ebay.com/itm/326769007434...`
- Amazon item: `https://www.amazon.com/dp/B0CBZTMMB1?tag=dcaft-20`

Images:

- eBay image host: `https://i.ebayimg.com/...`
- Amazon image host: `https://m.media-amazon.com/...`

Values:

- eBay Price: `$71.02`
- Retail Price: `$49.99`
- Profit: `$4.98`
- Members Listed: `0`
- Sales Rank:
  - `1. 14,854`
  - `2. 856`
  - `3. 88`
- Root category: `#14,854 Industrial & Scientific`
- Sub category: `#856 Vacuum Parts & Accessories`
- Sub category: `#88 Commercial Vacuum Accessories`
- Lifetime Sales: `35`

## Other Initial Visible Products

Examples from the initial visible/buffered product set:

- `169489`: Gas Burner for Ooni Pizza Oven Accessories, lifetime sales `11`, profit `-$50.23`, status `Sold 30d`
- `164787`: Electrolysis Machine for Permanent Hair Removal, lifetime sales `9`, profit `$4.35`, status `Not listed`
- `168417`: 13-Watt CFL Light Bulbs Yellow T2 CFL Color Spiral Bug Light, lifetime sales `8`, profit `-$14.86`, status `Sold 30d`
- `163875`: 16.4FT Peel and Stick Molding & Wall Trim, lifetime sales `6`, profit `$2.23`, members listed `4`
- `166671`: Waterproof Outdoor Chair Cushions 24X24, lifetime sales `5`

## Product Filters

Filter button:

- `aria-label="Product filters"`
- Class observed: `filter-trigger`

Filter menu:

- Role: `menu`
- Class observed: `action-menu-panel filter-panel`

Filter options:

- `Price filters`
- `Show unmatched products`

Price filters modal:

- Close button: `aria-label="Close price filter modal"`
- Title: `Price Filters`
- Subtitle: `Set the retail price range for matched products.`
- Section: `Retail Price`
- Note: `Leave a field empty to keep that side open.`
- Min price input: `#ifv2-price-from`, name `priceFrom`, placeholder `0`
- Max price input: `#ifv2-price-to`, name `priceTo`, placeholder `0`
- Submit button: `Apply filters`

Automation warning:

- Opening and closing Price Filters is safe.
- Do not apply filters during extraction unless the run explicitly wants a filtered product set.
- `Show unmatched products` changes the visible product set and should be treated as state-changing.

## Product Sort Menu

Sort button:

- `aria-label="Sort products"`
- Class observed: `sort-trigger`
- Default text observed: `Sort: Sales ↓`

Sort menu:

- Role: `menu`
- Class observed: `action-menu-panel sort-panel product-sort-panel`

Options:

- `Profit: Ascending`
- `Profit: Descending`
- `Retail Price: Ascending`
- `Retail Price: Descending`
- `Lifetime sales: Ascending`
- `Lifetime sales: Descending`

Observed active sort:

- `Lifetime sales: Descending`

UI note:

- The trigger displays `Sales ↓`, while the active menu option is `Lifetime sales: Descending`.

## Product Bulk Actions

Bulk action button:

- `aria-label="Bulk actions"`
- Class observed: `bulk-action-trigger`

Menu:

- Role: `menu`
- Class observed: `action-menu-panel bulk-action-panel`

Option:

- `Add selected to import list`

Automation warning:

- Do not click this during scouting.
- Future automation should only use this after explicit user approval and after the local app has marked products for import.

## Product Search Dropdown

Each product card has a `Search` button:

- Button `aria-label="Search title on marketplaces"`
- Class observed: `product-search-trigger`

Opened menu:

- Class observed: `action-menu-panel product-title-search-panel`
- Role: `menu`

Menu sections:

- `SEARCH ON EBAY`
  - `Use eBay title`
  - `Use Amazon title`
- `SEARCH ON AMAZON`
  - `Use eBay title`
  - `Use Amazon title`

Observed generated links for the top product:

- eBay search using eBay title:
  - `https://www.ebay.com/sch/i.html?_nkw=Replacement%20Hose%20Handle%20for%20Shark%20Vacuums%20for%20ONLY%20Models%20ZU62%20ZU62C%20ZU60%20ZU102`
- eBay search using Amazon title:
  - `https://www.ebay.com/sch/i.html?_nkw=Replacement%20Hose%20Handle%20for%20Shark%20Vacuums%20for%20ONLY%20Models%20ZU62%20ZU62C%20ZU60%20ZU102%20-%20Hose%20Handle%20for%20Navigator%20-%20Shark%20Rotator%20Professional%20Lift-Away%20Accessories%20-%20Upright%20Bagless%20Vacuum%20Cleaners`
- Amazon search using eBay title:
  - `https://www.amazon.com/s?k=Replacement%20Hose%20Handle%20for%20Shark%20Vacuums%20for%20ONLY%20Models%20ZU62%20ZU62C%20ZU60%20ZU102`
- Amazon search using Amazon title:
  - `https://www.amazon.com/s?k=Replacement%20Hose%20Handle%20for%20Shark%20Vacuums%20for%20ONLY%20Models%20ZU62%20ZU62C%20ZU60%20ZU102%20-%20Hose%20Handle%20for%20Navigator%20-%20Shark%20Rotator%20Professional%20Lift-Away%20Accessories%20-%20Upright%20Bagless%20Vacuum%20Cleaners`

Automation recommendation:

- For finding other eBay dropship sellers, use the `SEARCH ON EBAY` links only.
- Start with `Use Amazon title` as the primary discovery query.
- Use `Use eBay title` only when the Amazon title is missing, broken, or clearly unrelated before any Amazon-title eBay search is opened.
- If the Amazon-title eBay search returns zero real listing cards, do not fall back to the eBay title. Mark the product skipped with `amazon_title_zero_results` and continue to another eligible product.
- Do not use Amazon search for finding eBay sellers; use the Amazon link/title only as match evidence.
- Never qualify the Dropship Calendar source seller as the discovered seller for its own seed.
- Never qualify the exact eBay listing that supplied the seed as a candidate listing.

## Seed Discovery Strategy Decision

Decision date: 2026-05-27

For eBay seller discovery, use the Amazon/supplier title as the primary search query.

Primary search path:

- Open product card `Search` dropdown.
- Use `SEARCH ON EBAY -> Use Amazon title`.

Alternate search path:

- Use `SEARCH ON EBAY -> Use eBay title` only when the Amazon title is missing, broken, or clearly unrelated before any Amazon-title eBay search is opened.
- Do not use the eBay-title path when the Amazon-title eBay search returns zero real listing cards. In that case, run `uv run friday search no-results --search-task-id "$SEARCH_TASK_ID" --run-id "$RUN_ID"` and move to another eligible product.

Rationale:

- When the eBay title is an exact copy of Amazon, either query works.
- When the eBay title differs, it reflects one seller's rewrite and should not become the source of truth.
- The Amazon title better represents the supplier product we want to find across other dropship sellers.
- The agent will still validate candidate matches by title and image before accepting a seed or discovered seller match.

Use the eBay title for:

- Comparing how the source seller rewrote the listing.
- Match validation.
- Alternate search only if the Amazon title is unusable before an Amazon-title eBay search is opened.

## Store Selection And Seed Reuse Policy

Store choice does not need to be perfect. The system should scan through many Dropship Calendar stores over time and prevent waste by deduping seed searches and individual eBay result cards.

Store selection default:

- Treat stores as seed sources, not the primary dedupe unit.
- Prefer stores that are fully scanned or `Ready`.
- Prefer stores with many available matches.
- Prefer stores with low member overlap, such as `Only you`.
- Prefer stores not already exhausted locally.
- If remaining eligible seed count is known, choose the store with the most unseen eligible seeds.
- If remaining eligible seed count is unknown, choose the least recently scanned non-exhausted store with high available matches.

Primary seed identity:

- Dropship Calendar product ID from `selectedproducts-{productId}`.

Secondary seed identity:

- Amazon ASIN from supplier URL.
- eBay item ID from eBay URL.
- Normalized Amazon title.
- Image hash once available.

Seed statuses:

- `unseen`
- `candidate`
- `used`
- `skipped`
- `rejected`
- `stale`
- `duplicate`

Default behavior:

- A store can be revisited.
- A product seed can have a resumable search task.
- Resume partial search tasks and queued search results before opening new seed searches.
- A `find` run may start on an eBay listing or seller page instead of Dropship Calendar when queued search results exist; announce the `friday search preflight --limit 1` summary first so the resume is explicit.
- Before opening eBay for a product seed, the agent must atomically claim that seed with `friday seed claim --run-id "$RUN_ID" --dc-product-id "$DC_PRODUCT_ID"` and proceed only if the returned seed is claimed by the current run.
- `friday search start` is the enforcement gate and refuses unclaimed seeds, seeds claimed by another run, and seeds that already have a non-exhausted search task.
- Do not repeat already processed eBay result cards.
- Mark a seed as `used` only when its search task is exhausted, not merely when the eBay search opens.
- Store exhaustion means no unseen eligible seed candidates remain, not merely that the store was opened.
- Exhausted stores can be rescanned after `14` days or when Dropship Calendar shows the store was updated after the last local scan.

Track seed search state:

- search task status: `queued`, `in_progress`, `partial`, `exhausted`, or `blocked`
- search URL/query and source, default `amazon_title`
- cached first-page result count
- queued/processed result counts
- stop reason such as `target_reached`, `page_exhausted`, `blocked`, or `manual_stop`
- rejected/skipped result reason codes

## Product Seed Notes

Strong seed candidates likely have:

- Positive profit
- Lifetime Sales greater than `1`
- Members Listed equal to `0`
- Clear eBay/Amazon title overlap
- Clear eBay/Amazon image match
- Non-fragile, non-ambiguous title with model/brand/size/color terms

Useful but not required:

- Product status `Sold 30d`
- Active eBay listing

Allowed but downranked:

- `Not listed` badge
- No `Sold 30d` badge
- Members Listed greater than `0`

Weak seed candidates likely include:

- Negative profit
- Weak eBay/Amazon title overlap
- Generic title with no distinguishing terms
- High Members Listed
- Very broad category with ambiguous imagery

Current strategy default:

- `Sold 30d` should be a boost, not a requirement.
- `Not listed` should be allowed for now and treated as stale-listing risk, not a hard rejection.
