# Friday Plan

## Summary

Build a local browser-only research system for finding new eBay dropshipping stores from Dropship Calendar seed products. The system will use OpenClaw for live browsing, a local CLI/SQLite core for memory, deterministic qualification gates, exports, and screenshots for evidence. It will not use the eBay API.

Default boundary: stores that pass qualification are added to a local "qualified / approved for manual Dropship Calendar add" list, not automatically added inside Dropship Calendar.

Hard constraint: if eBay or Dropship Calendar shows captcha, anti-bot friction, account warnings, or a blocked state, the run pauses and records a blocker. No bypass behavior.

## Current Progress

Last updated: 2026-05-28

Done:

- OpenClaw config was backed up and updated from missing `Google Chrome 2.app` to installed `Google Chrome.app`.
- OpenClaw now has a config-backed default browser profile named `dc-hunter` on CDP port `18801`.
- OpenClaw smoke test passed for eBay and Dropship Calendar: eBay produced a readable search-page snapshot, Dropship Calendar produced the expected login snapshot, and screenshots were captured.
- OpenClaw workspace skill exists at `/Users/alirahimi/.openclaw/workspace/skills/friday/SKILL.md`.
- Dashboard-tested command form is the direct skill command, for example `/friday status`; `/skill friday ...` can work in fresh backend sessions but failed in the existing dashboard session due stale command/session state.
- `/friday scout-store store=barfire` completed a read-only seed extraction and recorded `11` eligible `unseen` seeds from Dropship Calendar shop `4027`.
- First live `find target=1` exposed a false-positive self-match: the source seller `barfire` was incorrectly qualified from its own seed listing. The v1 workflow now treats source-store/source-listing self-matches as invalid.
- Narrow Python/Typer CLI and SQLite core were added under `src/friday/`.
- Primary CLI command `friday` now supports `init-db`, `status`, `checks`, `assess`, `approve`, `reject`, `export`, and `record ...` subcommands. `hunter` remains as a temporary compatibility alias.
- SQLite schema now covers `runs`, `seed_products`, `stores`, `candidate_listings`, `seller_sold_items`, `qualification_checks`, `screenshots`, `exports`, and `export_items`.
- Default local database was initialized at `data/friday.sqlite3`.
- V1 qualification now uses required gates, not points.
- Deterministic status evaluation is implemented: blocker -> `blocked`, any failed gate -> `rejected`, all gates pass -> `qualified`, otherwise `manual_review`.
- Verification passed with `uv run --group dev pytest`, `uv run python -m compileall src tests`, `uv run friday checks`, an end-to-end temporary CLI smoke flow, and OpenClaw browser status checks.

Not done yet:

- First corrected eBay seller-finding run after self-match enforcement, starting with `/friday find target=1`.
- Real evidence copying into `data/evidence/YYYY-MM-DD/run-id/`.
- Web app/review UI.
- Source-store scan queue, snowball graph, saturation controls, and pagination beyond first-page eBay vetting.

## Implementation Changes

### 1. Scouting Pass

Use browser automation against a dedicated scouting session. The local OpenClaw browser config has been fixed to use installed `Google Chrome.app`, with `dc-hunter` as the default browser profile.

Scout Dropship Calendar Item Finder:

- Confirm login/session behavior: `/login` with `Email`, `Password`, `Log In`, `Discord Log In`, and `Reset password`.
- Map navigation to Item Finder from the dashboard left nav: `/dashboard/item-finder`.
- Identify how existing stores are opened from the shops page: `a[aria-label="Open products for {shop}"]` routes to `/dashboard/item-finder/shops/{shopId}`.
- Identify product row fields now observed on a store page: eBay title/link/image, Amazon title/link/image, canonical Amazon source image, eBay price, retail price, profit, members listed, sales rank/category stack, lifetime sales, updated timestamp, and status badges.
- Account for store product-page virtualization: only the visible/buffered product cards are rendered, so extraction must scroll and dedupe by product ID.
- Capture screenshots and browser snapshots of the relevant UI states.
- Confirm all scouting actions are read-only.

Observed Item Finder shops page details:

- Stats show Total Shops, Total products, and Shops Updated Last 24h.
- Shops are rendered as `article` cards.
- Shops page has explicit pagination: 20 shops on page 1, 20 on page 2, 3 on page 3.
- Search input uses `aria-label="Search shops"` and should be cleared with keyboard events, not only programmatic fill.
- Sort menu options are `Recently updated` and `Recently added`.
- Add Shops modal has textarea `#ifv2-sellers-string`, name `sellersString`, and accepts up to 10 seller IDs, one per line.
- Unsafe controls are `Bulk remove`, per-shop `Refresh`, per-shop `Delete`, and the Add Shops submit button.

Observed `barfire` store product page details:

- Store route is `/dashboard/item-finder/shops/4027`.
- Store stats: Total Products `322`, Avg Profit `-$1.91`, Sold Last 30 Days `119`, Sell-Through `1.3%`.
- Product cards use `article.product-card`; product IDs come from `input[name="selectedProducts"]`.
- Product card links use `.product-store-title.is-ebay` and `.product-store-title.is-supplier`.
- Product image links use `.product-shot.ebay` and `.product-shot.amazon`.
- The canonical seed image is the Amazon/supplier image from `.product-shot.amazon`; the source eBay image is secondary match evidence only.
- Product search dropdown exposes eBay/Amazon searches using either the eBay title or Amazon title.
- Product filters include Price Filters and Show unmatched products.
- Product sort options include profit, retail price, and lifetime sales ascending/descending.
- Unsafe product-page controls include `Automator`, `Customize Automator`, `Add to Import List`, and `Add selected to import list`.

Scout eBay search and seller pages:

- Search Amazon seed titles through the DC-generated eBay search URL.
- Vet every real listing on the first eBay results page before considering pagination.
- Identify where seller username, feedback count, feedback percent, item condition, price, sold activity, listing count, and store link appear.
- Determine reliable OpenClaw browser commands for collecting visible text and screenshots.
- Confirm stop conditions for captcha, login walls, soft blocks, and unavailable pages.

Scouting output:

- `docs/scouting/dc-item-finder.md`
- `docs/scouting/ebay-discovery.md`
- screenshot examples under `data/evidence/scouting/` once screenshot saving is enabled
- a selector/interaction map that the OpenClaw skill and scripts can follow

### 2. Local CLI And SQLite Core

Implemented first, before the web app:

- Python package: `src/friday/`
- CLI command: `friday`
- Compatibility CLI alias: `hunter`
- Runtime database default: `data/friday.sqlite3`
- Evidence directory convention: `data/evidence/YYYY-MM-DD/run-id/`
- Export directory convention: `data/exports/`
- Dependency/runtime entrypoint: `uv run friday ...`

Legacy artifacts intentionally left in place:

- Existing SQLite table names are unchanged because the schema is already durable and does not carry project branding.
- Historical run notes may still say `OpenClaw dropship hunter run`; those rows are audit history, not active configuration.
- The old live database file `data/dropship_hunter.sqlite3` remains as a compatibility/backup copy. The active default is `data/friday.sqlite3`.
- The OpenClaw browser profile remains `dc-hunter` to preserve the authenticated browser session.
- Existing generated `.venv` activation prompts can still show the previous package name until the virtualenv is recreated; source metadata and installed entrypoints now resolve as `friday`.

Implemented CLI commands:

- `friday init-db`
- `friday status`
- `friday checks`
- `friday assess --seller ... --run-id ...`
- `friday approve --seller ...`
- `friday reject --seller ... --reason ...`
- `friday export --out ...`
- `friday record run-start`
- `friday record run-finish`
- `friday record seed --json-file ...`
- `friday record seed-used --dc-product-id ... --run-id ... --search-query ...`
- `friday seed claim --run-id ... --dc-product-id ...`
- `friday record store --json-file ...`
- `friday record candidate --json-file ...`
- `friday record sold-item --json-file ...`
- `friday record check`
- `friday record screenshot`
- `friday record blocker`
- `friday search start`
- `friday search cache-results`
- `friday search preflight`
- `friday search next`
- `friday search claim`
- `friday search no-results`
- `friday search mark-result`
- `friday search finish`
- `friday explain seed`

Implemented database tables:

- `runs`: discovery/scouting/manual runs, status, counts, blocker reason.
- `seed_products`: source DC product data, titles, URLs, prices, seed status, claim owner, dedupe fields.
- `search_tasks`: one resumable eBay query opened from a seed, with partial/exhausted/blocked state.
- `search_results`: cached eBay result cards from a search task, with queued/processed status and rejection reason codes.
- `stores`: seller username, store URL/name, feedback, listing/sold counts, status.
- `candidate_listings`: seed-to-seller match, listing URL/item ID, title/price/seller evidence.
- `seller_sold_items`: first sold-page sample items for mixed-inventory judgement.
- `qualification_checks`: one row per required gate per seller/run.
- `screenshots`: screenshot file paths and source URLs.
- `exports`: export batch metadata.
- `export_items`: sellers included in each export.

Store statuses:

- `seen`
- `qualified`
- `approved`
- `manual_review`
- `rejected`
- `exported`
- `manually_added_to_dc`
- `blocked`

### 3. OpenClaw Skill

Create a workspace skill at:

`/Users/alirahimi/.openclaw/workspace/skills/friday/SKILL.md`

Skill behavior:

- Use OpenClaw browser for Dropship Calendar and eBay.
- Use local CLI commands for database writes, gate checks, dedupe, and exports.
- Never use eBay APIs.
- Never auto-add stores to Dropship Calendar.
- Never click Item Finder `Bulk remove`, per-shop `Delete`, per-shop `Refresh`, or Add Shops submit unless explicitly approved by the user.
- Pause and record blockers on captcha, login wall, warnings, or ambiguous destructive actions.
- Save evidence screenshots for every qualified seller.
- Prefer exact seed-title searches before looser searches.
- Never qualify the Dropship Calendar source seller as a discovered seller.
- Never qualify the exact eBay listing that supplied the seed as a candidate listing.
- Stop expanding a seed when saturation threshold is reached.

OpenClaw/browser capabilities to rely on:

- `snapshot` for readable UI state.
- `evaluate` for visible DOM text extraction when stable.
- `screenshot` for evidence.
- `open`, `navigate`, `click`, `type`, `press`, `wait`, `tabs` for navigation.
- `requests` only for troubleshooting, not as a data source.

Command interface:

- Preferred dashboard command: `/friday find target=1` for the first seller-finding test, then `/friday find target=10` after one seller is qualified with evidence.
- Backend/fallback command form: `/skill friday find target=1`.
- Avoid a generic `/find 10 stores` command because `find` is too broad and `10 stores` is ambiguous.
- `target=10` means the run should try to find `10` qualified candidate eBay sellers, not scan `10` Dropship Calendar stores.
- The target is a goal, not a guarantee; the run stops early if it hits blockers, saturation, seed exhaustion, captcha, login wall, or run limits.

Supported commands:

- `/friday status`
- `/friday seeds limit=25`
- `/friday scout-store store=barfire`
- `/friday find target=1`
- `/friday find target=10`
- `/friday export-approved`

Proven first-run sequence:

1. `/friday status`
2. `/friday scout-store store=barfire`
3. Confirm SQLite shows `unseen` seeds with `uv run friday status --json`.
4. `/friday find target=1`
5. Scale to `/friday find target=10` only after one seller has candidate data, required checks, and evidence screenshots.

Default `find` arguments:

- `target=10`
- `max_source_stores=3`
- `max_seeds=20`
- `max_candidates_per_seed=30`
- `search_source=amazon_title`
- `min_lifetime_sales=2`
- `min_profit=0.01`
- `members_listed_preferred=0`
- `allow_not_listed=true`
- `auto_add_to_dc=false`

Command responsibility split:

- The slash command starts the workflow.
- The OpenClaw skill handles browser navigation, screenshots, and visual validation.
- The local CLI/app owns database state, dedupe, qualification gates, run history, and exports.
- The browser agent should not rely on memory between runs; every important decision must be written to SQLite.
- No command should directly add sellers to Dropship Calendar in v1. Approved sellers should be exported for manual review.

### 4. Discovery Workflow

Store selection:

- Treat Dropship Calendar stores as seed sources; individual seed products are the main dedupe unit.
- Maintain a store scan queue.
- Prefer stores that are `Ready`, have many available matches, low member overlap, and are not exhausted.
- On each run, pick the store with the highest estimated count of unseen eligible seed products.
- If that count is unknown, pick the least recently scanned non-exhausted store with high available matches.
- Mark a store exhausted only after the virtualized product list has been fully scrolled, candidates have been extracted and filtered, and no `unseen` or `candidate` seed products remain.
- Rescan exhausted stores after `14` days, or sooner if Dropship Calendar shows a newer store update than the last local scan.

Seed and search-task dedupe:

- Do not repeat already processed eBay result cards.
- Resume `partial` search tasks and queued `search_results` before opening new seed searches.
- At the start of `find`, run `friday search preflight --limit 1` and announce whether the run will resume a queued eBay result or open Dropship Calendar for a new seed before any browser navigation.
- Before opening an eBay seed search, run `friday seed claim --run-id "$RUN_ID" --dc-product-id "$DC_PRODUCT_ID"` and proceed only if the returned seed is claimed by the current run.
- `friday search start` refuses unclaimed seeds, seeds claimed by another run, and seeds that already have a non-exhausted search task.
- A seed can have a partial search task when a run stops early because the target was reached.
- Mark a seed exhausted/used only when its cached search results are depleted or the search task is explicitly exhausted.
- Primary dedupe key is Dropship Calendar product ID from `selectedProducts-{productId}`.
- Secondary dedupe keys are Amazon ASIN, eBay item ID, normalized Amazon title, and later image hash.
- Mark duplicate, skipped, rejected, and stale seeds with reason codes.

Seed extraction:

- Open Dropship Calendar Item Finder.
- Open an existing known store from the shops page through `/dashboard/item-finder/shops/{shopId}`.
- Scroll the virtualized product list and collect unique products by `selectedProducts` product ID.
- Extract products with:
  - positive profit
  - lifetime sales greater than `1`
  - clear eBay/Amazon title and image match
  - visible Amazon/supplier title, link, and image
  - canonical Amazon image URL recorded as the seed source image
  - visible eBay item/listing reference
  - Members Listed preferably `0`
- Allow but downrank:
  - `Not listed` badge
  - no `Sold 30d` badge
  - Members Listed greater than `0`
- Save seeds to SQLite.
- Mark unusable products with reason.

eBay search and first-page vetting:

- If preflight finds queued work, the run may begin on an eBay listing or seller page. That is intentional resume behavior and must be explained before navigation.
- For each selected seed, use the Dropship Calendar product-card `Search` dropdown's `SEARCH ON EBAY` links.
- A seed is eligible only after the agent visually inspects the rendered Amazon/supplier image and rendered source eBay image on the Dropship Calendar product card.
- Persist `amazon_image_url`, `ebay_image_url`, `source_image_url`, `source_image_role`, `seed_title_match_result`, `seed_image_match_result`, and `seed_visual_evidence_note` before starting any eBay search task for the seed.
- `source_image_url` must be the Amazon/supplier image URL and `source_image_role` must be `amazon`; do not use the source eBay image as canonical seed image.
- Do not start eBay discovery from a seed whose Amazon/eBay product images are missing, broken, ambiguous, or only same-category rather than same-product.
- First-pass search uses `Use Amazon title`.
- Use the eBay title only when the Amazon title is missing, broken, or clearly unrelated before any Amazon-title eBay search is opened.
- If the Amazon-title eBay search returns zero real listing cards, do not fall back to the eBay title. Mark the product skipped with `uv run friday search no-results --search-task-id "$SEARCH_TASK_ID" --run-id "$RUN_ID"` and continue to another eligible product.
- Treat eBay title differences as seller-specific listing behavior, not source-of-truth product identity.
- Open the DC-generated eBay URL exactly as provided by the dropdown.
- Create or resume a search task for the opened URL:

```bash
uv run friday search start --dc-product-id "$DC_PRODUCT_ID" --run-id "$RUN_ID" --search-url "$SEARCH_URL" --search-query "$SEARCH_QUERY" --search-source amazon_title
```

If and only if the Amazon title was unusable before an Amazon-title eBay search was opened, use the eBay-title URL and set `--search-source ebay_title`.

- If eBay auto-corrects the query, use the visible `Search instead for...` exact-query link.
- If eBay returns a transient error page, retry once, then fall back to the same query with `_blrs=spell_auto_correct`.
- Cache every real listing card on the first eBay results page before deeper vetting.
- Skip fake marketplace placeholder cards such as `Shop on eBay`.
- Skip source-store self-matches before recording candidates: normalized candidate seller username must not equal the seed `source_store_name`.
- Skip source-listing self-matches before recording candidates: candidate item ID parsed from `ebay_item_id` or `listing_url` must not equal the seed `ebay_item_id` or item ID parsed from `source_ebay_url`.
- Do not reject solely because a listing is sponsored; sponsored listings can still reveal dropship sellers.
- Extract first-page card title, price, image URL, listing URL, item ID, seller username when visible, feedback count, feedback percent, sponsored flag, and result rank into `search_results`.
- Process queued `search_results` from SQLite; mark each processed result `candidate`, `qualified`, `rejected`, or `skipped` with a reason code when rejected/skipped.
- Pre-filter each result card for product match, price relationship, and seller feedback.
- The agent must personally inspect the seed product image and each promising eBay result-card image in the browser before opening the seller sold page.
- Do not infer image match from title, category, price, search rank, or eBay query relevance, and do not rely only on cached `image_url` text.
- A result-card image match does not require the exact same photo; different angle, crop, background, or lighting can pass only when the product identity is clear.
- Treat material differences in size, count, color, model, included parts, shape, or use case as mismatches unless listing-page evidence resolves them.
- Open only cards that appear likely to satisfy the required gates or need visual confirmation. Seller sold-page vetting is not allowed until listing-page title and image confirmation pass.
- Dedupe sellers before deeper inspection.
- Capture search result/card evidence for approved sellers when practical.
- Open candidate listing pages to confirm title, image, price, condition, seller/store name, seller ID, feedback, sold quantity, and seller links.
- Build seller sold-page URLs from `_ssn={seller_username}` only, without requiring `store_name`.
- Visit the seller sold page and extract sold results count, active listing count, visible sold-through, store lifetime items sold, category spread, and stock-photo/product-catalog signals.
- Save candidate listing evidence, seller evidence, and seller stats.

Seller sold-page URL template:

`https://www.ebay.com/sch/i.html?_dkr=1&iconV2Request=true&_blrs=recall_filtering&_ssn={seller_username}&_oac=1&LH_Sold=1`

Visible sold-through:

- Use `visible_sold_through = visible_sold_results_count / active_listing_count`.
- Do not call this lifetime sell-through. eBay's `LH_Sold=1` count is an eBay-visible sold-results count, not guaranteed lifetime history.
- Track `store_lifetime_items_sold` separately when eBay shows it in the seller/store header.

Run limits and stopping rules:

- Default target: `10` qualified candidate sellers.
- Max `3` Dropship Calendar source stores per run.
- Max `20` seed products per run.
- Max `40` eBay listing inspections per seed.
- Max `30` candidate sellers collected per seed.
- Saturation warning after `20` sellers are found from the same normalized seed title.
- Delay between page actions: `2-5` seconds.
- Stop immediately on captcha, login wall, account warning, destructive-action ambiguity, or repeated page instability.
- A run can finish with fewer than the requested target if it exhausts limits or hits blockers.
- If the target is reached before all cached results are processed, mark the search task `partial` with `stop_reason=target_reached`.
- If all cached first-page results are processed, mark the search task `exhausted` with `stop_reason=page_exhausted`.

### 5. Required-Gate Qualification

V1 does not use point scoring. A seller qualifies only when all required gates pass.

Required gates:

- `not_source_store`: candidate seller is not the Dropship Calendar source seller, and candidate listing is not the seed's source eBay listing.
- `same_product_match`: title and image clearly show the same product as the seed.
- `price_above_amazon_retail`: eBay listing price is strictly greater than Amazon retail.
- `seller_feedback_100_plus`: seller feedback count is at least `100`.
- `visible_sold_results_100_plus`: eBay visible sold result count is at least `100`.
- `mixed_non_niche_inventory`: first `30` real sold-card images/titles on the seller sold page show at least `3` broad retail macro categories.
- `catalog_stock_photo_style`: candidate listing images and the same first `30` sold-card images/titles look like retail catalog or stock-photo listings.
- `no_blocker`: no captcha, login wall, account warning, blocked state, or ambiguous destructive action occurred.

Gate result values:

- `pass`
- `fail`
- `unknown`

Deterministic status rules:

- Any run blocker or failed `no_blocker` gate -> `blocked`
- Any failed required gate -> `rejected`
- All required gates passed -> `qualified`
- No failed gates but at least one unknown/missing gate -> `manual_review`
- User approval changes `qualified` to `approved`
- Export changes `approved` to `exported`

Browser judgement requirements:

- Same-product match is the agent's visual responsibility during the run: the agent must compare the rendered seed image against the rendered eBay result-card/listing images and record the visible matching features before passing the gate.
- Same-product image match is not exact-photo matching. The image may differ by angle, crop, background, or lighting, but the product itself must clearly be the same product/SKU family.
- Do not pass `same_product_match` from title/category/search relevance alone. If the result-card image is missing, broken, too small, obscured, or ambiguous, use the listing page only to resolve the ambiguity; reject with `image_mismatch` if it remains unclear.
- Mixed inventory is assessed from the first seller sold page by inspecting the first `30` real sold-result cards, using product images plus titles/categories, not from one category label or sidebar filter alone.
- Pass mixed inventory when the reviewed sold-card images/titles span at least `3` broad retail macro categories, such as home/kitchen, beauty/personal care, toys/games, books/media, electronics, pet supplies, tools/hardware, apparel, and automotive/motors.
- Subtypes inside one vertical do not count as separate macro categories. For this gate, motorcycle, ATV, UTV, auto, racing, powersports, tires, vehicle fluids, and vehicle accessories count as the same macro category: `automotive/motors`.
- Do not pass a seller as mixed inventory just because the first sold cards include different product types within `automotive/motors`. A tire, brake pad, chain lube, helmet, hand guard, and ATV part are still one macro category.
- Catalog style is an explicit observed judgement from candidate-listing images and the same sold-card images/titles/listing style, not an automatic score.

### 6. Snowball Graph, Saturation, Evidence

Snowball graph:

- Node types: Dropship Calendar source store, seed product, candidate seller.
- Edge types: source store -> seed product, seed product -> candidate seller.
- Edge labels: matched listing count, best qualification status, run date.
- UI highlights best-producing seeds and sellers found by multiple seeds.

Saturation control:

- Track candidate count per normalized seed title.
- Warn at `10`.
- Stop automatic expansion at `20`.
- Downrank saturated seeds to avoid repeatedly finding the same seller cluster.

Evidence screenshots:

- Save one eBay search results screenshot or focused result-card screenshot per approved seller when practical.
- Save one eBay listing screenshot per qualifying match.
- Save one seller sold-page or store page screenshot per qualified seller.
- Store screenshot file paths in SQLite.
- Show screenshots directly in Store Detail.
- Keep screenshots under `data/evidence/YYYY-MM-DD/run-id/`.

## Test Plan

Scouting validation:

- Verify OpenClaw can open Dropship Calendar, navigate Item Finder, and collect read-only product data.
- Verify eBay search and seller pages can be inspected without API calls.
- Verify blocker detection works for captcha/login/warning pages.

App tests:

- Dedupe same seller by normalized username and store URL.
- Gate evaluation matches deterministic status rules exactly.
- Saturation warning triggers at `10` and stop threshold at `20`.
- Approved/exported/rejected stores are not rediscovered as new.
- Export includes only `approved` stores and marks them `exported`.

Workflow tests:

- Seed product creates graph edges.
- Candidate seller gets listing evidence attached.
- eBay first-page vetting skips placeholder cards and keeps real sponsored listings in scope.
- eBay first-page cards are cached before deeper vetting.
- Partial search tasks resume queued cards before new seed searches.
- Find runs announce a DB-grounded preflight summary before browser navigation so resumed eBay work is explicit.
- Seller sold-page URL is built from `_ssn` without requiring `store_name`.
- Visible sold-through is calculated from visible sold results and active listing count.
- Qualified seller has required qualification checks and screenshots.
- Manual approve/reject changes status correctly.
- Interrupted run can resume without duplicating stores/listings.
- Target-reached runs preserve remaining queued cards for later runs.

Acceptance criteria:

- From one Dropship Calendar store, the system can extract at least `5` valid seed products.
- From one seed, the system can find, qualify, and dedupe candidate eBay sellers.
- A resumed run states the search task, seed, next queued result, and queued count before opening eBay.
- Every qualified seller has required gate checks and evidence screenshots.
- Export produces a clean list of seller usernames/store URLs for manual DC entry.

## Assumptions And Defaults

- No eBay API will be used.
- Dropship Calendar adding remains manual.
- Local CLI/app runs only on the user's machine.
- SQLite is sufficient for v1.
- FastAPI/Jinja/HTMX remains the likely future app stack, but the implemented v1 core is CLI-first.
- OpenClaw is the browser automation layer.
- Dedicated browser profile target is `dc-hunter`; OpenClaw now points at installed `Google Chrome.app`.
- V1 has no point threshold. Qualification is all-required-gates-pass.
- Runs are intentionally slow and resumable rather than high-volume.
- Captcha/blocker handling is pause-and-record only.
