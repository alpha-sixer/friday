from __future__ import annotations

import csv
import json
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional
from urllib.parse import quote


REQUIRED_CHECKS = (
    "not_source_store",
    "same_product_match",
    "price_above_amazon_retail",
    "seller_feedback_100_plus",
    "visible_sold_results_100_plus",
    "mixed_non_niche_inventory",
    "catalog_stock_photo_style",
    "no_blocker",
)

CHECK_THRESHOLDS = {
    "not_source_store": "candidate seller and listing are not the Dropship Calendar source seller/listing",
    "same_product_match": "clear title/image match against canonical Amazon seed image",
    "price_above_amazon_retail": "listing price > Amazon retail",
    "seller_feedback_100_plus": "feedback count >= 100",
    "visible_sold_results_100_plus": "visible sold results >= 100",
    "mixed_non_niche_inventory": "first 30 sold-card images/titles show at least 3 broad retail macro categories",
    "catalog_stock_photo_style": "candidate and sold-card samples use retail catalog or stock-photo style listings",
    "no_blocker": "no captcha/login/account warning/blocker",
}

BLOCKER_TYPES = {
    "captcha",
    "login_wall",
    "account_warning",
    "blocked_state",
    "ambiguous_destructive_action",
}

SEARCH_TASK_STATUSES = {"queued", "in_progress", "partial", "exhausted", "blocked"}
SEARCH_TASK_STOP_REASONS = {"target_reached", "page_exhausted", "blocked", "manual_stop"}
SEARCH_RESULT_STATUSES = {"queued", "processing", "candidate", "qualified", "rejected", "skipped"}
SEARCH_RESULT_REASON_CODES = {
    "blocked",
    "duplicate_result",
    "feedback_under_100",
    "image_mismatch",
    "manual_stop",
    "placeholder_card",
    "price_below_retail",
    "qualified_elsewhere",
    "seller_seen",
    "source_listing_self_match",
    "source_store_self_match",
    "title_mismatch",
}

SOLD_VISUAL_REVIEW_MAX_RANK = 30
SOLD_VISUAL_REVIEW_MIN_IMAGE_SAMPLES = 30
SOLD_VISUAL_REVIEW_MIN_MACRO_CATEGORIES = 3
SOURCE_IMAGE_ROLE = "amazon"
AMAZON_TITLE_SEARCH_SOURCE = "amazon_title"
EBAY_TITLE_SEARCH_SOURCE = "ebay_title"
SEED_SKIP_REASON_AMAZON_TITLE_ZERO_RESULTS = "amazon_title_zero_results"
MATCH_RESULTS = {"pass", "fail", "unknown"}
STORE_STATUS_QUALIFIED = "qualified"
STORE_STATUS_MANUALLY_ADDED_TO_DC = "manually_added_to_dc"
STORE_STATUSES_NOT_REQUALIFIED = {
    STORE_STATUS_MANUALLY_ADDED_TO_DC,
    "approved",
    "exported",
    "rejected",
}
HANDOFF_STATUSES = {"pending", "confirmed", "cancelled"}


class FridayError(RuntimeError):
    pass


@dataclass(frozen=True)
class Assessment:
    seller_username: str
    run_id: Optional[int]
    status: str
    checks: Mapping[str, str]
    reason: str


def normalize_seller_username(value: str) -> str:
    return re.sub(r"\s+", "", value.strip().lower())


def extract_ebay_item_id(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if re.fullmatch(r"\d{6,}", text):
        return text
    path_match = re.search(r"/itm/(?:[^/?#]+/)?(\d{6,})", text)
    if path_match:
        return path_match.group(1)
    query_match = re.search(r"[?&](?:item|itemid|itemId|_trksid_item)=(\d{6,})", text)
    if query_match:
        return query_match.group(1)
    return None


def load_json_file(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def coerce_items(payload: Any) -> list[Mapping[str, Any]]:
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        return [payload]
    raise FridayError("JSON payload must be an object or array of objects.")


def row_to_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    if row is None:
        return None
    return dict(row)


def last_insert_id(cursor: sqlite3.Cursor) -> int:
    if cursor.lastrowid is None:
        raise FridayError("insert did not return a row id")
    return int(cursor.lastrowid)


def table_exists(conn: sqlite3.Connection, table_name: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?",
        (table_name,),
    ).fetchone()
    return row is not None


def create_run(
    conn: sqlite3.Connection,
    run_type: str = "manual",
    target_count: int | None = None,
    notes: str | None = None,
) -> int:
    cursor = conn.execute(
        """
        INSERT INTO runs (run_type, target_count, notes)
        VALUES (?, ?, ?)
        """,
        (run_type, target_count, notes),
    )
    conn.commit()
    return last_insert_id(cursor)


def finish_run(conn: sqlite3.Connection, run_id: int, status: str = "finished") -> None:
    conn.execute(
        """
        UPDATE runs
        SET status = ?, ended_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (status, run_id),
    )
    conn.commit()


def record_blocker(
    conn: sqlite3.Connection,
    run_id: int,
    blocker_type: str,
    detail: str | None = None,
) -> None:
    if blocker_type not in BLOCKER_TYPES:
        allowed = ", ".join(sorted(BLOCKER_TYPES))
        raise FridayError(f"Unknown blocker type '{blocker_type}'. Allowed: {allowed}")
    row = conn.execute("SELECT id FROM runs WHERE id = ?", (run_id,)).fetchone()
    if row is None:
        raise FridayError(f"Unknown run id {run_id}")
    conn.execute(
        """
        UPDATE runs
        SET status = 'blocked',
            blocker_type = ?,
            blocker_detail = ?,
            ended_at = COALESCE(ended_at, CURRENT_TIMESTAMP),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (blocker_type, detail, run_id),
    )
    conn.commit()


def upsert_seed(conn: sqlite3.Connection, data: Mapping[str, Any]) -> int:
    dc_product_id = data.get("dc_product_id")
    if not dc_product_id:
        raise FridayError("seed requires dc_product_id")
    _validate_seed_visual_payload(data)

    amazon_image_url = data.get("amazon_image_url")
    fields = {
        "dc_product_id": dc_product_id,
        "source_store_name": data.get("source_store_name"),
        "source_store_dc_shop_id": data.get("source_store_dc_shop_id"),
        "amazon_asin": data.get("amazon_asin"),
        "ebay_item_id": data.get("ebay_item_id"),
        "amazon_title": data.get("amazon_title"),
        "ebay_title": data.get("ebay_title"),
        "supplier_url": data.get("supplier_url"),
        "source_ebay_url": data.get("source_ebay_url"),
        "amazon_retail_price": data.get("amazon_retail_price"),
        "dc_ebay_price": data.get("dc_ebay_price"),
        "profit": data.get("profit"),
        "members_listed": data.get("members_listed"),
        "lifetime_sales": data.get("lifetime_sales"),
        "status": data.get("status", "unseen"),
        "used_at": data.get("used_at"),
        "discovery_run_id": data.get("discovery_run_id"),
        "search_query_used": data.get("search_query_used"),
        "search_source": data.get("search_source", "amazon_title"),
        "skip_reason": data.get("skip_reason"),
        "duplicate_of_id": data.get("duplicate_of_id"),
        "image_path": data.get("image_path"),
        "amazon_image_url": amazon_image_url,
        "ebay_image_url": data.get("ebay_image_url"),
        "source_image_url": data.get("source_image_url") or amazon_image_url,
        "source_image_role": data.get("source_image_role", SOURCE_IMAGE_ROLE),
        "seed_title_match_result": data.get("seed_title_match_result"),
        "seed_image_match_result": data.get("seed_image_match_result"),
        "seed_visual_evidence_note": data.get("seed_visual_evidence_note"),
    }
    columns = tuple(fields)
    placeholders = ", ".join("?" for _ in columns)
    update_columns = [
        column
        for column in columns
        if column != "dc_product_id" and column in data and data.get(column) is not None
    ]
    if update_columns:
        conflict_clause = (
            "DO UPDATE SET "
            + ", ".join(f"{column}=excluded.{column}" for column in update_columns)
            + ", updated_at = CURRENT_TIMESTAMP"
        )
    else:
        conflict_clause = "DO NOTHING"
    conn.execute(
        f"""
        INSERT INTO seed_products ({", ".join(columns)})
        VALUES ({placeholders})
        ON CONFLICT(dc_product_id) {conflict_clause}
        """,
        tuple(fields[column] for column in columns),
    )
    conn.commit()
    row = conn.execute("SELECT id FROM seed_products WHERE dc_product_id = ?", (dc_product_id,)).fetchone()
    return int(row["id"])


def _clean_string(value: Any) -> str:
    return str(value or "").strip()


def _validate_match_result(data: Mapping[str, Any], field_name: str) -> None:
    value = data.get(field_name)
    if value is not None and value not in MATCH_RESULTS:
        allowed = ", ".join(sorted(MATCH_RESULTS))
        raise FridayError(f"{field_name} must be one of: {allowed}")


def _seed_payload_looks_eligible(data: Mapping[str, Any]) -> bool:
    status = data.get("status", "unseen")
    if status in {"skipped", "duplicate"} or data.get("skip_reason") or data.get("duplicate_of_id"):
        return False
    eligibility_fields = {
        "supplier_url",
        "source_ebay_url",
        "ebay_item_id",
        "amazon_retail_price",
        "dc_ebay_price",
        "profit",
        "members_listed",
        "lifetime_sales",
    }
    return any(data.get(field) is not None for field in eligibility_fields)


def _validate_seed_visual_payload(data: Mapping[str, Any]) -> None:
    _validate_match_result(data, "seed_title_match_result")
    _validate_match_result(data, "seed_image_match_result")

    source_image_role = data.get("source_image_role", SOURCE_IMAGE_ROLE)
    if source_image_role != SOURCE_IMAGE_ROLE:
        raise FridayError("source_image_role must be amazon")

    amazon_image_url = _clean_string(data.get("amazon_image_url"))
    source_image_url = _clean_string(data.get("source_image_url") or amazon_image_url)
    if amazon_image_url and source_image_url and amazon_image_url != source_image_url:
        raise FridayError("source_image_url must match amazon_image_url")

    if _seed_payload_looks_eligible(data):
        missing = [
            field
            for field in (
                "amazon_image_url",
                "ebay_image_url",
                "source_image_url",
                "seed_visual_evidence_note",
            )
            if not _clean_string(data.get(field) if field != "source_image_url" else source_image_url)
        ]
        if data.get("seed_title_match_result") != "pass":
            missing.append("seed_title_match_result=pass")
        if data.get("seed_image_match_result") != "pass":
            missing.append("seed_image_match_result=pass")
        if missing:
            raise FridayError(
                "eligible seed requires canonical Amazon source image evidence: " + ", ".join(missing)
            )


def _seed_has_canonical_image_evidence(seed: Mapping[str, Any]) -> bool:
    amazon_image_url = _clean_string(seed["amazon_image_url"])
    source_image_url = _clean_string(seed["source_image_url"])
    return (
        bool(amazon_image_url)
        and bool(_clean_string(seed["ebay_image_url"]))
        and source_image_url == amazon_image_url
        and seed["source_image_role"] == SOURCE_IMAGE_ROLE
        and seed["seed_title_match_result"] == "pass"
        and seed["seed_image_match_result"] == "pass"
        and bool(_clean_string(seed["seed_visual_evidence_note"]))
    )


def _seed_image_evidence_error(dc_product_id: str) -> FridayError:
    return FridayError(
        f"seed {dc_product_id} requires canonical Amazon source image evidence before eBay discovery"
    )


def upsert_store(conn: sqlite3.Connection, data: Mapping[str, Any]) -> int:
    seller_username = data.get("seller_username")
    if not seller_username:
        raise FridayError("store requires seller_username")
    normalized = normalize_seller_username(str(seller_username))
    status_provided = "status" in data
    fields = {
        "seller_username": seller_username,
        "normalized_username": normalized,
        "store_name": data.get("store_name"),
        "store_url": data.get("store_url"),
        "feedback_count": data.get("feedback_count"),
        "feedback_percent": data.get("feedback_percent"),
        "active_listing_count": data.get("active_listing_count"),
        "visible_sold_results_count": data.get("visible_sold_results_count"),
        "store_lifetime_items_sold": data.get("store_lifetime_items_sold"),
        "status": data.get("status", "seen"),
        "status_reason": data.get("status_reason"),
        "notes": data.get("notes"),
    }
    columns = tuple(fields)
    placeholders = ", ".join("?" for _ in columns)
    updatable = [column for column in columns if column not in {"normalized_username", "first_seen_at"}]
    update_parts = []
    for column in updatable:
        if column == "status" and not status_provided:
            update_parts.append("status=stores.status")
        elif column == "status":
            terminal_statuses = ", ".join("?" for _ in STORE_STATUSES_NOT_REQUALIFIED)
            update_parts.append(
                "status=CASE "
                f"WHEN stores.status IN ({terminal_statuses}) THEN stores.status "
                "ELSE COALESCE(excluded.status, stores.status) END"
            )
        elif column == "status_reason":
            terminal_statuses = ", ".join("?" for _ in STORE_STATUSES_NOT_REQUALIFIED)
            update_parts.append(
                "status_reason=CASE "
                f"WHEN stores.status IN ({terminal_statuses}) THEN stores.status_reason "
                "ELSE COALESCE(excluded.status_reason, stores.status_reason) END"
            )
        else:
            update_parts.append(f"{column}=COALESCE(excluded.{column}, stores.{column})")
    updates = ", ".join(update_parts)
    terminal_params: tuple[str, ...] = ()
    if status_provided:
        terminal_params += tuple(STORE_STATUSES_NOT_REQUALIFIED)
    terminal_params += tuple(STORE_STATUSES_NOT_REQUALIFIED)
    conn.execute(
        f"""
        INSERT INTO stores ({", ".join(columns)})
        VALUES ({placeholders})
        ON CONFLICT(normalized_username) DO UPDATE SET
          {updates},
          last_seen_at = CURRENT_TIMESTAMP,
          updated_at = CURRENT_TIMESTAMP
        """,
        tuple(fields[column] for column in columns) + terminal_params,
    )
    conn.commit()
    return get_store_id(conn, seller_username)


def store_lookup(conn: sqlite3.Connection, seller_username: str) -> dict[str, Any]:
    if not seller_username:
        raise FridayError("seller username is required")
    normalized = normalize_seller_username(seller_username)
    row = conn.execute(
        """
        SELECT *
        FROM stores
        WHERE normalized_username = ?
        """,
        (normalized,),
    ).fetchone()
    if row is None:
        return {
            "exists": False,
            "seller_username": seller_username,
            "normalized_username": normalized,
            "seen_already": False,
            "do_not_qualify_as_new": False,
            "recommended_result_reason_code": None,
        }

    handoff_rows = conn.execute(
        """
        SELECT hi.handoff_id, h.status, h.confirmed_at, h.cancelled_at
        FROM store_handoff_items hi
        JOIN store_handoffs h ON h.id = hi.handoff_id
        WHERE hi.store_id = ?
        ORDER BY hi.handoff_id
        """,
        (row["id"],),
    ).fetchall()
    confirmed_handoff_ids = [int(item["handoff_id"]) for item in handoff_rows if item["status"] == "confirmed"]
    candidate_count = int(
        conn.execute(
            "SELECT COUNT(*) AS count FROM candidate_listings WHERE store_id = ?",
            (row["id"],),
        ).fetchone()["count"]
    )
    status = row["status"]
    if status in {STORE_STATUS_QUALIFIED, STORE_STATUS_MANUALLY_ADDED_TO_DC, "approved", "exported"}:
        reason_code = "qualified_elsewhere"
    else:
        reason_code = "seller_seen"
    return {
        "exists": True,
        "seller_username": row["seller_username"],
        "normalized_username": row["normalized_username"],
        "store": dict(row),
        "seen_already": True,
        "do_not_qualify_as_new": True,
        "recommended_result_reason_code": reason_code,
        "candidate_listing_count": candidate_count,
        "handoffs": [dict(item) for item in handoff_rows],
        "confirmed_handoff_ids": confirmed_handoff_ids,
    }


def get_store_id(conn: sqlite3.Connection, seller_username: str) -> int:
    normalized = normalize_seller_username(seller_username)
    row = conn.execute(
        "SELECT id FROM stores WHERE normalized_username = ?",
        (normalized,),
    ).fetchone()
    if row is None:
        raise FridayError(f"Unknown seller '{seller_username}'")
    return int(row["id"])


def find_seed_id(conn: sqlite3.Connection, dc_product_id: str | None) -> int | None:
    if not dc_product_id:
        return None
    row = conn.execute(
        "SELECT id FROM seed_products WHERE dc_product_id = ?",
        (dc_product_id,),
    ).fetchone()
    if row is None:
        raise FridayError(f"Unknown seed dc_product_id '{dc_product_id}'")
    return int(row["id"])


def get_seed_row(conn: sqlite3.Connection, seed_id: int | None) -> sqlite3.Row | None:
    if seed_id is None:
        return None
    row = conn.execute("SELECT * FROM seed_products WHERE id = ?", (seed_id,)).fetchone()
    if row is None:
        raise FridayError(f"Unknown seed id {seed_id}")
    return row


def mark_seed_used(
    conn: sqlite3.Connection,
    dc_product_id: str,
    run_id: int,
    search_query_used: str,
    search_source: str | None = None,
) -> int:
    if not dc_product_id:
        raise FridayError("seed-used requires dc_product_id")
    if not search_query_used:
        raise FridayError("seed-used requires search_query_used")
    run = conn.execute("SELECT id FROM runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        raise FridayError(f"Unknown run id {run_id}")
    seed = conn.execute("SELECT * FROM seed_products WHERE dc_product_id = ?", (dc_product_id,)).fetchone()
    if seed is None:
        raise FridayError(f"Unknown seed dc_product_id '{dc_product_id}'")
    if seed["used_at"] is not None and seed["discovery_run_id"] != run_id:
        raise FridayError(f"Seed '{dc_product_id}' was already used by run {seed['discovery_run_id']}")

    conn.execute(
        """
        UPDATE seed_products
        SET status = 'used',
            used_at = COALESCE(used_at, CURRENT_TIMESTAMP),
            discovery_run_id = ?,
            search_query_used = ?,
            search_source = COALESCE(?, search_source),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (run_id, search_query_used, search_source, seed["id"]),
    )
    conn.commit()
    return int(seed["id"])


def start_search_task(
    conn: sqlite3.Connection,
    dc_product_id: str,
    run_id: int,
    search_url: str,
    search_query: str | None = None,
    search_source: str = "amazon_title",
) -> int:
    if not search_url:
        raise FridayError("search task requires search_url")
    search_source = search_source or AMAZON_TITLE_SEARCH_SOURCE
    run = conn.execute("SELECT id FROM runs WHERE id = ?", (run_id,)).fetchone()
    if run is None:
        raise FridayError(f"Unknown run id {run_id}")
    seed_id = find_seed_id(conn, dc_product_id)
    if seed_id is None:
        raise FridayError(f"Unknown seed dc_product_id '{dc_product_id}'")
    seed = get_seed_row(conn, seed_id)
    if seed is not None and seed["status"] == "skipped":
        reason = f" ({seed['skip_reason']})" if seed["skip_reason"] else ""
        raise FridayError(f"Seed '{dc_product_id}' is skipped{reason}")
    if seed is not None and seed["skip_reason"] == SEED_SKIP_REASON_AMAZON_TITLE_ZERO_RESULTS:
        raise FridayError(f"Seed '{dc_product_id}' was skipped because amazon_title returned zero eBay results")
    if search_source == EBAY_TITLE_SEARCH_SOURCE and _seed_has_zero_result_amazon_title_task(conn, seed_id):
        raise FridayError(
            f"eBay-title search is not allowed for seed '{dc_product_id}' after an amazon_title search ended with zero cached results"
        )
    if seed is None or not _seed_has_canonical_image_evidence(seed):
        raise _seed_image_evidence_error(dc_product_id)

    row = conn.execute(
        """
        SELECT id, status FROM search_tasks
        WHERE seed_product_id = ? AND search_url = ?
        """,
        (seed_id, search_url),
    ).fetchone()
    if row is not None:
        status = "in_progress" if row["status"] in {"queued", "partial"} else row["status"]
        conn.execute(
            """
            UPDATE search_tasks
            SET run_id_started = ?,
                search_source = COALESCE(?, search_source),
                search_query = COALESCE(?, search_query),
                status = ?,
                stop_reason = CASE WHEN ? = 'in_progress' THEN NULL ELSE stop_reason END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (run_id, search_source, search_query, status, status, row["id"]),
        )
        conn.commit()
        return int(row["id"])

    cursor = conn.execute(
        """
        INSERT INTO search_tasks (
          seed_product_id, run_id_started, search_source, search_query, search_url, status
        )
        VALUES (?, ?, ?, ?, ?, 'in_progress')
        """,
        (seed_id, run_id, search_source, search_query, search_url),
    )
    conn.commit()
    return last_insert_id(cursor)


def _get_search_task(conn: sqlite3.Connection, search_task_id: int) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM search_tasks WHERE id = ?", (search_task_id,)).fetchone()
    if row is None:
        raise FridayError(f"Unknown search task id {search_task_id}")
    return row


def _seed_has_zero_result_amazon_title_task(conn: sqlite3.Connection, seed_id: int) -> bool:
    row = conn.execute(
        """
        SELECT st.id
        FROM search_tasks st
        LEFT JOIN search_results sr ON sr.search_task_id = st.id
        WHERE st.seed_product_id = ?
          AND st.search_source = ?
          AND st.status = 'exhausted'
        GROUP BY st.id
        HAVING COUNT(sr.id) = 0
        LIMIT 1
        """,
        (seed_id, AMAZON_TITLE_SEARCH_SOURCE),
    ).fetchone()
    return row is not None


def _find_search_result_matches(
    conn: sqlite3.Connection,
    search_task_id: int,
    page_number: int,
    rank: int,
    ebay_item_id: str | None,
    listing_url: str | None,
) -> set[int]:
    matches = {
        int(row["id"])
        for row in conn.execute(
            """
            SELECT id FROM search_results
            WHERE search_task_id = ? AND page_number = ? AND rank = ?
            """,
            (search_task_id, page_number, rank),
        ).fetchall()
    }
    if ebay_item_id:
        matches.update(
            int(row["id"])
            for row in conn.execute(
                "SELECT id FROM search_results WHERE search_task_id = ? AND ebay_item_id = ?",
                (search_task_id, ebay_item_id),
            ).fetchall()
        )
    if listing_url:
        matches.update(
            int(row["id"])
            for row in conn.execute(
                "SELECT id FROM search_results WHERE search_task_id = ? AND listing_url = ?",
                (search_task_id, listing_url),
            ).fetchall()
        )
    return matches


def cache_search_results(
    conn: sqlite3.Connection,
    search_task_id: int,
    items: Iterable[Mapping[str, Any]],
) -> list[int]:
    _get_search_task(conn, search_task_id)
    result_ids: list[int] = []
    for data in items:
        rank = data.get("rank")
        if rank is None:
            raise FridayError("search result requires rank")
        page_number = int(data.get("page_number", 1))
        rank = int(rank)
        listing_url = data.get("listing_url")
        ebay_item_id = extract_ebay_item_id(data.get("ebay_item_id")) or extract_ebay_item_id(listing_url)
        seller_username = data.get("seller_username")
        requested_status = data.get("status", "queued")
        if requested_status not in SEARCH_RESULT_STATUSES:
            raise FridayError(f"Unknown search result status '{requested_status}'")
        if requested_status != "queued":
            raise FridayError("cache_search_results can only create queued results; use mark_search_result to process cards")
        requested_reason_code = data.get("reason_code")
        if requested_reason_code is not None:
            if requested_reason_code not in SEARCH_RESULT_REASON_CODES:
                raise FridayError(f"Unknown search result reason code '{requested_reason_code}'")
            raise FridayError("cache_search_results cannot set reason_code; use mark_search_result to process cards")
        fields = {
            "search_task_id": search_task_id,
            "page_number": page_number,
            "rank": rank,
            "ebay_item_id": ebay_item_id,
            "listing_url": listing_url,
            "seller_username": seller_username,
            "normalized_seller_username": normalize_seller_username(str(seller_username)) if seller_username else None,
            "title": data.get("title"),
            "price": data.get("price"),
            "image_url": data.get("image_url"),
            "sponsored": int(bool(data.get("sponsored"))) if "sponsored" in data else 0,
            "feedback_count": data.get("feedback_count"),
            "feedback_percent": data.get("feedback_percent"),
            "status": "queued",
            "reason_code": None,
        }

        matched_ids = _find_search_result_matches(
            conn,
            search_task_id=search_task_id,
            page_number=page_number,
            rank=rank,
            ebay_item_id=ebay_item_id,
            listing_url=listing_url,
        )
        if len(matched_ids) > 1:
            raise FridayError("Search result identity conflict: rank, eBay item ID, and listing URL match different rows")
        if matched_ids:
            result_id = next(iter(matched_ids))
            update_columns = [
                column
                for column, value in fields.items()
                if column not in {"search_task_id", "page_number", "rank", "status", "reason_code"} and value is not None
                and (column != "sponsored" or "sponsored" in data)
            ]
            if update_columns:
                assignments = ", ".join(f"{column} = ?" for column in update_columns)
                conn.execute(
                    f"""
                    UPDATE search_results
                    SET {assignments}, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                    """,
                    tuple(fields[column] for column in update_columns) + (result_id,),
                )
            result_ids.append(result_id)
            continue

        columns = tuple(fields)
        placeholders = ", ".join("?" for _ in columns)
        cursor = conn.execute(
            f"""
            INSERT INTO search_results ({", ".join(columns)})
            VALUES ({placeholders})
            """,
            tuple(fields[column] for column in columns),
        )
        result_ids.append(last_insert_id(cursor))
    conn.commit()
    return result_ids


def next_search_results(conn: sqlite3.Connection, limit: int = 10) -> list[dict[str, Any]]:
    rows = conn.execute(
        """
        SELECT
          sr.*,
          st.id AS search_task_id,
          st.status AS task_status,
          st.search_url,
          st.search_query,
          st.search_source,
          sp.dc_product_id,
          sp.source_store_name,
          sp.ebay_item_id AS seed_ebay_item_id,
          sp.amazon_title AS seed_amazon_title,
          sp.amazon_retail_price AS seed_amazon_retail_price,
          sp.dc_ebay_price AS seed_dc_ebay_price
        FROM search_results sr
        JOIN search_tasks st ON st.id = sr.search_task_id
        JOIN seed_products sp ON sp.id = st.seed_product_id
        WHERE sr.status = 'queued'
          AND st.status IN ('partial', 'in_progress', 'queued')
        ORDER BY
          CASE st.status
            WHEN 'partial' THEN 0
            WHEN 'in_progress' THEN 1
            WHEN 'queued' THEN 2
            ELSE 3
          END,
          st.updated_at,
          st.id,
          sr.page_number,
          sr.rank
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [dict(row) for row in rows]


def claim_search_results(conn: sqlite3.Connection, limit: int = 10) -> list[dict[str, Any]]:
    if limit < 1:
        raise FridayError("claim limit must be at least 1")
    try:
        conn.execute("BEGIN IMMEDIATE")
        rows = next_search_results(conn, limit=limit)
        result_ids = [row["id"] for row in rows]
        if result_ids:
            placeholders = ", ".join("?" for _ in result_ids)
            conn.execute(
                f"""
                UPDATE search_results
                SET status = 'processing',
                    updated_at = CURRENT_TIMESTAMP
                WHERE status = 'queued'
                  AND id IN ({placeholders})
                """,
                tuple(result_ids),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise

    for row in rows:
        row["status"] = "processing"
    return rows


def search_preflight(conn: sqlite3.Connection, limit: int = 1) -> dict[str, Any]:
    rows = next_search_results(conn, limit=max(1, limit))
    if not rows:
        return {"mode": "new_seed", "queued_count": 0}

    row = rows[0]
    queued_count_row = conn.execute(
        """
        SELECT COUNT(*) AS queued_count
        FROM search_results
        WHERE search_task_id = ?
          AND status = 'queued'
        """,
        (row["search_task_id"],),
    ).fetchone()
    queued_count = int(queued_count_row["queued_count"])
    return {
        "mode": "resume_queue",
        "queued_count": queued_count,
        "search_task_id": row["search_task_id"],
        "task_status": row["task_status"],
        "dc_product_id": row["dc_product_id"],
        "seed_title": row["seed_amazon_title"],
        "search_query": row["search_query"],
        "search_url": row["search_url"],
        "next_search_result_id": row["id"],
        "next_rank": row["rank"],
        "next_seller_username": row["seller_username"],
        "next_listing_url": row["listing_url"],
        "next_ebay_item_id": row["ebay_item_id"],
        "next_title": row["title"],
    }


def mark_search_result(
    conn: sqlite3.Connection,
    search_result_id: int,
    status: str,
    reason_code: str | None = None,
    run_id: int | None = None,
    candidate_listing_id: int | None = None,
) -> int:
    if status not in SEARCH_RESULT_STATUSES:
        raise FridayError(f"Unknown search result status '{status}'")
    if status in {"rejected", "skipped"} and not reason_code:
        raise FridayError(f"search result status '{status}' requires reason_code")
    if reason_code is not None and reason_code not in SEARCH_RESULT_REASON_CODES:
        raise FridayError(f"Unknown search result reason code '{reason_code}'")
    if run_id is not None:
        run = conn.execute("SELECT id FROM runs WHERE id = ?", (run_id,)).fetchone()
        if run is None:
            raise FridayError(f"Unknown run id {run_id}")
    if candidate_listing_id is not None:
        candidate = conn.execute("SELECT id FROM candidate_listings WHERE id = ?", (candidate_listing_id,)).fetchone()
        if candidate is None:
            raise FridayError(f"Unknown candidate listing id {candidate_listing_id}")
    row = conn.execute("SELECT * FROM search_results WHERE id = ?", (search_result_id,)).fetchone()
    if row is None:
        raise FridayError(f"Unknown search result id {search_result_id}")
    if row["status"] not in {"queued", "processing"}:
        raise FridayError(
            f"Search result {search_result_id} is already {row['status']}; refusing to overwrite processed result"
        )

    conn.execute(
        """
        UPDATE search_results
        SET status = ?,
            reason_code = ?,
            processed_run_id = COALESCE(?, processed_run_id),
            candidate_listing_id = COALESCE(?, candidate_listing_id),
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (status, reason_code, run_id, candidate_listing_id, search_result_id),
    )
    conn.execute(
        """
        UPDATE search_tasks
        SET last_processed_rank = CASE
              WHEN last_processed_rank < ? THEN ?
              ELSE last_processed_rank
            END,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (row["rank"], row["rank"], row["search_task_id"]),
    )
    conn.commit()
    return search_result_id


def finish_search_task(
    conn: sqlite3.Connection,
    search_task_id: int,
    status: str,
    stop_reason: str | None = None,
) -> int:
    if status not in SEARCH_TASK_STATUSES:
        raise FridayError(f"Unknown search task status '{status}'")
    if stop_reason is not None and stop_reason not in SEARCH_TASK_STOP_REASONS:
        raise FridayError(f"Unknown search task stop reason '{stop_reason}'")
    task = _get_search_task(conn, search_task_id)
    if status == "exhausted":
        unfinished_count = int(
            conn.execute(
                """
                SELECT COUNT(*) AS count
                FROM search_results
                WHERE search_task_id = ?
                  AND status IN ('queued', 'processing')
                """,
                (search_task_id,),
            ).fetchone()["count"]
        )
        if unfinished_count:
            raise FridayError("Cannot exhaust search task while queued or processing results remain")
    conn.execute(
        """
        UPDATE search_tasks
        SET status = ?, stop_reason = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (status, stop_reason, search_task_id),
    )
    if status == "partial":
        conn.execute(
            """
            UPDATE seed_products
            SET status = CASE WHEN status = 'unseen' THEN 'candidate' ELSE status END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (task["seed_product_id"],),
        )
    elif status == "exhausted":
        search_query_used = task["search_query"] or task["search_url"]
        conn.execute(
            """
            UPDATE seed_products
            SET status = 'used',
                used_at = COALESCE(used_at, CURRENT_TIMESTAMP),
                discovery_run_id = COALESCE(?, discovery_run_id),
                search_query_used = COALESCE(?, search_query_used),
                search_source = COALESCE(?, search_source),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (task["run_id_started"], search_query_used, task["search_source"], task["seed_product_id"]),
        )
    conn.commit()
    return search_task_id


def mark_search_no_results(conn: sqlite3.Connection, search_task_id: int, run_id: int | None = None) -> int:
    task = _get_search_task(conn, search_task_id)
    if task["search_source"] != AMAZON_TITLE_SEARCH_SOURCE:
        raise FridayError("no-results can only be recorded for amazon_title search tasks")
    if task["status"] not in {"queued", "in_progress"}:
        raise FridayError("no-results can only be recorded for queued or in-progress search tasks")
    if run_id is not None:
        run = conn.execute("SELECT id FROM runs WHERE id = ?", (run_id,)).fetchone()
        if run is None:
            raise FridayError(f"Unknown run id {run_id}")

    result_count = int(
        conn.execute(
            "SELECT COUNT(*) AS count FROM search_results WHERE search_task_id = ?",
            (search_task_id,),
        ).fetchone()["count"]
    )
    if result_count:
        raise FridayError("no-results requires zero cached search results")

    resolved_run_id = run_id if run_id is not None else task["run_id_started"]
    search_query_used = task["search_query"] or task["search_url"]
    conn.execute(
        """
        UPDATE search_tasks
        SET status = 'exhausted',
            stop_reason = 'page_exhausted',
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (search_task_id,),
    )
    conn.execute(
        """
        UPDATE seed_products
        SET status = 'skipped',
            skip_reason = ?,
            discovery_run_id = COALESCE(?, discovery_run_id),
            search_query_used = COALESCE(?, search_query_used),
            search_source = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            SEED_SKIP_REASON_AMAZON_TITLE_ZERO_RESULTS,
            resolved_run_id,
            search_query_used,
            AMAZON_TITLE_SEARCH_SOURCE,
            task["seed_product_id"],
        ),
    )
    conn.commit()
    return search_task_id


def explain_seed(conn: sqlite3.Connection, dc_product_id: str) -> dict[str, Any]:
    seed = conn.execute("SELECT * FROM seed_products WHERE dc_product_id = ?", (dc_product_id,)).fetchone()
    if seed is None:
        raise FridayError(f"Unknown seed dc_product_id '{dc_product_id}'")
    tasks = []
    task_rows = conn.execute(
        """
        SELECT * FROM search_tasks
        WHERE seed_product_id = ?
        ORDER BY id
        """,
        (seed["id"],),
    ).fetchall()
    for task in task_rows:
        counts = {
            row["status"]: int(row["count"])
            for row in conn.execute(
                """
                SELECT status, COUNT(*) AS count
                FROM search_results
                WHERE search_task_id = ?
                GROUP BY status
                ORDER BY status
                """,
                (task["id"],),
            ).fetchall()
        }
        task_dict = dict(task)
        task_dict["result_counts"] = counts
        tasks.append(task_dict)
    queued_results = [
        dict(row)
        for row in conn.execute(
            """
            SELECT sr.*
            FROM search_results sr
            JOIN search_tasks st ON st.id = sr.search_task_id
            WHERE st.seed_product_id = ? AND sr.status = 'queued'
            ORDER BY st.id, sr.page_number, sr.rank
            """,
            (seed["id"],),
        ).fetchall()
    ]
    candidates = [
        dict(row)
        for row in conn.execute(
            """
            SELECT c.*, s.seller_username
            FROM candidate_listings c
            JOIN stores s ON s.id = c.store_id
            WHERE c.seed_product_id = ?
            ORDER BY c.id
            """,
            (seed["id"],),
        ).fetchall()
    ]
    return {
        "seed": dict(seed),
        "search_tasks": tasks,
        "queued_results": queued_results,
        "candidate_listings": candidates,
    }


def upsert_candidate(conn: sqlite3.Connection, data: Mapping[str, Any]) -> int:
    seed_id = data.get("seed_product_id")
    if seed_id is None:
        seed_id = find_seed_id(conn, data.get("dc_product_id"))
    seed = get_seed_row(conn, seed_id)

    if not data.get("listing_url") and not data.get("ebay_item_id"):
        raise FridayError("candidate requires listing_url or ebay_item_id")

    seed_item_id = None
    if seed is not None:
        seed_item_id = extract_ebay_item_id(seed["ebay_item_id"]) or extract_ebay_item_id(seed["source_ebay_url"])
    candidate_item_id = extract_ebay_item_id(data.get("ebay_item_id")) or extract_ebay_item_id(data.get("listing_url"))
    if seed_item_id and candidate_item_id and seed_item_id == candidate_item_id:
        raise FridayError("candidate listing matches source seed listing")

    store_id = data.get("store_id")
    if store_id is None:
        seller_username = data.get("seller_username")
        if not seller_username:
            raise FridayError("candidate requires seller_username or store_id")
        if seed is not None and seed["source_store_name"]:
            source_seller = normalize_seller_username(str(seed["source_store_name"]))
            if source_seller and normalize_seller_username(str(seller_username)) == source_seller:
                raise FridayError("candidate seller matches source store")
        store_id = upsert_store(conn, {"seller_username": seller_username})
    elif seed is not None and seed["source_store_name"]:
        row = conn.execute("SELECT normalized_username FROM stores WHERE id = ?", (store_id,)).fetchone()
        if row is None:
            raise FridayError(f"Unknown store id {store_id}")
        source_seller = normalize_seller_username(str(seed["source_store_name"]))
        if source_seller and row["normalized_username"] == source_seller:
            raise FridayError("candidate seller matches source store")

    sponsored = int(bool(data.get("sponsored"))) if "sponsored" in data else 0
    fields = {
        "seed_product_id": seed_id,
        "store_id": store_id,
        "run_id": data.get("run_id"),
        "search_result_rank": data.get("search_result_rank"),
        "sponsored": sponsored,
        "ebay_item_id": data.get("ebay_item_id"),
        "listing_url": data.get("listing_url"),
        "card_title": data.get("card_title"),
        "card_price": data.get("card_price"),
        "card_image_url": data.get("card_image_url"),
        "listing_title": data.get("listing_title"),
        "listing_price": data.get("listing_price"),
        "condition": data.get("condition"),
        "seller_text": data.get("seller_text"),
        "card_feedback_count": data.get("card_feedback_count"),
        "card_feedback_percent": data.get("card_feedback_percent"),
        "title_match_result": data.get("title_match_result"),
        "image_match_result": data.get("image_match_result"),
        "price_above_retail_result": data.get("price_above_retail_result"),
        "evidence_note": data.get("evidence_note"),
    }
    columns = tuple(fields)

    matches = []
    if data.get("ebay_item_id"):
        matches.extend(
            conn.execute(
                "SELECT id FROM candidate_listings WHERE ebay_item_id = ?",
                (data["ebay_item_id"],),
            ).fetchall()
        )
    if data.get("listing_url"):
        matches.extend(
            conn.execute(
                "SELECT id FROM candidate_listings WHERE listing_url = ?",
                (data["listing_url"],),
            ).fetchall()
        )
    matched_ids = {int(row["id"]) for row in matches}
    if len(matched_ids) > 1:
        raise FridayError("Candidate identity conflict: eBay item ID and listing URL match different rows")

    if matched_ids:
        candidate_id = next(iter(matched_ids))
        update_columns = [
            column
            for column in columns
            if fields[column] is not None and (column != "sponsored" or "sponsored" in data)
        ]
        if update_columns:
            assignments = ", ".join(f"{column} = ?" for column in update_columns)
            conn.execute(
                f"""
                UPDATE candidate_listings
                SET {assignments}, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                """,
                tuple(fields[column] for column in update_columns) + (candidate_id,),
            )
        else:
            conn.execute(
                "UPDATE candidate_listings SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
                (candidate_id,),
            )
        conn.commit()
        return candidate_id

    placeholders = ", ".join("?" for _ in columns)
    cursor = conn.execute(
        f"""
        INSERT INTO candidate_listings ({", ".join(columns)})
        VALUES ({placeholders})
        """,
        tuple(fields[column] for column in columns),
    )
    conn.commit()
    return last_insert_id(cursor)


def _provided_non_null(data: Mapping[str, Any], column: str) -> bool:
    return column in data and data.get(column) is not None


def _conflict_clause(
    table_name: str,
    columns: Iterable[str],
    data: Mapping[str, Any],
    key_columns: set[str],
    timestamp_column: str | None = "updated_at",
) -> str:
    update_columns = [
        column
        for column in columns
        if column not in key_columns and _provided_non_null(data, column)
    ]
    if not update_columns:
        return "DO NOTHING"
    assignments = [f"{column}=COALESCE(excluded.{column}, {table_name}.{column})" for column in update_columns]
    if timestamp_column is not None:
        assignments.append(f"{timestamp_column}=CURRENT_TIMESTAMP")
    return "DO UPDATE SET " + ", ".join(assignments)


def upsert_sold_item(conn: sqlite3.Connection, data: Mapping[str, Any]) -> int:
    seller_username = data.get("seller_username")
    if not seller_username:
        raise FridayError("sold item requires seller_username")
    store_id = get_store_id(conn, seller_username)
    run_id = data.get("run_id")
    if run_id is None:
        raise FridayError("sold item requires run_id")
    rank = data.get("rank")
    if rank is None:
        raise FridayError("sold item requires rank")

    fields = {
        "store_id": store_id,
        "run_id": run_id,
        "rank": rank,
        "title": data.get("title"),
        "price": data.get("price"),
        "item_url": data.get("item_url"),
        "image_url": data.get("image_url"),
        "category_text": data.get("category_text"),
        "sold_date_text": data.get("sold_date_text"),
        "raw_text": data.get("raw_text"),
    }
    columns = tuple(fields)
    placeholders = ", ".join("?" for _ in columns)
    conflict_clause = _conflict_clause(
        table_name="seller_sold_items",
        columns=columns,
        data=data,
        key_columns={"store_id", "run_id", "rank"},
        timestamp_column=None,
    )
    conn.execute(
        f"""
        INSERT INTO seller_sold_items ({", ".join(columns)})
        VALUES ({placeholders})
        ON CONFLICT(store_id, run_id, rank) {conflict_clause}
        """,
        tuple(fields[column] for column in columns),
    )
    conn.commit()
    row = conn.execute(
        "SELECT id FROM seller_sold_items WHERE store_id = ? AND run_id IS ? AND rank = ?",
        (store_id, run_id, rank),
    ).fetchone()
    return int(row["id"])


def record_screenshot(conn: sqlite3.Connection, data: Mapping[str, Any]) -> int:
    file_path = data.get("file_path")
    if not file_path:
        raise FridayError("screenshot requires file_path")
    resolved_path = Path(str(file_path)).expanduser().resolve()
    if not resolved_path.exists():
        raise FridayError(f"screenshot file does not exist: {resolved_path}")
    if not resolved_path.is_file():
        raise FridayError(f"screenshot path must be a file: {resolved_path}")
    if resolved_path.stat().st_size <= 0:
        raise FridayError(f"screenshot file is empty: {resolved_path}")
    cursor = conn.execute(
        """
        INSERT INTO screenshots (entity_type, entity_id, screenshot_type, file_path, source_url)
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            data.get("entity_type", "unknown"),
            data.get("entity_id"),
            data.get("screenshot_type", "evidence"),
            str(resolved_path),
            data.get("source_url"),
        ),
    )
    conn.commit()
    return last_insert_id(cursor)


def record_check(
    conn: sqlite3.Connection,
    seller_username: str,
    run_id: int | None,
    check_name: str,
    result: str,
    observed_value: str | None = None,
    threshold: str | None = None,
    evidence_note: str | None = None,
    candidate_listing_id: int | None = None,
    screenshot_id: int | None = None,
    assessed_by: str = "manual",
) -> int:
    if check_name not in REQUIRED_CHECKS:
        allowed = ", ".join(REQUIRED_CHECKS)
        raise FridayError(f"Unknown check '{check_name}'. Allowed: {allowed}")
    if result not in {"pass", "fail", "unknown"}:
        raise FridayError("result must be pass, fail, or unknown")

    store_id = get_store_id(conn, seller_username)
    threshold = threshold or CHECK_THRESHOLDS[check_name]
    conn.execute(
        """
        INSERT INTO qualification_checks (
          store_id, run_id, check_name, result, observed_value, threshold,
          evidence_note, candidate_listing_id, screenshot_id, assessed_by
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(store_id, run_id, check_name) DO UPDATE SET
          result = excluded.result,
          observed_value = excluded.observed_value,
          threshold = excluded.threshold,
          evidence_note = excluded.evidence_note,
          candidate_listing_id = excluded.candidate_listing_id,
          screenshot_id = excluded.screenshot_id,
          assessed_by = excluded.assessed_by,
          updated_at = CURRENT_TIMESTAMP
        """,
        (
            store_id,
            run_id,
            check_name,
            result,
            observed_value,
            threshold,
            evidence_note,
            candidate_listing_id,
            screenshot_id,
            assessed_by,
        ),
    )
    conn.commit()
    row = conn.execute(
        """
        SELECT id FROM qualification_checks
        WHERE store_id = ? AND run_id IS ? AND check_name = ?
        """,
        (store_id, run_id, check_name),
    ).fetchone()
    return int(row["id"])


def _normalize_macro_category(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _sold_visual_review_summary(conn: sqlite3.Connection, store_id: int, run_id: int | None) -> dict[str, Any]:
    rows = conn.execute(
        """
        SELECT rank, image_url, category_text
        FROM seller_sold_items
        WHERE store_id = ?
          AND run_id IS ?
          AND rank BETWEEN 1 AND ?
        ORDER BY rank
        """,
        (store_id, run_id, SOLD_VISUAL_REVIEW_MAX_RANK),
    ).fetchall()
    image_rows = [row for row in rows if str(row["image_url"] or "").strip()]
    macro_categories = {
        normalized
        for row in image_rows
        if (normalized := _normalize_macro_category(row["category_text"]))
    }
    return {
        "sample_count": len(rows),
        "image_sample_count": len(image_rows),
        "macro_category_count": len(macro_categories),
        "macro_categories": sorted(macro_categories),
    }


def _visual_review_observed_value(summary: Mapping[str, Any]) -> str:
    macro_categories = summary.get("macro_categories") or []
    category_text = ", ".join(str(value) for value in macro_categories[:6]) or "none recorded"
    return (
        f"reviewed {summary['image_sample_count']} image-backed sold samples "
        f"from ranks 1-{SOLD_VISUAL_REVIEW_MAX_RANK}; macro categories: "
        f"{summary['macro_category_count']} ({category_text})"
    )


def _enforce_sold_visual_review(
    conn: sqlite3.Connection,
    seller_username: str,
    run_id: int | None,
    checks: dict[str, str],
) -> dict[str, str]:
    if checks.get("mixed_non_niche_inventory") != "pass" and checks.get("catalog_stock_photo_style") != "pass":
        return checks

    store_id = get_store_id(conn, seller_username)
    summary = _sold_visual_review_summary(conn, store_id, run_id)
    has_enough_images = summary["image_sample_count"] >= SOLD_VISUAL_REVIEW_MIN_IMAGE_SAMPLES
    has_enough_categories = summary["macro_category_count"] >= SOLD_VISUAL_REVIEW_MIN_MACRO_CATEGORIES
    observed_value = _visual_review_observed_value(summary)

    if checks.get("mixed_non_niche_inventory") == "pass" and not (has_enough_images and has_enough_categories):
        record_check(
            conn,
            seller_username=seller_username,
            run_id=run_id,
            check_name="mixed_non_niche_inventory",
            result="unknown",
            observed_value=observed_value,
            threshold=(
                f"first {SOLD_VISUAL_REVIEW_MAX_RANK} sold cards include at least "
                f"{SOLD_VISUAL_REVIEW_MIN_IMAGE_SAMPLES} image-backed samples and "
                f"{SOLD_VISUAL_REVIEW_MIN_MACRO_CATEGORIES} broad retail macro categories"
            ),
            evidence_note=(
                "CLI requires first-page sold-card macro-category evidence before accepting mixed inventory."
            ),
            assessed_by="cli",
        )
        checks["mixed_non_niche_inventory"] = "unknown"

    if checks.get("catalog_stock_photo_style") == "pass" and not has_enough_images:
        record_check(
            conn,
            seller_username=seller_username,
            run_id=run_id,
            check_name="catalog_stock_photo_style",
            result="unknown",
            observed_value=observed_value,
            threshold=(
                f"first {SOLD_VISUAL_REVIEW_MAX_RANK} sold cards include at least "
                f"{SOLD_VISUAL_REVIEW_MIN_IMAGE_SAMPLES} image-backed samples"
            ),
            evidence_note=(
                "CLI requires first-page sold-card image evidence before accepting catalog/stock-photo style."
            ),
            assessed_by="cli",
        )
        checks["catalog_stock_photo_style"] = "unknown"

    return checks


def _same_product_evidence_summary(conn: sqlite3.Connection, store_id: int, run_id: int | None) -> dict[str, Any]:
    rows = conn.execute(
        """
        SELECT
          c.id AS candidate_listing_id,
          c.title_match_result,
          c.image_match_result,
          c.price_above_retail_result,
          c.card_image_url,
          c.evidence_note,
          sp.dc_product_id,
          sp.amazon_image_url,
          sp.ebay_image_url,
          sp.source_image_url,
          sp.source_image_role,
          sp.seed_title_match_result,
          sp.seed_image_match_result,
          sp.seed_visual_evidence_note
        FROM candidate_listings c
        LEFT JOIN seed_products sp ON sp.id = c.seed_product_id
        WHERE c.store_id = ?
          AND c.run_id IS ?
        ORDER BY c.id
        """,
        (store_id, run_id),
    ).fetchall()
    matching_rows = [
        row
        for row in rows
        if row["title_match_result"] == "pass"
        and row["image_match_result"] == "pass"
        and row["price_above_retail_result"] == "pass"
        and _clean_string(row["card_image_url"])
        and _clean_string(row["evidence_note"])
        and _seed_has_canonical_image_evidence(row)
    ]
    return {
        "candidate_count": len(rows),
        "matching_count": len(matching_rows),
        "candidate_listing_id": matching_rows[0]["candidate_listing_id"] if matching_rows else None,
    }


def _enforce_same_product_evidence(
    conn: sqlite3.Connection,
    seller_username: str,
    run_id: int | None,
    checks: dict[str, str],
) -> dict[str, str]:
    if checks.get("same_product_match") != "pass":
        return checks

    store_id = get_store_id(conn, seller_username)
    summary = _same_product_evidence_summary(conn, store_id, run_id)
    if summary["matching_count"] > 0:
        return checks

    record_check(
        conn,
        seller_username=seller_username,
        run_id=run_id,
        check_name="same_product_match",
        result="unknown",
        observed_value=(
            f"{summary['matching_count']} candidate listings with title/image/price pass, card image, "
            "evidence note, and canonical Amazon seed image evidence"
        ),
        threshold=(
            "candidate listing title_match_result=image_match_result=price_above_retail_result=pass, "
            "card_image_url present, evidence_note describes visible matching features, and seed has "
            "canonical Amazon source image evidence"
        ),
        evidence_note=(
            "CLI requires agent-recorded same-product image evidence from the canonical Amazon seed image "
            "before accepting same_product_match."
        ),
        assessed_by="cli",
    )
    checks["same_product_match"] = "unknown"
    return checks


def assess_store(conn: sqlite3.Connection, seller_username: str, run_id: int | None) -> Assessment:
    store_id = get_store_id(conn, seller_username)
    store_row = conn.execute("SELECT status FROM stores WHERE id = ?", (store_id,)).fetchone()
    current_status = store_row["status"]
    run = None
    if run_id is not None:
        run = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        if run is None:
            raise FridayError(f"Unknown run id {run_id}")

    blocker_type = run["blocker_type"] if run is not None else None
    for check_name in REQUIRED_CHECKS:
        row = conn.execute(
            """
            SELECT id FROM qualification_checks
            WHERE store_id = ? AND run_id IS ? AND check_name = ?
            """,
            (store_id, run_id, check_name),
        ).fetchone()
        if check_name == "no_blocker":
            if blocker_type or row is None:
                record_check(
                    conn,
                    seller_username=seller_username,
                    run_id=run_id,
                    check_name=check_name,
                    result="fail" if blocker_type else "pass",
                    observed_value=blocker_type or "none",
                    evidence_note=run["blocker_detail"] if run is not None and blocker_type else None,
                    assessed_by="cli",
                )
            continue

        if row is not None:
            continue
        record_check(
            conn,
            seller_username=seller_username,
            run_id=run_id,
            check_name=check_name,
            result="unknown",
            assessed_by="cli",
        )

    rows = conn.execute(
        """
        SELECT check_name, result FROM qualification_checks
        WHERE store_id = ? AND run_id IS ?
        """,
        (store_id, run_id),
    ).fetchall()
    checks = {row["check_name"]: row["result"] for row in rows}
    checks = _enforce_same_product_evidence(conn, seller_username, run_id, checks)
    checks = _enforce_sold_visual_review(conn, seller_username, run_id, checks)

    if blocker_type or checks.get("no_blocker") == "fail":
        status = "blocked"
        reason = blocker_type or "blocker recorded"
    elif any(checks.get(check_name) == "fail" for check_name in REQUIRED_CHECKS):
        status = "rejected"
        failed = [check_name for check_name in REQUIRED_CHECKS if checks.get(check_name) == "fail"]
        reason = "failed gates: " + ", ".join(failed)
    elif all(checks.get(check_name) == "pass" for check_name in REQUIRED_CHECKS):
        status = "qualified"
        reason = "all required gates passed"
    else:
        status = "manual_review"
        unknown = [check_name for check_name in REQUIRED_CHECKS if checks.get(check_name) != "pass"]
        reason = "unknown gates: " + ", ".join(unknown)

    if current_status in STORE_STATUSES_NOT_REQUALIFIED:
        update_run_counts(conn, run_id)
        conn.commit()
        return Assessment(
            seller_username=seller_username,
            run_id=run_id,
            status=current_status,
            checks=checks,
            reason=f"preserved existing terminal status: {current_status}",
        )

    conn.execute(
        """
        UPDATE stores
        SET status = ?, status_reason = ?, updated_at = CURRENT_TIMESTAMP, last_seen_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (status, reason, store_id),
    )
    update_run_counts(conn, run_id)
    conn.commit()

    return Assessment(seller_username=seller_username, run_id=run_id, status=status, checks=checks, reason=reason)


def update_run_counts(conn: sqlite3.Connection, run_id: int | None) -> None:
    if run_id is None:
        return
    counts = {
        "qualified": 0,
        "manual_review": 0,
        "rejected": 0,
        "blocked": 0,
    }
    rows = conn.execute(
        """
        SELECT status, COUNT(*) AS count
        FROM stores
        WHERE id IN (
          SELECT DISTINCT store_id FROM qualification_checks WHERE run_id IS ?
        )
        GROUP BY status
        """,
        (run_id,),
    ).fetchall()
    for row in rows:
        if row["status"] in counts:
            counts[row["status"]] = int(row["count"])
    conn.execute(
        """
        UPDATE runs
        SET qualified_count = ?,
            manual_review_count = ?,
            rejected_count = ?,
            blocked_count = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (
            counts["qualified"],
            counts["manual_review"],
            counts["rejected"],
            counts["blocked"],
            run_id,
        ),
    )


def approve_store(conn: sqlite3.Connection, seller_username: str, note: str | None = None, force: bool = False) -> None:
    store_id = get_store_id(conn, seller_username)
    row = conn.execute("SELECT status FROM stores WHERE id = ?", (store_id,)).fetchone()
    status = row["status"]
    if status != "qualified" and not force:
        raise FridayError(f"Only qualified stores can be approved without --force. Current status: {status}")
    reason = note or "approved manually"
    conn.execute(
        """
        UPDATE stores
        SET status = 'approved', status_reason = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (reason, store_id),
    )
    conn.commit()


def reject_store(conn: sqlite3.Connection, seller_username: str, reason: str) -> None:
    store_id = get_store_id(conn, seller_username)
    conn.execute(
        """
        UPDATE stores
        SET status = 'rejected', status_reason = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (reason, store_id),
    )
    conn.commit()


def export_approved(conn: sqlite3.Connection, out_path: Path, notes: str | None = None) -> int:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    rows = conn.execute(
        """
        SELECT id, seller_username, store_url, status
        FROM stores
        WHERE status = 'approved'
        ORDER BY lower(seller_username)
        """
    ).fetchall()
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["seller_username", "store_url"])
        writer.writeheader()
        for row in rows:
            writer.writerow({"seller_username": row["seller_username"], "store_url": row["store_url"] or ""})

    cursor = conn.execute(
        """
        INSERT INTO exports (file_path, item_count, notes)
        VALUES (?, ?, ?)
        """,
        (str(out_path), len(rows), notes),
    )
    export_id = last_insert_id(cursor)
    for row in rows:
        conn.execute(
            """
            INSERT INTO export_items (export_id, store_id, seller_username, store_url, status_at_export)
            VALUES (?, ?, ?, ?, ?)
            """,
            (export_id, row["id"], row["seller_username"], row["store_url"], row["status"]),
        )
    conn.execute(
        """
        UPDATE stores
        SET status = 'exported', status_reason = 'exported to CSV', updated_at = CURRENT_TIMESTAMP
        WHERE status = 'approved'
        """
    )
    conn.commit()
    return export_id


def _handoff_seller_payload(conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    candidate = conn.execute(
        """
        SELECT *
        FROM candidate_listings
        WHERE store_id = ?
        ORDER BY created_at DESC, id DESC
        LIMIT 1
        """,
        (row["store_id"],),
    ).fetchone()
    screenshot = conn.execute(
        """
        SELECT file_path, source_url
        FROM screenshots
        WHERE entity_type = 'store'
          AND entity_id = ?
          AND screenshot_type = 'seller_sold_page'
        ORDER BY captured_at DESC, id DESC
        LIMIT 1
        """,
        (row["store_id"],),
    ).fetchone()
    seller_username = row["seller_username"]
    payload = {
        "store_id": row["store_id"],
        "seller_username": seller_username,
        "store_name": row["store_name"],
        "store_url": row["store_url"],
        "seller_url": seller_search_url(seller_username),
        "seller_sold_url": seller_sold_url(seller_username),
        "feedback_count": row["feedback_count"],
        "feedback_percent": row["feedback_percent"],
        "visible_sold_results_count": row["visible_sold_results_count"],
        "store_lifetime_items_sold": row["store_lifetime_items_sold"],
        "status_at_handoff": row["status_at_handoff"],
        "matching_listing_url": candidate["listing_url"] if candidate else None,
        "matching_listing_title": candidate["listing_title"] if candidate else None,
        "matching_listing_price": candidate["listing_price"] if candidate else None,
        "screenshot_path": screenshot["file_path"] if screenshot else None,
        "screenshot_source_url": screenshot["source_url"] if screenshot else None,
    }
    quality_parts = []
    if payload["feedback_percent"] is not None:
        quality_parts.append(f"{payload['feedback_percent']:g}% feedback")
    if payload["visible_sold_results_count"] is not None:
        sold_count = int(payload["visible_sold_results_count"])
        quality_parts.append(f"{sold_count:,}+ sold results" if sold_count >= 1000 else f"{sold_count:,} sold results")
    if payload["matching_listing_url"]:
        quality_parts.append("same-product listing recorded")
    payload["quality_summary"] = ", ".join(quality_parts)
    return payload


def handoff_report(conn: sqlite3.Connection, handoff_id: int | None = None, pending: bool = False) -> dict[str, Any]:
    if pending:
        handoff = conn.execute(
            """
            SELECT *
            FROM store_handoffs
            WHERE status = 'pending'
            ORDER BY id DESC
            LIMIT 1
            """
        ).fetchone()
    elif handoff_id is None:
        handoff = conn.execute("SELECT * FROM store_handoffs ORDER BY id DESC LIMIT 1").fetchone()
    else:
        handoff = conn.execute("SELECT * FROM store_handoffs WHERE id = ?", (handoff_id,)).fetchone()
    if handoff is None:
        raise FridayError("No handoff found" if handoff_id is None else f"Unknown handoff id {handoff_id}")

    item_rows = conn.execute(
        """
        SELECT
          hi.store_id,
          hi.seller_username,
          hi.store_url,
          hi.status_at_handoff,
          s.store_name,
          s.feedback_count,
          s.feedback_percent,
          s.visible_sold_results_count,
          s.store_lifetime_items_sold
        FROM store_handoff_items hi
        JOIN stores s ON s.id = hi.store_id
        WHERE hi.handoff_id = ?
        ORDER BY lower(hi.seller_username)
        """,
        (handoff["id"],),
    ).fetchall()
    available_row = conn.execute(
        """
        SELECT COUNT(*) AS count
        FROM stores s
        WHERE s.status = ?
          AND NOT EXISTS (
            SELECT 1
            FROM store_handoff_items hi
            JOIN store_handoffs h ON h.id = hi.handoff_id
            WHERE hi.store_id = s.id
              AND h.status = 'confirmed'
          )
        """,
        (STORE_STATUS_QUALIFIED,),
    ).fetchone()
    item_count = len(item_rows)
    return {
        "handoff": dict(handoff),
        "stores": [_handoff_seller_payload(conn, row) for row in item_rows],
        "item_count": item_count,
        "available_qualified_now": int(available_row["count"]),
        "available_qualified_after_confirm": max(0, int(available_row["count"]) - item_count)
        if handoff["status"] == "pending"
        else int(available_row["count"]),
        "requires_confirmation": handoff["status"] == "pending",
    }


def _pending_handoff_id(conn: sqlite3.Connection) -> int | None:
    row = conn.execute(
        """
        SELECT id
        FROM store_handoffs
        WHERE status = 'pending'
        ORDER BY id DESC
        LIMIT 1
        """
    ).fetchone()
    return int(row["id"]) if row else None


def create_store_handoff(
    conn: sqlite3.Connection,
    limit: int | None = 10,
    include_all: bool = False,
    notes: str | None = None,
) -> dict[str, Any]:
    try:
        conn.execute("BEGIN IMMEDIATE")
        pending_id = _pending_handoff_id(conn)
        if pending_id is not None:
            raise FridayError(f"Pending handoff {pending_id} already exists; confirm or cancel it before creating another")
        if include_all:
            limit = None
        elif limit is None or limit < 1:
            raise FridayError("handoff limit must be at least 1 unless --all is used")

        query = """
            SELECT s.id, s.seller_username, s.store_url, s.status
            FROM stores s
            WHERE s.status = ?
              AND NOT EXISTS (
                SELECT 1
                FROM store_handoff_items hi
                JOIN store_handoffs h ON h.id = hi.handoff_id
                WHERE hi.store_id = s.id
                  AND h.status = 'confirmed'
              )
            ORDER BY s.updated_at, lower(s.seller_username)
        """
        params: tuple[Any, ...] = (STORE_STATUS_QUALIFIED,)
        if limit is not None:
            query += " LIMIT ?"
            params = (STORE_STATUS_QUALIFIED, limit)
        rows = conn.execute(query, params).fetchall()
        if not rows:
            raise FridayError("No qualified stores are available for handoff")

        cursor = conn.execute(
            """
            INSERT INTO store_handoffs (requested_count, item_count, notes)
            VALUES (?, ?, ?)
            """,
            (None if include_all else limit, len(rows), notes),
        )
        handoff_id = last_insert_id(cursor)
        for row in rows:
            conn.execute(
                """
                INSERT INTO store_handoff_items (
                  handoff_id, store_id, seller_username, store_url, status_at_handoff
                )
                VALUES (?, ?, ?, ?, ?)
                """,
                (handoff_id, row["id"], row["seller_username"], row["store_url"], row["status"]),
            )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return handoff_report(conn, handoff_id=handoff_id)


def confirm_store_handoff(conn: sqlite3.Connection, handoff_id: int, note: str | None = None) -> dict[str, Any]:
    try:
        conn.execute("BEGIN IMMEDIATE")
        handoff = conn.execute("SELECT * FROM store_handoffs WHERE id = ?", (handoff_id,)).fetchone()
        if handoff is None:
            raise FridayError(f"Unknown handoff id {handoff_id}")
        if handoff["status"] != "pending":
            raise FridayError(f"Only pending handoffs can be confirmed. Current status: {handoff['status']}")
        reason = note or f"manually added to Dropship Calendar from handoff {handoff_id}"
        store_rows = conn.execute(
            """
            SELECT s.id, s.seller_username, s.status
            FROM store_handoff_items hi
            JOIN stores s ON s.id = hi.store_id
            WHERE hi.handoff_id = ?
            ORDER BY lower(s.seller_username)
            """,
            (handoff_id,),
        ).fetchall()
        store_ids = [int(row["id"]) for row in store_rows]
        if not store_ids:
            raise FridayError(f"Handoff {handoff_id} has no stores to confirm")
        unavailable = [row["seller_username"] for row in store_rows if row["status"] != STORE_STATUS_QUALIFIED]
        if unavailable:
            raise FridayError(
                "Cannot confirm handoff because stores are no longer qualified: " + ", ".join(unavailable)
            )
        placeholders = ", ".join("?" for _ in store_ids)
        duplicate_rows = conn.execute(
            f"""
            SELECT hi.seller_username, hi.handoff_id
            FROM store_handoff_items hi
            JOIN store_handoffs h ON h.id = hi.handoff_id
            WHERE h.status = 'confirmed'
              AND hi.handoff_id <> ?
              AND hi.store_id IN ({placeholders})
            ORDER BY lower(hi.seller_username), hi.handoff_id
            """,
            (handoff_id, *store_ids),
        ).fetchall()
        if duplicate_rows:
            details = ", ".join(
                f"{row['seller_username']} in handoff {row['handoff_id']}" for row in duplicate_rows
            )
            raise FridayError("Cannot confirm handoff because stores were already confirmed: " + details)
        conn.execute(
            f"""
            UPDATE stores
            SET status = ?,
                status_reason = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id IN ({placeholders})
            """,
            (STORE_STATUS_MANUALLY_ADDED_TO_DC, reason, *store_ids),
        )
        conn.execute(
            """
            UPDATE store_handoffs
            SET status = 'confirmed',
                confirmed_at = CURRENT_TIMESTAMP,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
            """,
            (handoff_id,),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return handoff_report(conn, handoff_id=handoff_id)


def cancel_store_handoff(conn: sqlite3.Connection, handoff_id: int, note: str | None = None) -> dict[str, Any]:
    handoff = conn.execute("SELECT * FROM store_handoffs WHERE id = ?", (handoff_id,)).fetchone()
    if handoff is None:
        raise FridayError(f"Unknown handoff id {handoff_id}")
    if handoff["status"] != "pending":
        raise FridayError(f"Only pending handoffs can be cancelled. Current status: {handoff['status']}")
    conn.execute(
        """
        UPDATE store_handoffs
        SET status = 'cancelled',
            notes = COALESCE(?, notes),
            cancelled_at = CURRENT_TIMESTAMP,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
        """,
        (note, handoff_id),
    )
    conn.commit()
    return handoff_report(conn, handoff_id=handoff_id)


def status_summary(conn: sqlite3.Connection) -> dict[str, Any]:
    store_counts = {
        row["status"]: row["count"]
        for row in conn.execute("SELECT status, COUNT(*) AS count FROM stores GROUP BY status").fetchall()
    }
    seed_counts = {
        row["status"]: row["count"]
        for row in conn.execute("SELECT status, COUNT(*) AS count FROM seed_products GROUP BY status").fetchall()
    }
    run = row_to_dict(
        conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    )
    summary = {"stores": store_counts, "seeds": seed_counts, "latest_run": run}
    if table_exists(conn, "search_tasks"):
        summary["search_tasks"] = {
            row["status"]: row["count"]
            for row in conn.execute("SELECT status, COUNT(*) AS count FROM search_tasks GROUP BY status").fetchall()
        }
    if table_exists(conn, "search_results"):
        summary["search_results"] = {
            row["status"]: row["count"]
            for row in conn.execute("SELECT status, COUNT(*) AS count FROM search_results GROUP BY status").fetchall()
        }
    if table_exists(conn, "store_handoffs"):
        summary["store_handoffs"] = {
            row["status"]: row["count"]
            for row in conn.execute("SELECT status, COUNT(*) AS count FROM store_handoffs GROUP BY status").fetchall()
        }
    return summary


def seller_sold_url(seller_username: str) -> str:
    encoded = quote(seller_username, safe="")
    return (
        "https://www.ebay.com/sch/i.html?_dkr=1&iconV2Request=true"
        f"&_blrs=recall_filtering&_ssn={encoded}&_oac=1&LH_Sold=1"
    )


def seller_search_url(seller_username: str) -> str:
    return f"https://www.ebay.com/sch/i.html?_ssn={quote(seller_username, safe='')}"


def dropship_calendar_shop_url(shop_id: str | None) -> str | None:
    if not shop_id:
        return None
    return f"https://autopilot.dropshipcalendar.io/dashboard/item-finder/shops/{quote(str(shop_id), safe='')}"


def _run_status_from_checks(
    run: Mapping[str, Any],
    checks: Mapping[str, str],
) -> str:
    if run.get("blocker_type") or checks.get("no_blocker") == "fail":
        return "blocked"
    if any(checks.get(check_name) == "fail" for check_name in REQUIRED_CHECKS):
        return "rejected"
    if all(checks.get(check_name) == "pass" for check_name in REQUIRED_CHECKS):
        return "qualified"
    return "manual_review"


def _seller_quality_line(
    seller: Mapping[str, Any],
    checks: Mapping[str, Mapping[str, Any]],
) -> str:
    details = []
    if seller.get("feedback_percent") is not None:
        details.append(f"{seller['feedback_percent']:g}% feedback")
    if seller.get("visible_sold_results_count") is not None:
        visible_sold = int(seller["visible_sold_results_count"])
        details.append(f"{visible_sold:,}+ sold results" if visible_sold >= 1000 else f"{visible_sold:,} sold results")
    mixed = checks.get("mixed_non_niche_inventory", {})
    observed = mixed.get("observed_value")
    if observed:
        match = re.search(r"(?:macro categories|product types):\s*(.+)", observed)
        if match:
            details.append("mixed inventory: " + match.group(1).strip())
        else:
            details.append(str(observed))
    return ", ".join(details)


def _task_id_placeholders(task_ids: list[int]) -> str:
    return ", ".join("?" for _ in task_ids)


def run_report(conn: sqlite3.Connection, run_id: int | None = None, seller_limit: int = 10) -> dict[str, Any]:
    if seller_limit < 1:
        raise FridayError("seller_limit must be at least 1")
    if run_id is None:
        run_row = conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    else:
        run_row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
    if run_row is None:
        raise FridayError("No run found" if run_id is None else f"Unknown run id {run_id}")
    run = dict(run_row)
    run_id = int(run["id"])

    task_rows = conn.execute(
        """
        SELECT DISTINCT st.*
        FROM search_tasks st
        LEFT JOIN search_results sr ON sr.search_task_id = st.id
        LEFT JOIN candidate_listings c ON c.seed_product_id = st.seed_product_id
        WHERE st.run_id_started = ?
           OR sr.processed_run_id = ?
           OR c.run_id = ?
        ORDER BY st.id
        """,
        (run_id, run_id, run_id),
    ).fetchall()
    task_ids = [int(row["id"]) for row in task_rows]
    search_tasks = [dict(row) for row in task_rows]
    searches_opened = sum(1 for row in search_tasks if row["run_id_started"] == run_id)
    processed_count_row = conn.execute(
        "SELECT COUNT(*) AS count FROM search_results WHERE processed_run_id = ?",
        (run_id,),
    ).fetchone()
    listings_reviewed = int(processed_count_row["count"])
    if searches_opened:
        start_mode = "opened_dropship_calendar"
    elif listings_reviewed:
        start_mode = "resumed_queued_ebay_results"
    else:
        start_mode = "no_ebay_work_recorded"

    source_rows = conn.execute(
        """
        SELECT DISTINCT sp.*
        FROM search_tasks st
        JOIN seed_products sp ON sp.id = st.seed_product_id
        WHERE st.run_id_started = ?
        ORDER BY sp.source_store_name, sp.id
        """,
        (run_id,),
    ).fetchall()
    products = [dict(row) for row in source_rows]
    stores_by_key: dict[tuple[str | None, str | None], dict[str, Any]] = {}
    for product in products:
        key = (product.get("source_store_name"), product.get("source_store_dc_shop_id"))
        store = stores_by_key.setdefault(
            key,
            {
                "name": product.get("source_store_name"),
                "dropship_calendar_shop_id": product.get("source_store_dc_shop_id"),
                "url": dropship_calendar_shop_url(product.get("source_store_dc_shop_id")),
                "products_selected": 0,
                "products": [],
            },
        )
        store["products_selected"] += 1
        store["products"].append(
            {
                "title": product.get("amazon_title") or product.get("ebay_title"),
                "dropship_calendar_product_id": product.get("dc_product_id"),
                "amazon_url": product.get("supplier_url"),
                "source_ebay_url": product.get("source_ebay_url"),
                "profit": product.get("profit"),
                "lifetime_sales": product.get("lifetime_sales"),
                "members_listed": product.get("members_listed"),
            }
        )

    result_status_this_run = {
        row["status"]: int(row["count"])
        for row in conn.execute(
            """
            SELECT status, COUNT(*) AS count
            FROM search_results
            WHERE processed_run_id = ?
            GROUP BY status
            """,
            (run_id,),
        ).fetchall()
    }
    if task_ids:
        placeholders = _task_id_placeholders(task_ids)
        task_result_counts = {
            row["status"]: int(row["count"])
            for row in conn.execute(
                f"""
                SELECT status, COUNT(*) AS count
                FROM search_results
                WHERE search_task_id IN ({placeholders})
                GROUP BY status
                """,
                tuple(task_ids),
            ).fetchall()
        }
        listings_saved = sum(task_result_counts.values())
        remaining_queued = task_result_counts.get("queued", 0)
    else:
        task_result_counts = {}
        listings_saved = 0
        remaining_queued = 0

    candidate_count_row = conn.execute(
        "SELECT COUNT(DISTINCT store_id) AS count FROM candidate_listings WHERE run_id = ?",
        (run_id,),
    ).fetchone()
    sellers_recorded = int(candidate_count_row["count"])

    check_rows = conn.execute(
        """
        SELECT
          qc.*,
          s.seller_username,
          s.store_name,
          s.store_url,
          s.feedback_count,
          s.feedback_percent,
          s.visible_sold_results_count,
          s.store_lifetime_items_sold,
          s.notes
        FROM qualification_checks qc
        JOIN stores s ON s.id = qc.store_id
        WHERE qc.run_id IS ?
        ORDER BY lower(s.seller_username), qc.check_name
        """,
        (run_id,),
    ).fetchall()
    sellers_by_id: dict[int, dict[str, Any]] = {}
    for row in check_rows:
        store_id = int(row["store_id"])
        seller = sellers_by_id.setdefault(
            store_id,
            {
                "store_id": store_id,
                "username": row["seller_username"],
                "store_name": row["store_name"],
                "store_url": row["store_url"],
                "seller_url": seller_search_url(row["seller_username"]),
                "seller_sold_url": seller_sold_url(row["seller_username"]),
                "feedback_count": row["feedback_count"],
                "feedback_percent": row["feedback_percent"],
                "visible_sold_results_count": row["visible_sold_results_count"],
                "store_lifetime_items_sold": row["store_lifetime_items_sold"],
                "notes": row["notes"],
                "checks": {},
            },
        )
        seller["checks"][row["check_name"]] = {
            "result": row["result"],
            "observed_value": row["observed_value"],
            "evidence_note": row["evidence_note"],
        }

    sellers = []
    for seller in sellers_by_id.values():
        check_results = {name: value["result"] for name, value in seller["checks"].items()}
        status = _run_status_from_checks(run, check_results)
        candidate = conn.execute(
            """
            SELECT *
            FROM candidate_listings
            WHERE run_id = ? AND store_id = ?
            ORDER BY created_at, id
            LIMIT 1
            """,
            (run_id, seller["store_id"]),
        ).fetchone()
        screenshot = conn.execute(
            """
            SELECT file_path, source_url
            FROM screenshots
            WHERE entity_type = 'store'
              AND entity_id = ?
              AND screenshot_type = 'seller_sold_page'
            ORDER BY captured_at DESC, id DESC
            LIMIT 1
            """,
            (seller["store_id"],),
        ).fetchone()
        seller.update(
            {
                "status": status,
                "matching_listing_url": candidate["listing_url"] if candidate else None,
                "matching_listing_title": candidate["listing_title"] if candidate else None,
                "matching_listing_price": candidate["listing_price"] if candidate else None,
                "quality_summary": _seller_quality_line(seller, seller["checks"]),
                "screenshot_path": screenshot["file_path"] if screenshot else None,
                "screenshot_source_url": screenshot["source_url"] if screenshot else None,
            }
        )
        sellers.append(seller)

    sellers.sort(key=lambda item: (item["status"] != "qualified", item["username"].lower()))
    status_counts = {
        status: sum(1 for seller in sellers if seller["status"] == status)
        for status in ("qualified", "manual_review", "rejected", "blocked")
    }
    qualified = [seller for seller in sellers if seller["status"] == "qualified"]
    qualified_preview = qualified[:seller_limit]

    return {
        "run": run,
        "outcome": {
            "summary": (
                f"found {status_counts['qualified']} qualified seller"
                + ("" if status_counts["qualified"] == 1 else "s")
            )
            if status_counts["qualified"]
            else "no qualified sellers found",
            "status_counts": status_counts,
        },
        "start_mode": start_mode,
        "dropship_calendar": {
            "source_stores_used": list(stores_by_key.values()),
            "source_stores_used_count": len(stores_by_key),
            "products_selected": len(products),
        },
        "ebay": {
            "searches_opened": searches_opened,
            "search_tasks": search_tasks,
            "listings_saved_for_review": listings_saved,
            "listings_reviewed_this_run": listings_reviewed,
            "listings_rejected_this_run": result_status_this_run.get("rejected", 0),
            "listings_skipped_this_run": result_status_this_run.get("skipped", 0),
            "listings_qualified_this_run": result_status_this_run.get("qualified", 0),
            "remaining_queued": remaining_queued,
            "result_status_counts_for_touched_searches": task_result_counts,
            "result_status_counts_this_run": result_status_this_run,
        },
        "seller_review": {
            "sellers_recorded": sellers_recorded,
            "sellers_deep_reviewed": len(sellers),
            "qualified_total": len(qualified),
            "qualified": qualified_preview,
            "qualified_remaining": max(0, len(qualified) - len(qualified_preview)),
            "all_reviewed_sellers": sellers,
        },
        "safety": {
            "blocker_type": run.get("blocker_type"),
            "blocker_detail": run.get("blocker_detail"),
            "dropship_calendar_mutation": "none_recorded",
        },
    }


def iter_required_checks() -> Iterable[str]:
    return REQUIRED_CHECKS
