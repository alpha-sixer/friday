from __future__ import annotations

import sqlite3
from pathlib import Path


DEFAULT_DB_PATH = Path("data/friday.sqlite3")
SCHEMA_VERSION = 5

SEED_PRODUCT_ADDED_COLUMNS = {
    "claimed_run_id": "INTEGER REFERENCES runs(id)",
    "claimed_at": "TEXT",
    "amazon_image_url": "TEXT",
    "ebay_image_url": "TEXT",
    "source_image_url": "TEXT",
    "source_image_role": "TEXT NOT NULL DEFAULT 'amazon'",
    "seed_title_match_result": "TEXT",
    "seed_image_match_result": "TEXT",
    "seed_visual_evidence_note": "TEXT",
}


def connect(db_path: Path = DEFAULT_DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    if db_path != Path(":memory:"):
        conn.execute("PRAGMA journal_mode = WAL")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA_SQL)
    _ensure_columns(conn, "seed_products", SEED_PRODUCT_ADDED_COLUMNS)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_seed_products_claim ON seed_products(claimed_run_id, claimed_at)")
    conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
    conn.commit()


def _ensure_columns(conn: sqlite3.Connection, table_name: str, columns: dict[str, str]) -> None:
    existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall()}
    for column_name, column_sql in columns.items():
        if column_name not in existing:
            conn.execute(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {column_sql}")


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY,
  run_type TEXT NOT NULL DEFAULT 'manual',
  status TEXT NOT NULL DEFAULT 'running',
  started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at TEXT,
  target_count INTEGER,
  qualified_count INTEGER NOT NULL DEFAULT 0,
  manual_review_count INTEGER NOT NULL DEFAULT 0,
  rejected_count INTEGER NOT NULL DEFAULT 0,
  blocked_count INTEGER NOT NULL DEFAULT 0,
  blocker_type TEXT,
  blocker_detail TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS seed_products (
  id INTEGER PRIMARY KEY,
  dc_product_id TEXT,
  source_store_name TEXT,
  source_store_dc_shop_id TEXT,
  amazon_asin TEXT,
  ebay_item_id TEXT,
  amazon_title TEXT,
  ebay_title TEXT,
  supplier_url TEXT,
  source_ebay_url TEXT,
  amazon_retail_price REAL,
  dc_ebay_price REAL,
  profit REAL,
  members_listed INTEGER,
  lifetime_sales INTEGER,
  status TEXT NOT NULL DEFAULT 'unseen',
  used_at TEXT,
  claimed_run_id INTEGER REFERENCES runs(id),
  claimed_at TEXT,
  discovery_run_id INTEGER REFERENCES runs(id),
  search_query_used TEXT,
  search_source TEXT NOT NULL DEFAULT 'amazon_title',
  skip_reason TEXT,
  duplicate_of_id INTEGER REFERENCES seed_products(id),
  image_path TEXT,
  amazon_image_url TEXT,
  ebay_image_url TEXT,
  source_image_url TEXT,
  source_image_role TEXT NOT NULL DEFAULT 'amazon',
  seed_title_match_result TEXT,
  seed_image_match_result TEXT,
  seed_visual_evidence_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(dc_product_id)
);

CREATE TABLE IF NOT EXISTS stores (
  id INTEGER PRIMARY KEY,
  seller_username TEXT NOT NULL,
  normalized_username TEXT NOT NULL UNIQUE,
  store_name TEXT,
  store_url TEXT,
  feedback_count INTEGER,
  feedback_percent REAL,
  active_listing_count INTEGER,
  visible_sold_results_count INTEGER,
  store_lifetime_items_sold INTEGER,
  status TEXT NOT NULL DEFAULT 'seen',
  status_reason TEXT,
  first_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS search_tasks (
  id INTEGER PRIMARY KEY,
  seed_product_id INTEGER NOT NULL REFERENCES seed_products(id),
  run_id_started INTEGER REFERENCES runs(id),
  search_source TEXT NOT NULL DEFAULT 'amazon_title',
  search_query TEXT,
  search_url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued', 'in_progress', 'partial', 'exhausted', 'blocked')),
  stop_reason TEXT CHECK(stop_reason IS NULL OR stop_reason IN ('target_reached', 'page_exhausted', 'blocked', 'manual_stop')),
  last_processed_rank INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(seed_product_id, search_url)
);

CREATE TABLE IF NOT EXISTS search_results (
  id INTEGER PRIMARY KEY,
  search_task_id INTEGER NOT NULL REFERENCES search_tasks(id),
  page_number INTEGER NOT NULL DEFAULT 1,
  rank INTEGER NOT NULL,
  ebay_item_id TEXT,
  listing_url TEXT,
  seller_username TEXT,
  normalized_seller_username TEXT,
  title TEXT,
  price REAL,
  image_url TEXT,
  sponsored INTEGER NOT NULL DEFAULT 0,
  feedback_count INTEGER,
  feedback_percent REAL,
  status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued', 'processing', 'candidate', 'qualified', 'rejected', 'skipped')),
  reason_code TEXT,
  candidate_listing_id INTEGER REFERENCES candidate_listings(id),
  processed_run_id INTEGER REFERENCES runs(id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(search_task_id, page_number, rank),
  UNIQUE(search_task_id, ebay_item_id),
  UNIQUE(search_task_id, listing_url)
);

CREATE TABLE IF NOT EXISTS candidate_listings (
  id INTEGER PRIMARY KEY,
  seed_product_id INTEGER REFERENCES seed_products(id),
  store_id INTEGER NOT NULL REFERENCES stores(id),
  run_id INTEGER REFERENCES runs(id),
  search_result_rank INTEGER,
  sponsored INTEGER NOT NULL DEFAULT 0,
  ebay_item_id TEXT,
  listing_url TEXT,
  card_title TEXT,
  card_price REAL,
  card_image_url TEXT,
  listing_title TEXT,
  listing_price REAL,
  condition TEXT,
  seller_text TEXT,
  card_feedback_count INTEGER,
  card_feedback_percent REAL,
  title_match_result TEXT,
  image_match_result TEXT,
  price_above_retail_result TEXT,
  evidence_note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(ebay_item_id),
  UNIQUE(listing_url)
);

CREATE TABLE IF NOT EXISTS seller_sold_items (
  id INTEGER PRIMARY KEY,
  store_id INTEGER NOT NULL REFERENCES stores(id),
  run_id INTEGER REFERENCES runs(id),
  rank INTEGER,
  title TEXT,
  price REAL,
  item_url TEXT,
  image_url TEXT,
  category_text TEXT,
  sold_date_text TEXT,
  raw_text TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(store_id, run_id, rank)
);

CREATE TABLE IF NOT EXISTS screenshots (
  id INTEGER PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id INTEGER,
  screenshot_type TEXT NOT NULL,
  file_path TEXT NOT NULL,
  source_url TEXT,
  captured_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS qualification_checks (
  id INTEGER PRIMARY KEY,
  store_id INTEGER NOT NULL REFERENCES stores(id),
  run_id INTEGER REFERENCES runs(id),
  check_name TEXT NOT NULL,
  result TEXT NOT NULL CHECK(result IN ('pass', 'fail', 'unknown')),
  observed_value TEXT,
  threshold TEXT,
  evidence_note TEXT,
  candidate_listing_id INTEGER REFERENCES candidate_listings(id),
  screenshot_id INTEGER REFERENCES screenshots(id),
  assessed_by TEXT NOT NULL DEFAULT 'manual',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(store_id, run_id, check_name)
);

CREATE TABLE IF NOT EXISTS exports (
  id INTEGER PRIMARY KEY,
  file_path TEXT NOT NULL,
  item_count INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS export_items (
  id INTEGER PRIMARY KEY,
  export_id INTEGER NOT NULL REFERENCES exports(id),
  store_id INTEGER NOT NULL REFERENCES stores(id),
  seller_username TEXT NOT NULL,
  store_url TEXT,
  status_at_export TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(export_id, store_id)
);

CREATE TABLE IF NOT EXISTS store_handoffs (
  id INTEGER PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'confirmed', 'cancelled')),
  requested_count INTEGER,
  item_count INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  confirmed_at TEXT,
  cancelled_at TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS store_handoff_items (
  id INTEGER PRIMARY KEY,
  handoff_id INTEGER NOT NULL REFERENCES store_handoffs(id),
  store_id INTEGER NOT NULL REFERENCES stores(id),
  seller_username TEXT NOT NULL,
  store_url TEXT,
  status_at_handoff TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(handoff_id, store_id)
);

CREATE INDEX IF NOT EXISTS idx_seed_products_status ON seed_products(status);
CREATE INDEX IF NOT EXISTS idx_stores_status ON stores(status);
CREATE INDEX IF NOT EXISTS idx_search_tasks_status ON search_tasks(status);
CREATE INDEX IF NOT EXISTS idx_search_tasks_seed_status ON search_tasks(seed_product_id, status);
CREATE INDEX IF NOT EXISTS idx_search_results_queue ON search_results(status, search_task_id, page_number, rank);
CREATE INDEX IF NOT EXISTS idx_search_results_task_status ON search_results(search_task_id, status);
CREATE INDEX IF NOT EXISTS idx_candidate_listings_store ON candidate_listings(store_id);
CREATE INDEX IF NOT EXISTS idx_candidate_listings_seed ON candidate_listings(seed_product_id);
CREATE INDEX IF NOT EXISTS idx_sold_items_store_run ON seller_sold_items(store_id, run_id);
CREATE INDEX IF NOT EXISTS idx_checks_store_run ON qualification_checks(store_id, run_id);
CREATE INDEX IF NOT EXISTS idx_screenshots_entity ON screenshots(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_store_handoffs_status ON store_handoffs(status);
CREATE UNIQUE INDEX IF NOT EXISTS idx_store_handoffs_one_pending ON store_handoffs(status) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS idx_store_handoff_items_store ON store_handoff_items(store_id);
"""
