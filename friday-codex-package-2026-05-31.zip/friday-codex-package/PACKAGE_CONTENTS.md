# Friday Codex Package Contents

Send this whole package folder or the generated zip file to the recipient.

## Included

- `friday/pyproject.toml`
- `friday/uv.lock`
- `friday/src/friday/`
- `friday/tests/`
- `friday/docs/scouting/`
- `friday/friday-plan.md`
- `codex-skill/friday/SKILL.md`
- `scripts/install_codex_skill.sh`
- `INSTALL_FOR_CODEX_AGENT.md`

## Excluded

- Local SQLite databases.
- Evidence screenshots and scraped run artifacts.
- Browser state.
- Virtual environments.
- Pytest cache.
- Temporary run files.

## Recipient Quick Start

```bash
unzip friday-codex-package-2026-05-31.zip
cd friday-codex-package
bash scripts/install_codex_skill.sh "$HOME/Desktop/friday"
```

After installation, restart Codex if needed and ask:

```text
$friday status
```
