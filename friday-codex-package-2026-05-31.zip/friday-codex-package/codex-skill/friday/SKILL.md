---
name: friday
description: Use this in Codex for Dropship Calendar and eBay dropship seller discovery with the local Friday CLI. Trigger for requests like $friday status, find target=1, find target=10, scout-store store=barfire, handoff target=10, handoff all, handoff-confirm, export-approved, queued search result resume, and seller evidence recording. Never use the eBay API and never add sellers to Dropship Calendar automatically.
---

# Friday

## Mission

Find eBay dropshipping seller candidates from Dropship Calendar seed products using browser-only research and the local `friday` CLI for every durable write.

Workspace:

```bash
cd __FRIDAY_WORKSPACE__
```

Use these project references only when needed:

- `__FRIDAY_WORKSPACE__/friday-plan.md`
- `__FRIDAY_WORKSPACE__/docs/scouting/dc-item-finder.md`
- `__FRIDAY_WORKSPACE__/docs/scouting/ebay-discovery.md`

## Invocation

Codex explicit skill invocation uses `$friday`, not an OpenClaw slash command.

Supported prompts:

```text
$friday status
$friday scout-store store=barfire
$friday find target=1
$friday find target=10
$friday handoff target=10
$friday handoff all
$friday handoff-confirm handoff=123
$friday handoff-cancel handoff=123
$friday export-approved
```

For `find`, parse `target=N` from the prompt. If omitted, use `target=1`.
For `handoff`, parse `target=N` from the prompt. If omitted, use `target=10`. If the prompt asks for `all`, `entire list`, or `everything`, use `--all` instead of `--limit`.

## Hard Rules

- Use the Codex app browser/browser automation for Dropship Calendar and eBay. Do not invoke an OpenClaw agent or OpenClaw slash command from this skill.
- Do not use the eBay API.
- Do not auto-add sellers to Dropship Calendar.
- Do not click Dropship Calendar destructive or mutating controls unless the user explicitly approves that exact action.
- Unsafe controls include `Bulk remove`, per-shop `Refresh`, per-shop `Delete`, `Automator`, `Customize Automator`, `Add to Import List`, `Add selected to import list`, and Add Shops submit.
- If you run into captcha, handle it and proceed with the run. Most of the captcha you run into don't require handling anyway. If you see "Pardon our interruption" or clear indicator that the type of captcha is just a browser check and redirect is expected shortly, wait it out. Do not abort the run.
- Record every important decision in SQLite through `uv run friday ...`; do not rely on chat memory.
- Keep cached search-result processing state in SQLite. Never repeat processed results just because cards are visible again.
- Never mark stores as `manually_added_to_dc` unless the user explicitly confirms they manually added the exact pending handoff batch to Dropship Calendar.
- Multiple Codex agents may be running Friday. Treat SQLite as the only source of truth for queue ownership and seen sellers.
- Before opening any eBay seed search URL or running `search start`, atomically claim the seed with `uv run friday seed claim --run-id "$RUN_ID" --dc-product-id "$DC_PRODUCT_ID"`. If the claim output does not return that seed with `claimed_run_id` equal to the current run, do not use that seed.
- `search start` is an ownership gate. If it says the seed must be claimed or is claimed by another run, stop using that seed and choose another claimed seed instead of retrying browser work.
- Never process a queued eBay result from `search next`; `search next` is read-only/debug only. Use `search claim` and process only rows returned by that claim.
- Before opening a candidate listing page, seller page, or seller sold page, check whether the seller is already known with `uv run friday store show --seller "$SELLER" --json`.
- If `store show` returns `exists=true`, the seller is not a new discovery. Do not qualify, assess, hand off, or add that seller from the current search result unless the user explicitly asks to repair/enrich that exact existing seller record.
- If an already-known seller appears in a claimed search result, mark the result `skipped` with the returned `recommended_result_reason_code` (`seller_seen` or `qualified_elsewhere`) and move on.

## Browser Visibility And Login Handoff

- Friday browser work uses the Codex app browser and may run in the background unless login, account warning, blocked state, or any user handoff is needed.
- Before asking the user to log in to Dropship Calendar, make the Codex browser visible with the Browser visibility capability: `await (await browser.capabilities.get("visibility")).set(true)`.
- Do not ask the user to log in unless the visible browser is already open on the Dropship Calendar login page or the page requiring login.
- Do not type or submit the user's Dropship Calendar credentials.
- When login is required, stop after making the login page visible and send: `I have opened the Dropship Calendar login page in the visible Codex browser. Please log in manually, then tell me when to continue.`
- After the user confirms login is complete, verify the session by confirming the dashboard or Item Finder page is visible before continuing.
- If the login page cannot be made visible, record a `login_wall` blocker and stop the run instead of continuing invisibly.

## Standard Preflight

From `__FRIDAY_WORKSPACE__`, run this before workflow commands:

```bash
uv run friday init-db
uv run friday status --json
uv run friday checks
```

For `status`, report store counts, seed counts, latest run status, blockers, queued search work, and the next concrete action.

## Find Workflow

For `$friday find target=N`, use this bounded v1 workflow.

1. Start a discovery run:

```bash
RUN_ID=$(uv run friday record run-start --type discovery --target-count "$TARGET" --notes "Codex Friday run")
```

2. Mandatory visible checkpoint before browser navigation:

```bash
uv run friday search preflight --limit 1
```

Send a standalone Codex commentary message with one of these short summaries before opening a browser page, calling `uv run friday search claim`, or making durable writes beyond run creation.

For queued work:

```text
Starting run $RUN_ID. I found queued search results from search task $SEARCH_TASK_ID for seed $DC_PRODUCT_ID, "$SEED_TITLE". I will resume at result $SEARCH_RESULT_ID/rank $RANK for seller $SELLER before opening any new Dropship Calendar seed. $QUEUED_COUNT queued cards remain.
```

For no queued work:

```text
Starting run $RUN_ID. No queued search results found, so I will open Dropship Calendar Item Finder and select a new eligible seed.
```

This checkpoint is not an approval pause. It means the summary must be visibly sent first, then continue unless a blocker exists.

3. Atomically claim cached queue work before processing it:

```bash
uv run friday search claim --limit "$MAX_CANDIDATES_PER_SEED"
```

4. If claimed results exist, process only those claimed rows before opening a new Dropship Calendar seed. If another agent claimed the row shown by preflight first, follow the actual `claim` output, not the stale preflight lookahead.
5. If no queued results exist, open Dropship Calendar Item Finder only after confirming login/session state. If login is required, follow Browser Visibility And Login Handoff before selecting any seed.
6. Select and record an eligible seed product that has no non-exhausted search task, extracting from up to `max_source_stores=3` if needed.
7. Before opening eBay for that product, atomically claim the exact seed:

```bash
uv run friday seed claim --run-id "$RUN_ID" --dc-product-id "$DC_PRODUCT_ID"
```

The returned JSON must include the seed and show `claimed_run_id` equal to `$RUN_ID`. If `seeds` is empty, or the returned seed is not claimed by this run, another agent owns or used it. Do not open the eBay URL, do not run `search start`, and choose another eligible seed.

8. For each claimed seed search, use the Dropship Calendar product card search dropdown:
   - primary: `SEARCH ON EBAY` -> `Use Amazon title`
   - use `SEARCH ON EBAY` -> `Use eBay title` only when the Amazon title is missing, broken, or clearly unrelated before opening an Amazon-title eBay search
9. Open the Dropship Calendar generated eBay URL exactly as provided only after the seed claim succeeds.
10. Create or resume a search task after opening the eBay discovery search:

```bash
uv run friday search start --dc-product-id "$DC_PRODUCT_ID" --run-id "$RUN_ID" --search-url "$SEARCH_URL" --search-query "$SEARCH_QUERY" --search-source amazon_title
```

If and only if the Amazon title was missing, broken, or clearly unrelated before opening any Amazon-title eBay search, use the eBay-title URL and set `--search-source ebay_title`.

If `search start` fails because the seed is unclaimed, claimed by another run, or already has a non-exhausted search task, stop using that seed immediately and claim a different eligible seed.

11. If eBay auto-corrects the query, use the visible exact-query link and keep that final URL/query in the search task.
12. If the Amazon-title eBay search returns zero real listing cards, do not fall back to the eBay title. Mark the product skipped and select another eligible product:

```bash
uv run friday search no-results --search-task-id "$SEARCH_TASK_ID" --run-id "$RUN_ID"
```

The skipped product reason must be `amazon_title_zero_results`. Do not start an `ebay_title` search task for that product after this condition.

13. Extract every real first-page eBay listing card into lean JSON and cache it before deeper vetting:

```bash
uv run friday search cache-results --search-task-id "$SEARCH_TASK_ID" --json-file /path/to/search-results.json
```

Search result card fields:

- `rank` required
- `page_number` default `1`
- `listing_url`
- `ebay_item_id`
- `seller_username`
- `title`
- `price`
- `image_url`
- `sponsored`
- `feedback_count`
- `feedback_percent`

Do not include processed statuses in cache payloads. `cache-results` is only for queued cards; use `mark-result` for candidate/rejected/skipped/qualified.

14. Skip fake placeholder cards like `Shop on eBay`; keep sponsored listing cards in scope.
15. Process claimed cached results from SQLite, not from chat memory or visible cards.
16. Skip source-store self-matches before recording candidates: normalized candidate seller must not equal the seed `source_store_name`.
17. Skip source-listing self-matches before recording candidates: candidate item ID parsed from `ebay_item_id` or `listing_url` must not equal the seed eBay item ID or item ID parsed from `source_ebay_url`.
18. Check seller seen state before opening listing/seller pages or recording a candidate:

```bash
uv run friday store show --seller "$SELLER" --json
```

If `exists=true`, do not deep-vet that seller as new. Mark the claimed result skipped using the payload's `recommended_result_reason_code`:

```bash
uv run friday search mark-result --search-result-id "$SEARCH_RESULT_ID" --status skipped --reason-code "$REASON_CODE" --run-id "$RUN_ID"
```

19. Mark every processed claimed result:

```bash
uv run friday search mark-result --search-result-id "$SEARCH_RESULT_ID" --status rejected --reason-code title_mismatch --run-id "$RUN_ID"
```

Allowed result statuses are `candidate`, `qualified`, `rejected`, and `skipped` for processed cards. Rejected/skipped cards require a reason code.
If `mark-result` says the result is already processed, stop processing that row; another agent got there first.

Agent visual comparison responsibility:

- The agent must personally inspect the seed product image and each promising eBay result-card image in the browser before opening the seller sold page.
- Do not infer image match from title, category, price, search rank, or eBay query relevance.
- Do not rely only on cached `image_url` text. The image must be visually loaded or visible in the browser, screenshot, or equivalent browser-rendered image context.
- A cached result is promising only after the agent compares the visible result-card image against the seed product image and determines it is clearly the same product.
- Exact same photo is not required. Different angle, crop, background, or lighting can pass only if the product identity is clear.
- Treat material differences in size, count, color, model, included parts, shape, or use case as mismatches unless listing-page evidence resolves them.
- If the card image is missing, broken, too small, obscured, or ambiguous, open the listing page only for same-product confirmation. If the listing image still does not clearly match the seed product, reject the result with `image_mismatch`.
- Before recording `same_product_match=pass`, the evidence note must state the visible features that matched, for example: `visible card/listing image matches seed: same 55 inch rope saw, dual handles, coiled rope, 70-tooth chain layout`.

20. Open promising listing pages only after agent visual pre-vetting confirms plausible same-product title, visible same-product image, price above Amazon retail, non-source seller/listing, and `store show exists=false`. Seller sold-page vetting is not allowed until listing-page title and image confirmation pass.
21. Build seller sold-page URLs from seller username only:

```text
https://www.ebay.com/sch/i.html?_dkr=1&iconV2Request=true&_blrs=recall_filtering&_ssn={seller_username}&_oac=1&LH_Sold=1
```

22. Record seller stats, sold-item samples, screenshots, qualification checks, and assessment.
23. If target is reached while queued results remain, finish the search task as partial:

```bash
uv run friday search finish --search-task-id "$SEARCH_TASK_ID" --status partial --stop-reason target_reached
```

24. If all cached first-page results are processed and no claimed rows remain in `processing`, finish the search task as exhausted:

```bash
uv run friday search finish --search-task-id "$SEARCH_TASK_ID" --status exhausted --stop-reason page_exhausted
```

If `search finish --status exhausted` refuses because queued or processing results remain, claim/process those rows or leave the task partial; do not force exhaustion.

25. Finish the run:

```bash
uv run friday record run-finish --run-id "$RUN_ID" --status finished
```

26. Build the final report payload before responding to the user:

```bash
uv run friday report run --run-id "$RUN_ID" --json
```

On blocker:

```bash
uv run friday record run-finish --run-id "$RUN_ID" --status blocked
uv run friday report run --run-id "$RUN_ID" --json
```

Allowed blocker types are `login_wall`, `account_warning`, `blocked_state`, and `ambiguous_destructive_action`.

## Find Final Funnel Report

For every completed or blocked `$friday find` run, use the JSON from:

```bash
uv run friday report run --run-id "$RUN_ID" --json
```

Render a concise user-facing Funnel Report. Prefer beginner-friendly labels over database terms:

- Say `product selected` instead of `seed`.
- Say `dropshipping store reviewed` or `verified dropshipping store on eBay` instead of `candidate`.
- Do not mention row IDs, search task IDs, seed IDs, candidate IDs, or run IDs in the main report unless the user asks for debugging details.
- Always include `No sellers were added to Dropship Calendar.` unless the user explicitly approved a Dropship Calendar mutation.
- Hyperlink stores, sellers, listings, and screenshot paths when the report payload provides URLs or paths.
- Show at most the first `10` verified dropshipping stores on eBay. If more verified stores exist, add `+ N more verified dropshipping stores not shown`.
- Keep seller reasons short: feedback/sold-result volume, same-product listing, and mixed inventory are enough for the main report.
- The `Discovery funnel:` section must contain at most `5` bullets. Prefer exactly the five high-signal bullets in the default shape when the data exists.
- Do not include low-signal debug fields in the main funnel: run ID, normal completed status, target count, row IDs, search task IDs, seed IDs, candidate IDs, or separate one-field count bullets.
- Combine related counts into one bullet instead of splitting them across multiple bullets.
- If a blocker stopped the run, lead with the blocker and the next required user action, then include whatever funnel counts are available.

Default final shape:

```text
Run complete: found {outcome.status_counts.qualified} verified dropshipping stores on eBay.

Discovery funnel:
- Starting point: {resumed pending eBay listings / opened a new Dropship Calendar product / resumed pending eBay listings, then opened a new Dropship Calendar product}.
- Product selected: {products_selected} from [store](url) / {product title}.
- eBay searches opened: {count}; {short search-path note if useful}.
- Listings reviewed: {reviewed} reviewed, {qualified} qualified, {rejected} rejected.
- Outcome: {qualified_total} verified dropshipping stores found; {remaining_queued} listings remain queued for the next run.

Verified dropshipping stores on eBay:
1. [store](seller_url) via [matching listing](listing_url) - short reason
2. ...
+ N more verified dropshipping stores not shown.

Evidence:
- Screenshot: [seller sold page](path)

No sellers were added to Dropship Calendar.
```

Omit empty sections. For example, if there are no verified dropshipping stores on eBay, omit `Verified dropshipping stores on eBay:`. If no new Dropship Calendar product was selected, omit the `Product selected:` bullet and keep the funnel to `4` bullets rather than adding filler. If a run both resumes pending eBay work and later opens a new Dropship Calendar product, say that in the single `Starting point:` bullet.

## Candidate And Evidence Recording

Check seller seen state before any deep seller work:

```bash
uv run friday store show --seller "$SELLER" --json
```

Rules for this check:

- Run it after source-store/source-listing self-match checks and before opening the candidate listing page, seller page, or sold page.
- `exists=false` means the seller can be treated as a new discovery.
- `exists=true` means the seller has already been seen in Friday. Do not record a new candidate, qualification checks, assessment, approval, or handoff for that seller from this result.
- For an already-seen seller, mark the claimed search result `skipped` with the payload's `recommended_result_reason_code`.
- Only enrich an existing seller when the user explicitly asks to repair or continue that exact seller record; do not infer this from seeing the seller again in search results.

Record or enrich stores:

```bash
uv run friday record store --json-file /path/to/store.json
```

Record candidate listings:

```bash
uv run friday record candidate --json-file /path/to/candidate.json
```

Record first sold-page sample items:

```bash
uv run friday record sold-item --json-file /path/to/sold-items.json
```

Seller sold-page visual review requirement:

- Before passing `mixed_non_niche_inventory`, inspect the first `30` real sold-result cards on the seller sold page.
- Use the sold-card product images plus titles/categories. Do not pass this gate from category sidebar/filter labels alone.
- Record sold-page samples for the reviewed cards with `rank`, `title`, `item_url`, `image_url` when available, `category_text` or inferred visual product type, `sold_date_text`, and `raw_text`.
- `mixed_non_niche_inventory` means broad-retail diversity, not variety within one vertical.
- Pass `mixed_non_niche_inventory` only when the first `30` reviewed sold-card images/titles show at least `3` broad retail macro categories.
- Broad retail macro categories include examples like home/kitchen, beauty/personal care, toys/games, books/media, electronics, pet supplies, tools/hardware, apparel, and automotive/motors.
- Subtypes inside one vertical do not count as separate macro categories.
- Examples that must fail `mixed_non_niche_inventory`: motorcycle parts, ATV parts, UTV parts, powersports gear, tires, chain lube, grips, guards, helmets, racing apparel, Harley parts, auto parts, truck accessories, vehicle fluids, vehicle lighting, vehicle tools, different sizes/colors/models of one product family, different brands inside one vertical, or mostly one eBay top-level department such as eBay Motors.
- For this gate, motorcycle, ATV, UTV, auto, racing, powersports, tires, vehicle fluids, and vehicle accessories count as the same macro category: `automotive/motors`.
- Do not pass a seller as mixed inventory just because the first sold cards include different product types within `automotive/motors`. A tire, brake pad, chain lube, helmet, hand guard, and ATV part are still one macro category.
- Set the gate `observed-value` in this form: `reviewed 30 sold-card images from ranks 1-30; macro categories: automotive/motors, home/kitchen, pet supplies`.
- If the seller fails, write the reason plainly, for example: `reviewed 30 sold-card images from ranks 1-30; macro categories: automotive/motors only; fail because varied motors products are still one macro category`.
- Before recording `mixed_non_niche_inventory=pass`, ask: "Would a human describe this seller as a general retail dropshipper, or as a niche seller?" Use that answer as a sanity check before passing the gate. If the macro-category evidence and the human-readable store description conflict, mark the gate `unknown` instead of forcing a pass.
- If fewer than `30` real sold-card images are inspectable, mark `mixed_non_niche_inventory` as `unknown` unless code enforcement is updated to support a narrower manual-review exception.
- Before passing `catalog_stock_photo_style`, use candidate-listing images and the same reviewed sold-card images/titles to judge whether the seller uses retail catalog or stock-photo-style listings.

Candidate listing fields to capture when visible:

- `seller_username`
- `dc_product_id`
- `run_id`
- `search_result_rank`
- `sponsored`
- `ebay_item_id`
- `listing_url`
- `card_title`
- `card_price`
- `card_image_url`
- `listing_title`
- `listing_price`
- `condition`
- `seller_text`
- `card_feedback_count`
- `card_feedback_percent`
- `title_match_result`
- `image_match_result`
- `price_above_retail_result`
- `evidence_note`

Save screenshots under:

```text
__FRIDAY_WORKSPACE__/data/evidence/YYYY-MM-DD/run-{RUN_ID}/
```

Save the browser screenshot file to disk before recording the DB row. Verify the path is non-empty with `test -s "$SCREENSHOT_PATH"` or rely on `uv run friday record screenshot` to fail. If screenshot recording fails, do not claim the screenshot was recorded.

```bash
uv run friday record screenshot --entity-type store --entity-id "$STORE_ID" --screenshot-type seller_sold_page --file-path "$SCREENSHOT_PATH" --source-url "$SOURCE_URL"
```

## Required Gates

Record all gates before assessing:

- `not_source_store`
- `same_product_match`
- `price_above_amazon_retail`
- `seller_feedback_100_plus`
- `visible_sold_results_100_plus`
- `mixed_non_niche_inventory`
- `catalog_stock_photo_style`
- `no_blocker`

Gate command:

```bash
uv run friday record check --seller "$SELLER" --run-id "$RUN_ID" --check same_product_match --result pass --observed-value "title and image match seed" --evidence-note "short note" --assessed-by codex
```

Then assess:

```bash
uv run friday assess --seller "$SELLER" --run-id "$RUN_ID" --json
```

Status rules are deterministic: blocker -> `blocked`; any failed gate -> `rejected`; all gates pass -> `qualified`; otherwise `manual_review`.

## Scout Store

For `$friday scout-store store=barfire`:

1. Open Dropship Calendar Item Finder.
2. Confirm login/session state. If login is required, make the Codex browser visible, stop on the visible login page, and ask the user to log in manually.
3. Search shops using real keyboard events, not only programmatic value changes.
4. Open the matching shop product page.
5. Use controlled scrolling because product cards are virtualized.
6. Extract visible `article.product-card` data after each scroll.
7. Dedupe products by `input[name="selectedProducts"]`.
8. Record eligible seeds with `uv run friday record seed --json-file ...`.

Seed visual-source requirements:

- Record a seed only after the agent personally inspects the rendered Amazon/supplier image and the rendered source eBay image on the Dropship Calendar product card.
- The canonical seed image is the Amazon/supplier image, because the Amazon product is the product being searched for across eBay sellers.
- Do not use the source eBay image as the canonical seed image. Use it only as secondary evidence that Dropship Calendar matched the Amazon/eBay pair correctly.
- Record `amazon_image_url`, `ebay_image_url`, `source_image_url`, `source_image_role`, `seed_title_match_result`, `seed_image_match_result`, and `seed_visual_evidence_note` for every eligible seed.
- `source_image_url` must be the same rendered image URL as `amazon_image_url`, and `source_image_role` must be `amazon`.
- `seed_image_match_result` must be `pass` before a seed is eligible. If the Amazon and source eBay images are missing, broken, ambiguous, or only same-category rather than same-product, do not record the seed as eligible.
- The evidence note must state the visible Amazon/eBay image features that matched, for example: `Amazon and source eBay images show the same rope saw: coiled rope, dual handles, long chain blade, orange throw weight`.

Record seeds with positive profit, lifetime sales greater than `1`, clear Amazon/eBay title and image match, supplier link, eBay listing/search reference, Members Listed `0`, and the required Amazon canonical image evidence. Allow but downrank `Not listed`, no `Sold 30d`, and Members Listed greater than `0`.

## Approval And Export

Qualified sellers still require manual approval:

```bash
uv run friday approve --seller "$SELLER" --note "approved after evidence review"
```

For `$friday export-approved`:

```bash
uv run friday export
```

Export marks approved sellers as `exported`. Do not enter them into Dropship Calendar automatically.

## Manual Dropship Calendar Handoff

Use this when the user asks for stores to manually add to Dropship Calendar, asks for the next `N` stores, asks for the entire list of unused stores, or asks to mark a shown batch added/used.

Create a pending handoff without changing store statuses:

```bash
uv run friday handoff create --limit "$TARGET" --json
```

For all currently qualified stores:

```bash
uv run friday handoff create --all --json
```

If a pending handoff already exists, do not create a duplicate. Show it instead:

```bash
uv run friday handoff show --pending --json
```

Render the pending handoff as a concise list of sellers with eBay seller links, matching listing links, quality summaries, and screenshot links when present. Tell the user that the stores are not marked added yet.

After the user explicitly confirms that they manually added the exact pending handoff batch to Dropship Calendar, mark that batch added:

```bash
uv run friday handoff confirm --handoff-id "$HANDOFF_ID" --json
```

If the user says they did not add the batch or wants to discard it:

```bash
uv run friday handoff cancel --handoff-id "$HANDOFF_ID" --json
```

Handoff status rules:

- `handoff create` selects only stores with status `qualified`.
- `handoff create` is serialized by SQLite and excludes any store that already appeared in a confirmed handoff, even if a bad later write put the store back into `qualified`.
- `handoff create` does not mark stores used, added, approved, or exported.
- `handoff confirm` marks every store in that exact pending batch as `manually_added_to_dc`.
- `handoff confirm` refuses to confirm a store that is no longer `qualified` or that was already confirmed in another handoff.
- Future handoffs must exclude `manually_added_to_dc`, `approved`, `exported`, `rejected`, and every non-`qualified` store by selecting only `qualified`.
- Do not run `handoff confirm` from implication, vague acknowledgement, or because the user asked for a list. Require explicit confirmation that the user manually added the shown stores.
