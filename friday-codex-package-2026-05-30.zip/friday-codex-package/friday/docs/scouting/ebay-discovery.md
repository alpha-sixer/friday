# eBay Discovery Scouting Report

Date: 2026-05-27

Purpose: map the eBay side of the Friday workflow. This report covers the handoff from Dropship Calendar search links, first-page eBay result vetting, listing-page confirmation, seller sold-page construction, and seller-level qualification signals.

## Scope

This scouting pass used a real seed product from Dropship Calendar's `barfire` store:

- Dropship Calendar store: `barfire`
- Dropship Calendar store route: `/dashboard/item-finder/shops/4027`
- Dropship Calendar product ID: `163875`
- eBay title: `16.4FT Peel and Stick Molding & Wall Trim, Flexible Self-Adhesive Decorative Str`
- Amazon title: `Gaahing 16.4FT Peel and Stick Molding & Wall Trim, Flexible Self-Adhesive Decorative Strip for Tile, Mirror, Ceiling, Floor, Panel, Cabinet`
- Dropship Calendar eBay price: `$10.84`
- Amazon retail price: `$5.99`
- Profit: `$2.23`
- Members Listed: `4`
- Lifetime Sales: `6`

## Search Entrypoint

Primary search path:

- Open the Dropship Calendar product card.
- Open the card's `Search` dropdown.
- Use `SEARCH ON EBAY -> Use Amazon title`.

Observed generated eBay URL:

```text
https://www.ebay.com/sch/i.html?_nkw=Gaahing%2016.4FT%20Peel%20and%20Stick%20Molding%20%26%20Wall%20Trim%2C%20Flexible%20Self-Adhesive%20Decorative%20Strip%20for%20Tile%2C%20Mirror%2C%20Ceiling%2C%20Floor%2C%20Panel%2C%20Cabinet
```

Automation rule:

- Use the DC-generated URL exactly as the primary search URL.
- Do not assume the raw DC link is broken.
- If eBay returns a transient error page, retry once.
- If eBay auto-corrects the query, use the visible `Search instead for...` exact-query link.
- If needed, fallback to the same search with `_blrs=spell_auto_correct`.

Exact-query fallback form:

```text
https://www.ebay.com/sch/i.html?_nkw={encoded_amazon_title}&_blrs=spell_auto_correct
```

Observed eBay auto-correction behavior:

- A shortened query `Gaahing 16.4FT Peel and Stick Molding` was auto-corrected by eBay to `gaming 16.4ft peel and stick molding`.
- eBay showed a `Search instead for Gaahing 16.4FT Peel and Stick Molding` link.
- Using the exact-search link removed the correction and returned exact-query results.

## Search Results Page

Observed page title:

- `Gaahing 16.4FT Peel and Stick Molding & Wall Trim, Flexible Self-Adhesive Decorative Strip for Tile, Mirror, Ceiling, Floor, Panel, Cabinet for sale | eBay`

Observed result count:

- `577 results` for the full Amazon-title exact query during scouting.
- Result counts can vary by time, location, filters, personalization, and eBay UI changes.

Important visible controls:

- Header search input: `Search for anything`
- Include description checkbox
- Category filter rail
- Buy It Now / Auction filter
- Condition filter
- Item Location filter
- Sort control

Initial automation should avoid changing filters. The first version should inspect the first default search results page only.

## Result Card Structure

Observed real result-card selector:

```css
li.s-card.s-card--horizontal
```

Observed useful child selectors:

```css
a.s-card__link
.s-card__title
.s-card__price
img
```

Fake marketplace placeholder cards may also use similar card styling. Skip cards where the title/text is `Shop on eBay` or the item URL is a fake placeholder such as `/itm/123456`.

Data to extract from each real first-page card:

- result rank
- sponsored flag
- listing title
- listing URL
- eBay item ID
- listing price
- image URL
- seller username, when visible
- feedback percent, when visible
- feedback count, when visible
- condition, when visible
- shipping text, when visible
- location text, when visible
- watcher/sold snippet, when visible

Observed seller text format on result cards:

```text
thecorner2010 99.5% positive (13.1K)
```

Extraction note:

- Seller username can often be parsed from the result-card seller text.
- If the result card does not expose the seller username reliably, open the listing page before seller-level vetting.

## First-Page Vetting Workflow

The v1 workflow should cache every real listing card on the first eBay results page generated from the Amazon title before deeper vetting. Cached cards make a seed search resumable when a run reaches its target before the page is exhausted.

Before browser navigation in a find run, run `friday search preflight --limit 1`. If it returns `resume_queue`, briefly state the search task, seed, next queued result/rank/seller, and queued count before opening eBay. If it returns `new_seed`, briefly state that no queued search results exist and Dropship Calendar Item Finder will be opened for a new seed.

Per-card flow:

1. Skip fake placeholder cards.
2. Keep sponsored cards in scope.
3. Extract card-level fields.
4. Cache cards as `search_results` with page number, rank, title, listing URL, item ID, seller, price, image URL, feedback, and sponsored flag.
5. Dedupe by item ID and seller username when available.
6. Reject source-store self-matches before recording: candidate seller must not equal the seed source store.
7. Reject source-listing self-matches before recording: candidate item ID/listing URL must not equal the seed eBay item ID/source URL.
8. Compare image to the seed product.
9. Compare title to the Amazon seed title.
10. Compare price to the Amazon retail price and Dropship Calendar eBay price.
11. Pre-score the card.
12. Open only cards that pass the card threshold or need visual confirmation.
13. Mark every processed cached card as `candidate`, `qualified`, `rejected`, or `skipped`.

Card-level qualification signals:

- Image clearly matches the same product.
- Title clearly describes the same product.
- Candidate seller/listing is not the source seller/listing that supplied the seed.
- Listing price is above the Amazon retail price.
- Listing price is near the Dropship Calendar eBay price.
- Seller feedback count is over `100`.
- Feedback percent is acceptable, ideally `98%+`.

Card-level rejection signals:

- Product image mismatch.
- Product title mismatch.
- Candidate seller or listing is the same source seller/listing that supplied the seed.
- Listing price below Amazon retail.
- Feedback count under `100`, unless manually reviewed.
- Placeholder card or non-product card.

Queue status behavior:

- `partial`: target was reached with queued cards remaining; resume this task before new seed searches.
- `exhausted`: cached first-page cards were depleted.
- `blocked`: captcha, login wall, warning, blocked state, or destructive-action ambiguity interrupted the search.
- Resume-first runs may start on an eBay listing or seller page instead of Dropship Calendar when queued `search_results` exist. That is correct only when the preflight summary is announced first.

Useful result reason codes:

- `source_store_self_match`
- `source_listing_self_match`
- `title_mismatch`
- `image_mismatch`
- `price_below_retail`
- `feedback_under_100`
- `placeholder_card`
- `seller_seen`
- `qualified_elsewhere`

## Example Candidate: `thecorner2010`

First strong candidate found from the Gaahing seed:

- Seller username: `thecorner2010`
- Store name resolved by eBay: `TheCorner1`
- Result card title: `Gaahing 16.4FT Peel and Stick Molding & Wall Trim, Flexible Self-Adhesive Decora`
- Result card price: `$8.88`
- Result card seller text: `thecorner2010 99.5% positive (13.1K)`
- Result card image: gold coil trim product, visually matching the seed
- Candidate listing URL: `https://www.ebay.com/itm/257385269240`

Why this card passed scouting:

- Image match: clear same product.
- Title match: clear same product.
- Price: `$8.88`, above Amazon retail `$5.99`.
- Price is close enough to Dropship Calendar eBay price `$10.84`.
- Feedback count is far above `100`.
- Feedback percent is strong at `99.5%`.

## Listing Page Confirmation

Observed candidate listing page:

- URL: `https://www.ebay.com/itm/257385269240`
- Title: `Gaahing 16.4FT Peel and Stick Molding & Wall Trim, Flexible Self-Adhesive Decora`
- Price: `US $8.88`
- Seller/store display: `TheCorner1`
- Seller feedback count: `13137`
- Seller feedback percent: `99.5% positive`
- Quantity observed: `2 available`
- Listing sold quantity observed: `4 sold`
- Condition: `New`

Observed listing-page selectors/areas:

```css
#RightSummaryPanel
.right-summary-panel-container
#mainContent
```

Useful listing-page extraction strategy:

- Scope title, seller, price, condition, quantity, and sold snippets to `#RightSummaryPanel` when present.
- Use listing-page links to confirm the store name and feedback URL.
- Feedback URLs can expose the seller username as `username={seller_username}`.

Important note:

- The listing page may show sponsored "similar items" above the actual listing details. Do not treat those as the candidate listing.
- The actual candidate details were visible in the right summary panel.

## Seller Sold Page

Use seller username, not store name, to construct the seller sold page.

Recommended URL template:

```text
https://www.ebay.com/sch/i.html?_dkr=1&iconV2Request=true&_blrs=recall_filtering&_ssn={seller_username}&_oac=1&LH_Sold=1
```

Observed working example:

```text
https://www.ebay.com/sch/i.html?_dkr=1&iconV2Request=true&_blrs=recall_filtering&_ssn=thecorner2010&_oac=1&LH_Sold=1
```

Do not require `store_name` in v1.

Reason:

- Store names can differ from seller usernames.
- eBay correctly resolved `_ssn=thecorner2010` to the store header `TheCorner1`.
- Requiring or guessing `store_name` adds a mismatch risk.

## Seller Sold Page Signals

Observed seller sold page title:

- `Items for sale by thecorner2010 | eBay`

Observed store header:

- Store name: `TheCorner1`
- Positive feedback: `99.5% positive feedback`
- Store lifetime items sold: `21K items sold`
- Followers: `892 followers`
- Visit store link: `https://www.ebay.com/str/thecorner1`

Observed sold-page result count:

- `2,000+ results`

Observed active listing count:

- Store search input placeholder: `Search all 7,172 items`

Derived metric:

```text
visible_sold_through = visible_sold_results_count / active_listing_count
```

For `thecorner2010`:

```text
visible_sold_through = 2,000+ / 7,172 = at least 27.9%
```

Naming rule:

- Do not call this lifetime sell-through.
- eBay's `LH_Sold=1` result count is an eBay-visible sold-results count, not guaranteed lifetime history.
- Track `store_lifetime_items_sold` separately from the store header, such as `21K items sold`.

## Broad Category Signal

Observed category spread for `thecorner2010` sold page included:

- Home & Garden
- Health & Beauty
- Business & Industrial
- eBay Motors
- Pet Supplies
- Movies & TV
- Sporting Goods
- Art & Craft Supplies
- Books & Magazines
- Consumer Electronics

This broad category spread is a strong dropshipper signal when combined with:

- high sold-results count
- high active-listings count
- stock-photo/product-catalog look
- many unrelated product categories
- consistent Buy It Now retail-style listings

## Sold Result Examples

Visible sold examples from `thecorner2010` showed varied categories and stock-photo-style product cards:

- `Camaro SS Logo Black Tire Stem Valve Caps`
- `Battat - Stacking Toy - Educational & Dexterity Toy - Nesting Cup Playset`
- `21st Century C 500 Mg Tablets, 110 Count`
- `The Yellow Wallpaper`
- `L'Oreal Paris Colorista Hair Bleach`
- `Hell Or High Water [DVD]`

These examples support a broad catalog signal rather than a narrow specialist seller signal.

## Scoring Implications

Card-level scoring should happen before opening listing pages.

Recommended card-level boosts:

- clear image match
- clear title match
- listing price above Amazon retail
- listing price near Dropship Calendar eBay price
- seller feedback count over `100`
- feedback percent `98%+`

Recommended seller-level boosts:

- sold results `150+`
- active listings `500+`
- visible sold-through `10%+`
- broad category spread
- stock-photo/product-catalog look
- store lifetime items sold `1000+`
- feedback percent `98%+`

Recommended hard rejects or heavy penalties:

- price below Amazon retail
- image mismatch
- title mismatch
- feedback under `100`
- feedback percent under `95%`
- narrow personal/auction/used-item pattern

## Evidence Requirements

For each approved seller, save:

- eBay search result screenshot or focused result-card screenshot when practical
- candidate listing page screenshot
- seller sold page screenshot

Persist these references:

- DC source store
- DC product ID
- Amazon title search URL
- search result rank
- eBay item ID
- seller username
- store URL if resolved
- score breakdown
- screenshot paths

## Open Questions

- Whether result-card classes stay stable across logged-out/logged-in eBay sessions.
- Whether mobile/narrow viewport changes result-card seller visibility.
- Whether eBay hides seller text for some categories or personalization states.
- Whether all first-page cards should be opened when card-level seller username is missing, or only visually strong matches.
- Whether pagination should be enabled in v2 for seeds with unusually strong first-page yield.

## Current Recommendation

Use a bounded first-page workflow for v1:

- one seed product
- one Amazon-title eBay search
- all real first-page listing cards
- card-level pre-score
- listing-page confirmation for promising cards
- seller sold-page vetting by `_ssn`
- approved sellers exported locally for manual Dropship Calendar addition

Do not add pagination until first-page extraction, dedupe, scoring, and evidence capture are reliable.
