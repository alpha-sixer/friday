# Dropship Calendar Item Finder Notes

Use this file as lightweight context for the Codex browser portion of Friday. The authoritative workflow is the Friday skill.

## Login

- Entry URL: `https://autopilot.dropshipcalendar.io`
- If a login page appears, make the Codex browser visible and ask the user to log in manually.
- Do not type, store, or submit user credentials.
- After login, confirm the dashboard or Item Finder page is visible before continuing.

## Item Finder

Typical route:

- `/dashboard/item-finder`

Common visible controls:

- `Item Finder` left navigation link.
- `Search shops` textbox.
- `Sort shops` button.
- `Add shops` button.
- Shop cards with links to product pages.
- Per-shop `More actions` menu.

Unsafe controls:

- `Bulk remove`
- per-shop `Refresh`
- per-shop `Delete`
- `Automator`
- `Customize Automator`
- `Add to Import List`
- `Add selected to import list`
- Add Shops submit

Do not click unsafe controls without explicit approval for that exact action.

## Shop Product Pages

Product cards may be virtualized, so controlled scrolling is often required. Extract only visible read-only product data.

Eligible seed products should have:

- Positive profit.
- Lifetime sales greater than `1`.
- Clear Amazon/eBay title match.
- Clear Amazon/eBay image match.
- Supplier link.
- eBay listing/search reference.
- Members Listed `0` preferred.

The canonical seed image is the rendered Amazon/supplier image, not the source eBay image. Use the source eBay image only as secondary evidence that Dropship Calendar matched the pair correctly.

Record seed evidence with:

- `amazon_image_url`
- `ebay_image_url`
- `source_image_url`
- `source_image_role`
- `seed_title_match_result`
- `seed_image_match_result`
- `seed_visual_evidence_note`

## eBay Search Entrypoint

For each eligible product card:

1. Open the product card search dropdown.
2. Prefer `SEARCH ON EBAY` -> `Use Amazon title`.
3. Use `Use eBay title` only when the Amazon title is missing, broken, or clearly unrelated before opening an Amazon-title search.
4. Open the generated eBay URL exactly as provided.
5. Record or resume the search task with `uv run friday search start ...`.

## Browser Handling

- Use real keyboard events for search fields when possible.
- Wait for visible list/card changes after search or pagination actions.
- If eBay or Dropship Calendar shows a browser-check page, wait for it to resolve.
- If a real blocker remains, record the blocker through the CLI and stop the run.

