from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer

from .core import (
    FridayError,
    approve_store,
    assess_store,
    cache_search_results,
    cancel_store_handoff,
    confirm_store_handoff,
    coerce_items,
    create_run,
    create_store_handoff,
    explain_seed as explain_seed_core,
    export_approved,
    finish_search_task,
    finish_run,
    handoff_report,
    iter_required_checks,
    load_json_file,
    mark_search_no_results,
    mark_seed_used,
    mark_search_result,
    next_search_results,
    record_blocker,
    record_check as record_qualification_check,
    record_screenshot as record_screenshot_row,
    reject_store,
    run_report,
    search_preflight,
    start_search_task,
    status_summary,
    upsert_candidate,
    upsert_seed,
    upsert_sold_item,
    upsert_store,
)
from .db import DEFAULT_DB_PATH, connect, init_db as create_schema


app = typer.Typer(help="Friday local CLI.")
record_app = typer.Typer(help="Record run, seed, seller, evidence, and gate data.")
search_app = typer.Typer(help="Create, cache, resume, and finish eBay search tasks.")
explain_app = typer.Typer(help="Explain Friday DB state for a seed or entity.")
report_app = typer.Typer(help="Build user-facing run reports.")
handoff_app = typer.Typer(help="Prepare and confirm manual Dropship Calendar store handoffs.")
app.add_typer(record_app, name="record")
app.add_typer(search_app, name="search")
app.add_typer(explain_app, name="explain")
app.add_typer(report_app, name="report")
app.add_typer(handoff_app, name="handoff")


def _connect(db_path: Path):
    conn = connect(db_path)
    return conn


def _print_payload(payload, as_json: bool = False) -> None:
    if as_json:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
    elif isinstance(payload, str):
        typer.echo(payload)
    else:
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))


def _handle_error(exc: Exception) -> None:
    if isinstance(exc, FridayError):
        raise typer.BadParameter(str(exc))
    raise exc


@app.command("init-db")
def init_db(
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Create or update the local SQLite schema."""
    conn = _connect(db)
    create_schema(conn)
    typer.echo(f"initialized {db}")


@app.command()
def status(
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(False, "--json", help="Print JSON."),
) -> None:
    """Show run, seed, and store status counts."""
    conn = _connect(db)
    _print_payload(status_summary(conn), json_output)


@app.command()
def assess(
    seller: str = typer.Option(..., "--seller", help="Seller username."),
    run_id: int = typer.Option(..., "--run-id", help="Run id."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(False, "--json", help="Print JSON."),
) -> None:
    """Evaluate required gates and update seller status."""
    conn = _connect(db)
    try:
        result = assess_store(conn, seller, run_id)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(
        {
            "seller_username": result.seller_username,
            "run_id": result.run_id,
            "status": result.status,
            "reason": result.reason,
            "checks": dict(result.checks),
        },
        json_output,
    )


@app.command()
def approve(
    seller: str = typer.Option(..., "--seller", help="Seller username."),
    note: Optional[str] = typer.Option(None, "--note", help="Approval note."),
    force: bool = typer.Option(False, "--force", help="Approve even if not qualified."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Mark a qualified seller approved for export."""
    conn = _connect(db)
    try:
        approve_store(conn, seller, note=note, force=force)
    except Exception as exc:
        _handle_error(exc)
    typer.echo(f"approved {seller}")


@app.command()
def reject(
    seller: str = typer.Option(..., "--seller", help="Seller username."),
    reason: str = typer.Option(..., "--reason", help="Rejection reason."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Manually reject a seller."""
    conn = _connect(db)
    try:
        reject_store(conn, seller, reason)
    except Exception as exc:
        _handle_error(exc)
    typer.echo(f"rejected {seller}")


@app.command()
def export(
    out: Optional[Path] = typer.Option(None, "--out", help="CSV output path."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Export notes."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Export approved sellers to CSV and mark them exported."""
    if out is None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        out = Path("data/exports") / f"approved-{stamp}.csv"
    conn = _connect(db)
    export_id = export_approved(conn, out, notes=notes)
    typer.echo(f"exported batch {export_id} to {out}")


@handoff_app.command("create")
def handoff_create(
    limit: Optional[int] = typer.Option(10, "--limit", help="Number of qualified stores to include."),
    include_all: bool = typer.Option(False, "--all", help="Include every currently qualified store."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Handoff notes."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Create a pending manual-add handoff without changing store statuses."""
    conn = _connect(db)
    try:
        payload = create_store_handoff(conn, limit=limit, include_all=include_all, notes=notes)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@handoff_app.command("show")
def handoff_show(
    handoff_id: Optional[int] = typer.Option(None, "--handoff-id", help="Handoff id. Defaults to latest."),
    pending: bool = typer.Option(False, "--pending", help="Show the latest pending handoff."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Show a handoff batch and its stores."""
    conn = _connect(db)
    try:
        payload = handoff_report(conn, handoff_id=handoff_id, pending=pending)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@handoff_app.command("confirm")
def handoff_confirm(
    handoff_id: int = typer.Option(..., "--handoff-id", help="Pending handoff id."),
    note: Optional[str] = typer.Option(None, "--note", help="Confirmation note."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Mark all stores in a pending handoff manually added to Dropship Calendar."""
    conn = _connect(db)
    try:
        payload = confirm_store_handoff(conn, handoff_id=handoff_id, note=note)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@handoff_app.command("cancel")
def handoff_cancel(
    handoff_id: int = typer.Option(..., "--handoff-id", help="Pending handoff id."),
    note: Optional[str] = typer.Option(None, "--note", help="Cancellation note."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Cancel a pending handoff without changing store statuses."""
    conn = _connect(db)
    try:
        payload = cancel_store_handoff(conn, handoff_id=handoff_id, note=note)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@report_app.command("run")
def report_run(
    run_id: int = typer.Option(..., "--run-id", help="Run id."),
    seller_limit: int = typer.Option(10, "--seller-limit", help="Max qualified sellers to include in preview."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Build a funnel report for one discovery run."""
    conn = _connect(db)
    try:
        payload = run_report(conn, run_id=run_id, seller_limit=seller_limit)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@report_app.command("latest")
def report_latest(
    seller_limit: int = typer.Option(10, "--seller-limit", help="Max qualified sellers to include in preview."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
    json_output: bool = typer.Option(True, "--json/--no-json", help="Print JSON."),
) -> None:
    """Build a funnel report for the latest run."""
    conn = _connect(db)
    try:
        payload = run_report(conn, seller_limit=seller_limit)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, json_output)


@record_app.command("run-start")
def record_run_start(
    run_type: str = typer.Option("manual", "--type", help="Run type."),
    target_count: Optional[int] = typer.Option(None, "--target-count", help="Target qualified seller count."),
    notes: Optional[str] = typer.Option(None, "--notes", help="Run notes."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Create a run row and print its id."""
    conn = _connect(db)
    run_id = create_run(conn, run_type=run_type, target_count=target_count, notes=notes)
    typer.echo(str(run_id))


@record_app.command("run-finish")
def record_run_finish(
    run_id: int = typer.Option(..., "--run-id", help="Run id."),
    status: str = typer.Option("finished", "--status", help="Final run status."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Mark a run finished."""
    conn = _connect(db)
    finish_run(conn, run_id, status=status)
    typer.echo(f"finished run {run_id}")


@record_app.command("seed")
def record_seed(
    json_file: Path = typer.Option(..., "--json-file", help="Seed JSON object or array."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Upsert seed product rows from JSON."""
    conn = _connect(db)
    try:
        ids = [upsert_seed(conn, item) for item in coerce_items(load_json_file(json_file))]
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"seed_ids": ids}))


@record_app.command("seed-used")
def record_seed_used(
    dc_product_id: str = typer.Option(..., "--dc-product-id", help="Dropship Calendar product id."),
    run_id: int = typer.Option(..., "--run-id", help="Discovery run id."),
    search_query_used: str = typer.Option(..., "--search-query", help="Exact eBay search query or URL opened."),
    search_source: Optional[str] = typer.Option(None, "--search-source", help="amazon_title, ebay_title, or other source label."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Mark a seed used after its eBay discovery search starts."""
    conn = _connect(db)
    try:
        seed_id = mark_seed_used(
            conn,
            dc_product_id=dc_product_id,
            run_id=run_id,
            search_query_used=search_query_used,
            search_source=search_source,
        )
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"seed_id": seed_id, "status": "used"}))


@record_app.command("store")
def record_store(
    json_file: Path = typer.Option(..., "--json-file", help="Store JSON object or array."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Upsert seller/store rows from JSON."""
    conn = _connect(db)
    try:
        ids = [upsert_store(conn, item) for item in coerce_items(load_json_file(json_file))]
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"store_ids": ids}))


@record_app.command("candidate")
def record_candidate(
    json_file: Path = typer.Option(..., "--json-file", help="Candidate listing JSON object or array."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Upsert candidate listing rows from JSON."""
    conn = _connect(db)
    try:
        ids = [upsert_candidate(conn, item) for item in coerce_items(load_json_file(json_file))]
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"candidate_ids": ids}))


@record_app.command("sold-item")
def record_sold_item(
    json_file: Path = typer.Option(..., "--json-file", help="Sold item JSON object or array."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Upsert first sold-page sample rows from JSON."""
    conn = _connect(db)
    try:
        ids = [upsert_sold_item(conn, item) for item in coerce_items(load_json_file(json_file))]
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"sold_item_ids": ids}))


@record_app.command("check")
def record_check(
    seller: str = typer.Option(..., "--seller", help="Seller username."),
    run_id: int = typer.Option(..., "--run-id", help="Run id."),
    check: str = typer.Option(..., "--check", help="Gate name."),
    result: str = typer.Option(..., "--result", help="pass, fail, or unknown."),
    observed_value: Optional[str] = typer.Option(None, "--observed-value", help="Observed value."),
    threshold: Optional[str] = typer.Option(None, "--threshold", help="Threshold override."),
    evidence_note: Optional[str] = typer.Option(None, "--evidence-note", help="Evidence note."),
    candidate_listing_id: Optional[int] = typer.Option(None, "--candidate-listing-id", help="Candidate listing id."),
    screenshot_id: Optional[int] = typer.Option(None, "--screenshot-id", help="Screenshot id."),
    assessed_by: str = typer.Option("manual", "--assessed-by", help="manual, codex, or cli."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Record one qualification gate result."""
    conn = _connect(db)
    try:
        check_id = record_qualification_check(
            conn,
            seller_username=seller,
            run_id=run_id,
            check_name=check,
            result=result,
            observed_value=observed_value,
            threshold=threshold,
            evidence_note=evidence_note,
            candidate_listing_id=candidate_listing_id,
            screenshot_id=screenshot_id,
            assessed_by=assessed_by,
        )
    except Exception as exc:
        _handle_error(exc)
    typer.echo(str(check_id))


@record_app.command("screenshot")
def record_screenshot(
    entity_type: str = typer.Option(..., "--entity-type", help="Entity type."),
    file_path: str = typer.Option(..., "--file-path", help="Screenshot file path."),
    screenshot_type: str = typer.Option("evidence", "--screenshot-type", help="Screenshot type."),
    entity_id: Optional[int] = typer.Option(None, "--entity-id", help="Entity row id."),
    source_url: Optional[str] = typer.Option(None, "--source-url", help="Source URL."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Record a screenshot path."""
    conn = _connect(db)
    try:
        screenshot_id = record_screenshot_row(
            conn,
            {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "screenshot_type": screenshot_type,
                "file_path": file_path,
                "source_url": source_url,
            },
        )
    except Exception as exc:
        _handle_error(exc)
    typer.echo(str(screenshot_id))


@record_app.command("blocker")
def record_blocker_command(
    run_id: int = typer.Option(..., "--run-id", help="Run id."),
    blocker_type: str = typer.Option(..., "--type", help="Blocker type."),
    detail: Optional[str] = typer.Option(None, "--detail", help="Blocker detail."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Record a captcha/login/warning/blocked run state."""
    conn = _connect(db)
    try:
        record_blocker(conn, run_id=run_id, blocker_type=blocker_type, detail=detail)
    except Exception as exc:
        _handle_error(exc)
    typer.echo(f"blocked run {run_id}: {blocker_type}")


@search_app.command("start")
def search_start(
    dc_product_id: str = typer.Option(..., "--dc-product-id", help="Dropship Calendar product id."),
    run_id: int = typer.Option(..., "--run-id", help="Discovery run id."),
    search_url: str = typer.Option(..., "--search-url", help="Exact eBay search URL opened."),
    search_query: Optional[str] = typer.Option(None, "--search-query", help="Human-readable search query."),
    search_source: str = typer.Option("amazon_title", "--search-source", help="amazon_title, ebay_title, or other source label."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Create or resume a search task for a seed/query."""
    conn = _connect(db)
    try:
        task_id = start_search_task(
            conn,
            dc_product_id=dc_product_id,
            run_id=run_id,
            search_url=search_url,
            search_query=search_query,
            search_source=search_source,
        )
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"search_task_id": task_id}))


@search_app.command("cache-results")
def search_cache_results(
    search_task_id: int = typer.Option(..., "--search-task-id", help="Search task id."),
    json_file: Path = typer.Option(..., "--json-file", help="Search result card JSON object or array."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Cache eBay search result cards before deeper vetting."""
    conn = _connect(db)
    try:
        ids = cache_search_results(conn, search_task_id, coerce_items(load_json_file(json_file)))
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"search_result_ids": ids}))


@search_app.command("next")
def search_next(
    limit: int = typer.Option(10, "--limit", help="Max queued search results to return."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Return queued results, preferring partial search tasks."""
    conn = _connect(db)
    _print_payload({"search_results": next_search_results(conn, limit=limit)}, as_json=True)


@search_app.command("preflight")
def search_preflight_command(
    limit: int = typer.Option(1, "--limit", help="Queued result lookahead for preflight summary."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Summarize whether discovery will resume queued work or open a new seed."""
    conn = _connect(db)
    _print_payload(search_preflight(conn, limit=limit), as_json=True)


@search_app.command("mark-result")
def search_mark_result(
    search_result_id: int = typer.Option(..., "--search-result-id", help="Search result row id."),
    status: str = typer.Option(..., "--status", help="queued, processing, candidate, qualified, rejected, or skipped."),
    reason_code: Optional[str] = typer.Option(None, "--reason-code", help="Reason code for rejected/skipped results."),
    run_id: Optional[int] = typer.Option(None, "--run-id", help="Run that processed this result."),
    candidate_listing_id: Optional[int] = typer.Option(None, "--candidate-listing-id", help="Linked candidate listing id."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Mark one cached result processed."""
    conn = _connect(db)
    try:
        result_id = mark_search_result(
            conn,
            search_result_id=search_result_id,
            status=status,
            reason_code=reason_code,
            run_id=run_id,
            candidate_listing_id=candidate_listing_id,
        )
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"search_result_id": result_id, "status": status}))


@search_app.command("finish")
def search_finish(
    search_task_id: int = typer.Option(..., "--search-task-id", help="Search task id."),
    status: str = typer.Option(..., "--status", help="queued, in_progress, partial, exhausted, or blocked."),
    stop_reason: Optional[str] = typer.Option(None, "--stop-reason", help="target_reached, page_exhausted, blocked, or manual_stop."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Finish or pause a search task."""
    conn = _connect(db)
    try:
        task_id = finish_search_task(conn, search_task_id=search_task_id, status=status, stop_reason=stop_reason)
    except Exception as exc:
        _handle_error(exc)
    typer.echo(json.dumps({"search_task_id": task_id, "status": status}))


@search_app.command("no-results")
def search_no_results(
    search_task_id: int = typer.Option(..., "--search-task-id", help="Amazon-title search task id."),
    run_id: int = typer.Option(..., "--run-id", help="Run that observed zero eBay results."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Mark an Amazon-title search with zero eBay results and skip its product."""
    conn = _connect(db)
    try:
        task_id = mark_search_no_results(conn, search_task_id=search_task_id, run_id=run_id)
    except Exception as exc:
        _handle_error(exc)
    typer.echo(
        json.dumps(
            {
                "search_task_id": task_id,
                "status": "exhausted",
                "seed_status": "skipped",
                "skip_reason": "amazon_title_zero_results",
            }
        )
    )


@explain_app.command("seed")
def explain_seed_command(
    dc_product_id: str = typer.Option(..., "--dc-product-id", help="Dropship Calendar product id."),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="SQLite database path."),
) -> None:
    """Explain seed search/candidate state."""
    conn = _connect(db)
    try:
        payload = explain_seed_core(conn, dc_product_id=dc_product_id)
    except Exception as exc:
        _handle_error(exc)
    _print_payload(payload, as_json=True)


@app.command("checks")
def checks() -> None:
    """List required qualification gates."""
    for check in iter_required_checks():
        typer.echo(check)


if __name__ == "__main__":
    app()
