from __future__ import annotations

import csv
import json
import sqlite3

import pytest
from typer.testing import CliRunner

from friday.cli import app
from friday.core import (
    FridayError,
    REQUIRED_CHECKS,
    approve_store,
    assess_store,
    cache_search_results,
    cancel_store_handoff,
    confirm_store_handoff,
    create_run,
    create_store_handoff,
    explain_seed,
    export_approved,
    finish_search_task,
    handoff_report,
    mark_seed_used,
    mark_search_no_results,
    mark_search_result,
    next_search_results,
    record_blocker,
    record_check,
    record_screenshot,
    reject_store,
    run_report,
    search_preflight,
    start_search_task,
    status_summary,
    upsert_candidate,
    upsert_seed,
    upsert_sold_item,
    upsert_store,
)
from friday.db import connect, init_db


@pytest.fixture()
def conn() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    init_db(db)
    return db


def make_store_run(conn: sqlite3.Connection, seller: str = "thecorner2010") -> tuple[str, int]:
    run_id = create_run(conn, run_type="test")
    upsert_store(conn, {"seller_username": seller, "feedback_count": 13137})
    return seller, run_id


def seed_payload(dc_product_id: str = "seed-1", **overrides) -> dict:
    item_id = 900000000000 + sum(ord(char) for char in dc_product_id)
    payload = {
        "dc_product_id": dc_product_id,
        "amazon_title": "Seed Amazon Product",
        "ebay_title": "Seed eBay Product",
        "supplier_url": f"https://www.amazon.com/dp/{dc_product_id}",
        "source_ebay_url": f"https://www.ebay.com/itm/{item_id}",
        "amazon_image_url": f"https://m.media-amazon.com/images/I/{dc_product_id}.jpg",
        "ebay_image_url": f"https://i.ebayimg.com/images/g/{dc_product_id}/s-l500.webp",
        "source_image_url": f"https://m.media-amazon.com/images/I/{dc_product_id}.jpg",
        "source_image_role": "amazon",
        "seed_title_match_result": "pass",
        "seed_image_match_result": "pass",
        "seed_visual_evidence_note": "Rendered Amazon and source eBay images show the same product features.",
    }
    payload.update(overrides)
    if "amazon_image_url" in overrides and "source_image_url" not in overrides:
        payload["source_image_url"] = overrides["amazon_image_url"]
    return payload


def record_candidate_evidence(
    conn: sqlite3.Connection,
    seller: str,
    run_id: int,
    *,
    dc_product_id: str = "seed-1",
) -> int:
    upsert_seed(conn, seed_payload(dc_product_id))
    return upsert_candidate(
        conn,
        {
            "seller_username": seller,
            "dc_product_id": dc_product_id,
            "run_id": run_id,
            "ebay_item_id": str(800000000000 + run_id),
            "listing_url": f"https://www.ebay.com/itm/{800000000000 + run_id}",
            "card_title": "Matching seed product",
            "card_price": 42.0,
            "card_image_url": "https://i.ebayimg.com/images/g/candidate/s-l500.webp",
            "listing_title": "Matching seed product",
            "listing_price": 42.0,
            "title_match_result": "pass",
            "image_match_result": "pass",
            "price_above_retail_result": "pass",
            "evidence_note": "Visible card/listing image matches seed: same shape, parts, and product layout.",
        },
    )


def record_sold_visual_samples(
    conn: sqlite3.Connection,
    seller: str,
    run_id: int,
    *,
    count: int = 30,
    macro_categories: list[str] | None = None,
    start_rank: int = 1,
) -> None:
    macro_categories = macro_categories or ["home/kitchen", "electronics", "pet supplies"]
    for offset in range(count):
        rank = start_rank + offset
        macro_category = macro_categories[offset % len(macro_categories)]
        upsert_sold_item(
            conn,
            {
                "seller_username": seller,
                "run_id": run_id,
                "rank": rank,
                "title": f"{macro_category} sold sample {rank}",
                "price": 10.0 + rank,
                "item_url": f"https://www.ebay.com/itm/{100000000000 + rank}",
                "image_url": f"https://i.ebayimg.com/images/g/sample-{rank}/s-l500.webp",
                "category_text": macro_category,
                "sold_date_text": "Sold May 28, 2026",
            },
        )


def record_all(conn: sqlite3.Connection, seller: str, run_id: int, result: str = "pass") -> None:
    if result == "pass":
        record_candidate_evidence(conn, seller, run_id)
        record_sold_visual_samples(conn, seller, run_id)
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, result, assessed_by="test")


def store_status(conn: sqlite3.Connection, seller: str) -> str:
    row = conn.execute(
        "SELECT status FROM stores WHERE normalized_username = lower(?)",
        (seller,),
    ).fetchone()
    return row["status"]


def test_all_required_checks_pass_qualifies(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_all(conn, seller, run_id)

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "qualified"
    assert store_status(conn, seller) == "qualified"


def test_mixed_inventory_pass_requires_sold_image_samples(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["mixed_non_niche_inventory"] == "unknown"
    assert assessment.checks["catalog_stock_photo_style"] == "unknown"
    assert "mixed_non_niche_inventory" in assessment.reason
    assert store_status(conn, seller) == "manual_review"


def test_mixed_inventory_pass_requires_three_sold_macro_categories(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_sold_visual_samples(conn, seller, run_id, macro_categories=["home/kitchen", "electronics"])
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["mixed_non_niche_inventory"] == "unknown"
    assert assessment.checks["catalog_stock_photo_style"] == "pass"


def test_mixed_inventory_pass_requires_thirty_sold_image_samples(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_sold_visual_samples(conn, seller, run_id, count=29)
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["mixed_non_niche_inventory"] == "unknown"
    assert assessment.checks["catalog_stock_photo_style"] == "unknown"


def test_sold_image_samples_must_be_from_first_thirty_ranks(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_sold_visual_samples(conn, seller, run_id, start_rank=31)
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["mixed_non_niche_inventory"] == "unknown"
    assert assessment.checks["catalog_stock_photo_style"] == "unknown"


def test_same_product_match_pass_requires_candidate_seed_image_evidence(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_sold_visual_samples(conn, seller, run_id)
    for check in REQUIRED_CHECKS:
        record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["same_product_match"] == "unknown"


def test_any_failed_required_check_rejects(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_all(conn, seller, run_id)
    record_check(conn, seller, run_id, "mixed_non_niche_inventory", "fail")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "rejected"
    assert "mixed_non_niche_inventory" in assessment.reason


def test_unknown_check_routes_to_manual_review(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_sold_visual_samples(conn, seller, run_id)
    for check in REQUIRED_CHECKS:
        if check != "catalog_stock_photo_style":
            record_check(conn, seller, run_id, check, "pass")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "manual_review"
    assert assessment.checks["catalog_stock_photo_style"] == "unknown"


def test_blocker_overrides_other_checks(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_all(conn, seller, run_id)
    record_blocker(conn, run_id, "captcha", "captcha shown on eBay")

    assessment = assess_store(conn, seller, run_id)

    assert assessment.status == "blocked"
    assert assessment.checks["no_blocker"] == "fail"
    assert store_status(conn, seller) == "blocked"


def test_not_source_store_is_required_gate() -> None:
    assert "not_source_store" in REQUIRED_CHECKS


def test_search_queue_tables_exist(conn: sqlite3.Connection) -> None:
    tables = {
        row["name"]
        for row in conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name IN ('search_tasks', 'search_results')"
        ).fetchall()
    }
    assert tables == {"search_tasks", "search_results"}


def test_store_handoff_tables_exist(conn: sqlite3.Connection) -> None:
    tables = {
        row["name"]
        for row in conn.execute(
            """
            SELECT name
            FROM sqlite_master
            WHERE type = 'table'
              AND name IN ('store_handoffs', 'store_handoff_items')
            """
        ).fetchall()
    }

    assert tables == {"store_handoffs", "store_handoff_items"}


def test_seed_schema_has_canonical_image_columns(conn: sqlite3.Connection) -> None:
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(seed_products)").fetchall()}

    assert {
        "amazon_image_url",
        "ebay_image_url",
        "source_image_url",
        "source_image_role",
        "seed_title_match_result",
        "seed_image_match_result",
        "seed_visual_evidence_note",
    }.issubset(columns)


def test_init_db_migrates_seed_image_columns(tmp_path) -> None:
    db = connect(tmp_path / "legacy.sqlite3")
    db.execute(
        """
        CREATE TABLE seed_products (
          id INTEGER PRIMARY KEY,
          dc_product_id TEXT,
          status TEXT NOT NULL DEFAULT 'unseen'
        )
        """
    )

    init_db(db)

    columns = {row["name"] for row in db.execute("PRAGMA table_info(seed_products)").fetchall()}
    assert {
        "amazon_image_url",
        "ebay_image_url",
        "source_image_url",
        "source_image_role",
        "seed_title_match_result",
        "seed_image_match_result",
        "seed_visual_evidence_note",
    }.issubset(columns)
    assert db.execute("PRAGMA user_version").fetchone()[0] == 3


def test_eligible_seed_requires_canonical_amazon_image_evidence(conn: sqlite3.Connection) -> None:
    with pytest.raises(FridayError, match="canonical Amazon source image evidence"):
        upsert_seed(
            conn,
            {
                "dc_product_id": "missing-images",
                "supplier_url": "https://www.amazon.com/dp/missing-images",
                "source_ebay_url": "https://www.ebay.com/itm/123456789012",
            },
        )

    with pytest.raises(FridayError, match="source_image_url must match amazon_image_url"):
        upsert_seed(
            conn,
            seed_payload(
                "wrong-source",
                source_image_url="https://i.ebayimg.com/images/g/wrong/s-l500.webp",
            ),
        )


def test_upserts_dedupe_seed_store_and_candidate(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    seed_id = upsert_seed(conn, {"dc_product_id": "163875", "amazon_title": "Old"})
    seed_id_again = upsert_seed(conn, {"dc_product_id": "163875", "amazon_title": "New"})
    store_id = upsert_store(conn, {"seller_username": "TheCorner2010"})
    store_id_again = upsert_store(conn, {"seller_username": " thecorner2010 ", "store_url": "https://example.test/store"})
    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "dc_product_id": "163875",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
            "listing_url": "https://www.ebay.com/itm/257385269240",
        },
    )
    candidate_id_again = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
            "listing_title": "Updated title",
        },
    )

    assert seed_id == seed_id_again
    assert store_id == store_id_again
    assert candidate_id == candidate_id_again
    assert conn.execute("SELECT COUNT(*) AS count FROM seed_products").fetchone()["count"] == 1
    assert conn.execute("SELECT COUNT(*) AS count FROM stores").fetchone()["count"] == 1
    assert conn.execute("SELECT COUNT(*) AS count FROM candidate_listings").fetchone()["count"] == 1


def test_candidate_rejects_source_store_self_match(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(
        conn,
        seed_payload("163825", source_store_name="barfire", ebay_item_id="326769007434"),
    )

    with pytest.raises(FridayError, match="source store"):
        upsert_candidate(
            conn,
            {
                "seller_username": " BARFIRE ",
                "dc_product_id": "163825",
                "run_id": run_id,
                "ebay_item_id": "147235983259",
            },
        )

    assert conn.execute("SELECT COUNT(*) AS count FROM stores").fetchone()["count"] == 0
    assert conn.execute("SELECT COUNT(*) AS count FROM candidate_listings").fetchone()["count"] == 0


def test_candidate_rejects_source_listing_self_match(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(
        conn,
        seed_payload(
            "163825",
            source_store_name="barfire",
            source_ebay_url="https://www.ebay.com/itm/326769007434?amdata=ignored",
        ),
    )

    with pytest.raises(FridayError, match="source seed listing"):
        upsert_candidate(
            conn,
            {
                "seller_username": "other_seller",
                "dc_product_id": "163825",
                "run_id": run_id,
                "listing_url": "https://www.ebay.com/itm/326769007434",
            },
        )

    assert conn.execute("SELECT COUNT(*) AS count FROM stores").fetchone()["count"] == 0
    assert conn.execute("SELECT COUNT(*) AS count FROM candidate_listings").fetchone()["count"] == 0


def test_candidate_url_only_row_can_be_enriched_with_item_id(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, {"dc_product_id": "163875"})

    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "dc_product_id": "163875",
            "run_id": run_id,
            "listing_url": "https://www.ebay.com/itm/257385269240",
            "card_title": "Search result title",
        },
    )
    candidate_id_again = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
            "listing_url": "https://www.ebay.com/itm/257385269240",
            "listing_title": "Listing detail title",
        },
    )

    row = conn.execute(
        """
        SELECT ebay_item_id, listing_url, card_title, listing_title
        FROM candidate_listings
        WHERE id = ?
        """,
        (candidate_id,),
    ).fetchone()
    assert candidate_id_again == candidate_id
    assert dict(row) == {
        "ebay_item_id": "257385269240",
        "listing_url": "https://www.ebay.com/itm/257385269240",
        "card_title": "Search result title",
        "listing_title": "Listing detail title",
    }
    assert conn.execute("SELECT COUNT(*) AS count FROM candidate_listings").fetchone()["count"] == 1


def test_candidate_item_id_only_row_can_be_enriched_with_listing_url(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")

    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
            "listing_title": "Listing detail title",
        },
    )
    candidate_id_again = upsert_candidate(
        conn,
        {
            "seller_username": "thecorner2010",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
            "listing_url": "https://www.ebay.com/itm/257385269240",
            "card_title": "Search result title",
        },
    )

    row = conn.execute(
        """
        SELECT ebay_item_id, listing_url, card_title, listing_title
        FROM candidate_listings
        WHERE id = ?
        """,
        (candidate_id,),
    ).fetchone()
    assert candidate_id_again == candidate_id
    assert dict(row) == {
        "ebay_item_id": "257385269240",
        "listing_url": "https://www.ebay.com/itm/257385269240",
        "card_title": "Search result title",
        "listing_title": "Listing detail title",
    }


def test_candidate_identity_conflict_raises(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_candidate(
        conn,
        {
            "seller_username": "seller_a",
            "run_id": run_id,
            "ebay_item_id": "257385269240",
        },
    )
    upsert_candidate(
        conn,
        {
            "seller_username": "seller_b",
            "run_id": run_id,
            "listing_url": "https://www.ebay.com/itm/999999999999",
        },
    )

    with pytest.raises(FridayError, match="identity conflict"):
        upsert_candidate(
            conn,
            {
                "seller_username": "seller_c",
                "run_id": run_id,
                "ebay_item_id": "257385269240",
                "listing_url": "https://www.ebay.com/itm/999999999999",
            },
        )


def test_partial_seed_upsert_preserves_existing_values(conn: sqlite3.Connection) -> None:
    seed_id = upsert_seed(
        conn,
        seed_payload(
            "163875",
            amazon_title="Old title",
            amazon_retail_price=19.99,
            status="used",
            search_source="amazon_title",
        ),
    )
    seed_id_again = upsert_seed(conn, {"dc_product_id": "163875", "amazon_title": "New title"})

    row = conn.execute(
        """
        SELECT amazon_title, amazon_retail_price, status, search_source
        FROM seed_products
        WHERE id = ?
        """,
        (seed_id,),
    ).fetchone()
    assert seed_id_again == seed_id
    assert dict(row) == {
        "amazon_title": "New title",
        "amazon_retail_price": 19.99,
        "status": "used",
        "search_source": "amazon_title",
    }


def test_mark_seed_used_records_search_and_prevents_reuse(conn: sqlite3.Connection) -> None:
    first_run_id = create_run(conn, run_type="test")
    second_run_id = create_run(conn, run_type="test")
    seed_id = upsert_seed(conn, {"dc_product_id": "163825", "amazon_title": "Replacement Hose"})

    used_id = mark_seed_used(
        conn,
        dc_product_id="163825",
        run_id=first_run_id,
        search_query_used="Replacement Hose",
        search_source="amazon_title",
    )

    row = conn.execute(
        """
        SELECT status, used_at, discovery_run_id, search_query_used, search_source
        FROM seed_products
        WHERE id = ?
        """,
        (seed_id,),
    ).fetchone()
    assert used_id == seed_id
    assert row["status"] == "used"
    assert row["used_at"] is not None
    assert row["discovery_run_id"] == first_run_id
    assert row["search_query_used"] == "Replacement Hose"
    assert row["search_source"] == "amazon_title"

    with pytest.raises(FridayError, match="already used"):
        mark_seed_used(conn, "163825", second_run_id, "Replacement Hose")


def test_search_task_creation_is_idempotent(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671", amazon_title="Outdoor Chair Cushions"))

    task_id = start_search_task(
        conn,
        dc_product_id="166671",
        run_id=run_id,
        search_url="https://www.ebay.com/sch/i.html?_nkw=Outdoor+Chair+Cushions",
        search_query="Outdoor Chair Cushions",
        search_source="amazon_title",
    )
    same_task_id = start_search_task(
        conn,
        dc_product_id="166671",
        run_id=run_id,
        search_url="https://www.ebay.com/sch/i.html?_nkw=Outdoor+Chair+Cushions",
        search_query="Outdoor Chair Cushions",
        search_source="amazon_title",
    )

    row = conn.execute("SELECT status, search_query FROM search_tasks WHERE id = ?", (task_id,)).fetchone()
    assert same_task_id == task_id
    assert row["status"] == "in_progress"
    assert row["search_query"] == "Outdoor Chair Cushions"
    assert conn.execute("SELECT COUNT(*) AS count FROM search_tasks").fetchone()["count"] == 1


def test_start_search_task_requires_seed_image_evidence(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, {"dc_product_id": "legacy-seed", "amazon_title": "Legacy Seed"})

    with pytest.raises(FridayError, match="canonical Amazon source image evidence"):
        start_search_task(
            conn,
            dc_product_id="legacy-seed",
            run_id=run_id,
            search_url="https://www.ebay.com/sch/i.html?_nkw=legacy",
        )


def test_search_no_results_skips_amazon_title_seed(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671", amazon_title="Outdoor Chair Cushions"))
    task_id = start_search_task(
        conn,
        dc_product_id="166671",
        run_id=run_id,
        search_url="https://www.ebay.com/sch/i.html?_nkw=Outdoor+Chair+Cushions",
        search_query="Outdoor Chair Cushions",
        search_source="amazon_title",
    )

    returned_task_id = mark_search_no_results(conn, task_id, run_id=run_id)

    task = conn.execute("SELECT status, stop_reason FROM search_tasks WHERE id = ?", (task_id,)).fetchone()
    seed = conn.execute(
        """
        SELECT status, skip_reason, discovery_run_id, search_query_used, search_source, used_at
        FROM seed_products
        WHERE dc_product_id = '166671'
        """
    ).fetchone()
    assert returned_task_id == task_id
    assert dict(task) == {"status": "exhausted", "stop_reason": "page_exhausted"}
    assert seed["status"] == "skipped"
    assert seed["skip_reason"] == "amazon_title_zero_results"
    assert seed["discovery_run_id"] == run_id
    assert seed["search_query_used"] == "Outdoor Chair Cushions"
    assert seed["search_source"] == "amazon_title"
    assert seed["used_at"] is None


def test_search_no_results_requires_zero_cached_results(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=cushions")
    cache_search_results(conn, task_id, [{"rank": 1, "ebay_item_id": "800036969169"}])

    with pytest.raises(FridayError, match="zero cached search results"):
        mark_search_no_results(conn, task_id, run_id=run_id)

    seed = conn.execute("SELECT status, skip_reason FROM seed_products WHERE dc_product_id = '166671'").fetchone()
    assert seed["status"] == "unseen"
    assert seed["skip_reason"] is None


def test_search_no_results_requires_amazon_title_task(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(
        conn,
        "166671",
        run_id,
        "https://www.ebay.com/sch/i.html?_nkw=cushions",
        search_source="ebay_title",
    )

    with pytest.raises(FridayError, match="amazon_title"):
        mark_search_no_results(conn, task_id, run_id=run_id)


def test_start_search_task_blocks_skipped_zero_result_seed(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=amazon")
    mark_search_no_results(conn, task_id, run_id=run_id)

    with pytest.raises(FridayError, match="amazon_title_zero_results"):
        start_search_task(
            conn,
            "166671",
            run_id,
            "https://www.ebay.com/sch/i.html?_nkw=ebay",
            search_source="ebay_title",
        )


def test_start_search_task_blocks_ebay_title_after_exhausted_zero_result_amazon_title_task(
    conn: sqlite3.Connection,
) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=amazon")
    finish_search_task(conn, task_id, status="exhausted", stop_reason="page_exhausted")

    with pytest.raises(FridayError, match="eBay-title search is not allowed"):
        start_search_task(
            conn,
            "166671",
            run_id,
            "https://www.ebay.com/sch/i.html?_nkw=ebay",
            search_source="ebay_title",
        )


def test_cache_search_results_dedupes_and_preserves_queue(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(
        conn,
        dc_product_id="166671",
        run_id=run_id,
        search_url="https://www.ebay.com/sch/i.html?_nkw=cushions",
    )

    result_ids = cache_search_results(
        conn,
        task_id,
        [
            {
                "rank": 1,
                "ebay_item_id": "800036969169",
                "listing_url": "https://www.ebay.com/itm/800036969169",
                "seller_username": "qashbz",
                "title": "Outdoor Chair Cushions",
                "price": 52.4,
                "sponsored": True,
            },
            {
                "rank": 2,
                "listing_url": "https://www.ebay.com/itm/389582511837",
                "seller_username": "other_seller",
                "title": "Cable Clips",
                "price": 12.98,
            },
        ],
    )
    result_ids_again = cache_search_results(
        conn,
        task_id,
        [
            {
                "rank": 9,
                "ebay_item_id": "800036969169",
                "listing_url": "https://www.ebay.com/itm/800036969169",
                "title": "Updated title",
            }
        ],
    )

    rows = conn.execute(
        """
        SELECT rank, ebay_item_id, seller_username, normalized_seller_username, title, status, sponsored
        FROM search_results
        ORDER BY id
        """
    ).fetchall()
    assert result_ids_again == [result_ids[0]]
    assert len(rows) == 2
    assert dict(rows[0]) == {
        "rank": 1,
        "ebay_item_id": "800036969169",
        "seller_username": "qashbz",
        "normalized_seller_username": "qashbz",
        "title": "Updated title",
        "status": "queued",
        "sponsored": 1,
    }


def test_cache_search_results_preserves_processed_state_on_refresh(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=cushions")
    (result_id,) = cache_search_results(
        conn,
        task_id,
        [
            {
                "rank": 1,
                "ebay_item_id": "800036969169",
                "listing_url": "https://www.ebay.com/itm/800036969169",
                "seller_username": "qashbz",
                "title": "Outdoor Chair Cushions",
                "price": 52.4,
            }
        ],
    )
    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "qashbz",
            "dc_product_id": "166671",
            "run_id": run_id,
            "ebay_item_id": "800036969169",
        },
    )
    mark_search_result(conn, result_id, status="candidate", run_id=run_id, candidate_listing_id=candidate_id)

    recached_ids = cache_search_results(
        conn,
        task_id,
        [
            {
                "rank": 9,
                "ebay_item_id": "800036969169",
                "listing_url": "https://www.ebay.com/itm/800036969169",
                "title": "Updated card title",
                "price": 54.95,
            }
        ],
    )

    row = conn.execute(
        """
        SELECT rank, title, price, status, reason_code, candidate_listing_id, processed_run_id
        FROM search_results
        WHERE id = ?
        """,
        (result_id,),
    ).fetchone()
    assert recached_ids == [result_id]
    assert dict(row) == {
        "rank": 1,
        "title": "Updated card title",
        "price": 54.95,
        "status": "candidate",
        "reason_code": None,
        "candidate_listing_id": candidate_id,
        "processed_run_id": run_id,
    }
    assert next_search_results(conn) == []


def test_cache_search_results_rejects_processed_status_input(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=cushions")

    with pytest.raises(FridayError, match="only create queued"):
        cache_search_results(
            conn,
            task_id,
            [{"rank": 1, "ebay_item_id": "800036969169", "status": "rejected"}],
        )


def test_next_search_results_prefers_partial_queued_work(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("first"))
    upsert_seed(conn, seed_payload("second"))
    first_task = start_search_task(conn, "first", run_id, "https://www.ebay.com/sch/i.html?_nkw=first")
    second_task = start_search_task(conn, "second", run_id, "https://www.ebay.com/sch/i.html?_nkw=second")
    cache_search_results(conn, second_task, [{"rank": 1, "ebay_item_id": "222222"}])
    cache_search_results(conn, first_task, [{"rank": 1, "ebay_item_id": "111111"}])
    finish_search_task(conn, first_task, status="partial", stop_reason="target_reached")

    rows = next_search_results(conn, limit=2)

    assert [row["search_task_id"] for row in rows] == [first_task, second_task]
    assert [row["ebay_item_id"] for row in rows] == ["111111", "222222"]
    assert rows[0]["dc_product_id"] == "first"


def test_search_preflight_returns_new_seed_when_no_queue(conn: sqlite3.Connection) -> None:
    assert search_preflight(conn, limit=1) == {"mode": "new_seed", "queued_count": 0}


def test_search_preflight_summarizes_next_partial_queue_item(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("first", amazon_title="First Seed"))
    upsert_seed(conn, seed_payload("second", amazon_title="Second Seed"))
    first_task = start_search_task(
        conn,
        "first",
        run_id,
        "https://www.ebay.com/sch/i.html?_nkw=first",
        search_query="first query",
    )
    second_task = start_search_task(conn, "second", run_id, "https://www.ebay.com/sch/i.html?_nkw=second")
    first_result, second_result, _third_result = cache_search_results(
        conn,
        first_task,
        [
            {"rank": 1, "ebay_item_id": "111111", "seller_username": "source_seller"},
            {
                "rank": 2,
                "ebay_item_id": "222222",
                "listing_url": "https://www.ebay.com/itm/222222",
                "seller_username": "seller_two",
                "title": "Second card",
            },
            {"rank": 3, "ebay_item_id": "333333", "seller_username": "seller_three"},
        ],
    )
    cache_search_results(conn, second_task, [{"rank": 1, "ebay_item_id": "999999", "seller_username": "later"}])
    mark_search_result(conn, first_result, status="skipped", reason_code="source_store_self_match", run_id=run_id)
    finish_search_task(conn, first_task, status="partial", stop_reason="target_reached")

    expected_next = next_search_results(conn, limit=1)[0]
    preflight = search_preflight(conn, limit=1)

    assert expected_next["id"] == second_result
    assert preflight == {
        "mode": "resume_queue",
        "queued_count": 2,
        "search_task_id": first_task,
        "task_status": "partial",
        "dc_product_id": "first",
        "seed_title": "First Seed",
        "search_query": "first query",
        "search_url": "https://www.ebay.com/sch/i.html?_nkw=first",
        "next_search_result_id": second_result,
        "next_rank": 2,
        "next_seller_username": "seller_two",
        "next_listing_url": "https://www.ebay.com/itm/222222",
        "next_ebay_item_id": "222222",
        "next_title": "Second card",
    }


def test_search_preflight_does_not_mutate_queue_state(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("first", amazon_title="First Seed"))
    task_id = start_search_task(conn, "first", run_id, "https://www.ebay.com/sch/i.html?_nkw=first")
    cache_search_results(conn, task_id, [{"rank": 1, "ebay_item_id": "111111", "seller_username": "seller_one"}])
    finish_search_task(conn, task_id, status="partial", stop_reason="target_reached")
    before = {
        table: [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY id").fetchall()]
        for table in ("seed_products", "search_tasks", "search_results")
    }

    search_preflight(conn, limit=1)

    after = {
        table: [dict(row) for row in conn.execute(f"SELECT * FROM {table} ORDER BY id").fetchall()]
        for table in ("seed_products", "search_tasks", "search_results")
    }
    assert after == before


def test_search_preflight_cli_smoke(tmp_path) -> None:
    runner = CliRunner()
    db_path = tmp_path / "friday.sqlite3"
    assert runner.invoke(app, ["init-db", "--db", str(db_path)]).exit_code == 0
    db = connect(db_path)
    run_id = create_run(db, run_type="test")
    upsert_seed(db, seed_payload("first", amazon_title="First Seed"))
    task_id = start_search_task(db, "first", run_id, "https://www.ebay.com/sch/i.html?_nkw=first")
    (result_id,) = cache_search_results(
        db,
        task_id,
        [{"rank": 1, "ebay_item_id": "111111", "seller_username": "seller_one"}],
    )
    finish_search_task(db, task_id, status="partial", stop_reason="target_reached")

    result = runner.invoke(app, ["search", "preflight", "--db", str(db_path), "--limit", "1"])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["mode"] == "resume_queue"
    assert payload["next_search_result_id"] == result_id
    assert payload["queued_count"] == 1


def test_search_no_results_cli_skips_seed(tmp_path) -> None:
    runner = CliRunner()
    db_path = tmp_path / "friday.sqlite3"
    assert runner.invoke(app, ["init-db", "--db", str(db_path)]).exit_code == 0
    db = connect(db_path)
    run_id = create_run(db, run_type="test")
    upsert_seed(db, seed_payload("first", amazon_title="First Seed"))
    task_id = start_search_task(
        db,
        "first",
        run_id,
        "https://www.ebay.com/sch/i.html?_nkw=First+Seed",
        search_query="First Seed",
    )

    result = runner.invoke(
        app,
        [
            "search",
            "no-results",
            "--db",
            str(db_path),
            "--search-task-id",
            str(task_id),
            "--run-id",
            str(run_id),
        ],
    )

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload == {
        "search_task_id": task_id,
        "status": "exhausted",
        "seed_status": "skipped",
        "skip_reason": "amazon_title_zero_results",
    }
    seed = db.execute("SELECT status, skip_reason FROM seed_products WHERE dc_product_id = 'first'").fetchone()
    assert seed["status"] == "skipped"
    assert seed["skip_reason"] == "amazon_title_zero_results"


def test_report_latest_cli_smoke(tmp_path) -> None:
    runner = CliRunner()
    db_path = tmp_path / "friday.sqlite3"
    assert runner.invoke(app, ["init-db", "--db", str(db_path)]).exit_code == 0
    db = connect(db_path)
    run_id = create_run(db, run_type="discovery", target_count=1)

    result = runner.invoke(app, ["report", "latest", "--db", str(db_path)])

    assert result.exit_code == 0
    payload = json.loads(result.stdout)
    assert payload["run"]["id"] == run_id
    assert payload["outcome"]["summary"] == "no qualified sellers found"
    assert payload["ebay"]["listings_reviewed_this_run"] == 0


def test_mark_search_result_records_reason_and_candidate_link(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=cushions")
    first_result, second_result = cache_search_results(
        conn,
        task_id,
        [
            {"rank": 1, "ebay_item_id": "800036969169", "seller_username": "qashbz"},
            {"rank": 2, "ebay_item_id": "389582511837", "seller_username": "weak_seller"},
        ],
    )
    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "qashbz",
            "dc_product_id": "166671",
            "run_id": run_id,
            "ebay_item_id": "800036969169",
        },
    )

    mark_search_result(conn, first_result, status="candidate", run_id=run_id, candidate_listing_id=candidate_id)
    mark_search_result(conn, second_result, status="rejected", reason_code="feedback_under_100", run_id=run_id)

    rows = conn.execute(
        """
        SELECT id, status, reason_code, candidate_listing_id, processed_run_id
        FROM search_results
        ORDER BY id
        """
    ).fetchall()
    task = conn.execute("SELECT last_processed_rank FROM search_tasks WHERE id = ?", (task_id,)).fetchone()
    assert dict(rows[0]) == {
        "id": first_result,
        "status": "candidate",
        "reason_code": None,
        "candidate_listing_id": candidate_id,
        "processed_run_id": run_id,
    }
    assert rows[1]["status"] == "rejected"
    assert rows[1]["reason_code"] == "feedback_under_100"
    assert task["last_processed_rank"] == 2


def test_run_report_builds_user_observable_funnel(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="discovery", target_count=1)
    upsert_seed(
        conn,
        seed_payload(
            "164442",
            source_store_name="larrsap_1",
            source_store_dc_shop_id="4026",
            amazon_title="16Pcs W10919249 Grate Rubber Feet Replacement",
            source_ebay_url="https://www.ebay.com/itm/146824713737",
            ebay_item_id="146824713737",
            profit=1.57,
            lifetime_sales=4,
            members_listed=0,
        ),
    )
    task_id = start_search_task(
        conn,
        "164442",
        run_id,
        "https://www.ebay.com/sch/i.html?_nkw=W10919249",
        search_query="W10919249",
    )
    rejected_result, qualified_result, _queued_result = cache_search_results(
        conn,
        task_id,
        [
            {"rank": 1, "ebay_item_id": "111111111111", "seller_username": "wrong_size"},
            {"rank": 2, "ebay_item_id": "222222222222", "seller_username": "dbpenter-0"},
            {"rank": 3, "ebay_item_id": "333333333333", "seller_username": "next_seller"},
        ],
    )
    mark_search_result(conn, rejected_result, status="rejected", reason_code="title_mismatch", run_id=run_id)
    candidate_id = upsert_candidate(
        conn,
        {
            "seller_username": "dbpenter-0",
            "dc_product_id": "164442",
            "run_id": run_id,
            "search_result_rank": 2,
            "ebay_item_id": "222222222222",
            "listing_url": "https://www.ebay.com/itm/222222222222",
            "card_title": "W10919249 Grate Rubber Feet Replacement Parts",
            "card_price": 16.70,
            "card_image_url": "https://i.ebayimg.com/images/g/candidate/s-l500.webp",
            "listing_title": "W10919249 Grate Rubber Feet Replacement Parts",
            "listing_price": 16.70,
            "title_match_result": "pass",
            "image_match_result": "pass",
            "price_above_retail_result": "pass",
            "evidence_note": "Visible card/listing image matches seed: same black rubber stove grate feet.",
        },
    )
    mark_search_result(
        conn,
        qualified_result,
        status="qualified",
        run_id=run_id,
        candidate_listing_id=candidate_id,
    )
    upsert_store(
        conn,
        {
            "seller_username": "dbpenter-0",
            "store_url": "https://www.ebay.com/str/dbpenter0",
            "feedback_count": 6796,
            "feedback_percent": 99.2,
            "visible_sold_results_count": 1000,
            "store_lifetime_items_sold": 15000,
        },
    )
    record_sold_visual_samples(conn, "dbpenter-0", run_id)
    for check in REQUIRED_CHECKS:
        observed = None
        if check == "mixed_non_niche_inventory":
            observed = "reviewed 30 sold-card images from ranks 1-30; macro categories: home/kitchen, electronics, pet supplies"
        record_check(conn, "dbpenter-0", run_id, check, "pass", observed_value=observed, assessed_by="test")
    assess_store(conn, "dbpenter-0", run_id)
    finish_search_task(conn, task_id, status="partial", stop_reason="target_reached")

    report = run_report(conn, run_id=run_id, seller_limit=1)

    assert report["outcome"]["summary"] == "found 1 qualified seller"
    assert report["start_mode"] == "opened_dropship_calendar"
    assert report["dropship_calendar"]["source_stores_used_count"] == 1
    assert report["dropship_calendar"]["source_stores_used"][0]["name"] == "larrsap_1"
    assert (
        report["dropship_calendar"]["source_stores_used"][0]["url"]
        == "https://autopilot.dropshipcalendar.io/dashboard/item-finder/shops/4026"
    )
    assert report["dropship_calendar"]["products_selected"] == 1
    assert report["ebay"]["searches_opened"] == 1
    assert report["ebay"]["listings_saved_for_review"] == 3
    assert report["ebay"]["listings_reviewed_this_run"] == 2
    assert report["ebay"]["listings_rejected_this_run"] == 1
    assert report["ebay"]["listings_qualified_this_run"] == 1
    assert report["ebay"]["remaining_queued"] == 1
    assert report["seller_review"]["sellers_deep_reviewed"] == 1
    assert report["seller_review"]["qualified_total"] == 1
    assert report["seller_review"]["qualified_remaining"] == 0
    qualified = report["seller_review"]["qualified"][0]
    assert qualified["username"] == "dbpenter-0"
    assert qualified["matching_listing_url"] == "https://www.ebay.com/itm/222222222222"
    assert qualified["seller_url"] == "https://www.ebay.com/sch/i.html?_ssn=dbpenter-0"
    assert "99.2% feedback" in qualified["quality_summary"]
    assert "1,000+ sold results" in qualified["quality_summary"]
    assert report["safety"]["dropship_calendar_mutation"] == "none_recorded"


def test_run_report_detects_resumed_queue_start(conn: sqlite3.Connection) -> None:
    original_run = create_run(conn, run_type="discovery", target_count=1)
    resumed_run = create_run(conn, run_type="discovery", target_count=1)
    upsert_seed(conn, seed_payload("first", source_store_name="source_store"))
    task_id = start_search_task(conn, "first", original_run, "https://www.ebay.com/sch/i.html?_nkw=first")
    (result_id,) = cache_search_results(
        conn,
        task_id,
        [{"rank": 1, "ebay_item_id": "111111111111", "seller_username": "weak_seller"}],
    )
    finish_search_task(conn, task_id, status="partial", stop_reason="target_reached")
    mark_search_result(conn, result_id, status="rejected", reason_code="feedback_under_100", run_id=resumed_run)

    report = run_report(conn, run_id=resumed_run)

    assert report["start_mode"] == "resumed_queued_ebay_results"
    assert report["dropship_calendar"]["source_stores_used_count"] == 0
    assert report["ebay"]["searches_opened"] == 0
    assert report["ebay"]["listings_saved_for_review"] == 1
    assert report["ebay"]["listings_reviewed_this_run"] == 1
    assert report["ebay"]["remaining_queued"] == 0


def test_finish_search_task_updates_status_and_seed_when_exhausted(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671"))
    task_id = start_search_task(
        conn,
        "166671",
        run_id,
        "https://www.ebay.com/sch/i.html?_nkw=cushions",
        search_query="cushions",
    )
    cache_search_results(conn, task_id, [{"rank": 1, "ebay_item_id": "800036969169"}])
    finish_search_task(conn, task_id, status="partial", stop_reason="target_reached")

    task = conn.execute("SELECT status, stop_reason FROM search_tasks WHERE id = ?", (task_id,)).fetchone()
    seed = conn.execute("SELECT status, used_at FROM seed_products WHERE dc_product_id = '166671'").fetchone()
    assert dict(task) == {"status": "partial", "stop_reason": "target_reached"}
    assert seed["status"] == "candidate"
    assert seed["used_at"] is None

    mark_search_result(conn, 1, status="skipped", reason_code="seller_seen", run_id=run_id)
    finish_search_task(conn, task_id, status="exhausted", stop_reason="page_exhausted")

    task = conn.execute("SELECT status, stop_reason FROM search_tasks WHERE id = ?", (task_id,)).fetchone()
    seed = conn.execute(
        """
        SELECT status, used_at, discovery_run_id, search_query_used, search_source
        FROM seed_products
        WHERE dc_product_id = '166671'
        """
    ).fetchone()
    assert dict(task) == {"status": "exhausted", "stop_reason": "page_exhausted"}
    assert seed["status"] == "used"
    assert seed["used_at"] is not None
    assert seed["discovery_run_id"] == run_id
    assert seed["search_query_used"] == "cushions"


def test_explain_seed_reports_task_and_result_counts(conn: sqlite3.Connection) -> None:
    run_id = create_run(conn, run_type="test")
    upsert_seed(conn, seed_payload("166671", amazon_title="Outdoor Chair Cushions"))
    task_id = start_search_task(conn, "166671", run_id, "https://www.ebay.com/sch/i.html?_nkw=cushions")
    first_result, second_result = cache_search_results(
        conn,
        task_id,
        [{"rank": 1, "ebay_item_id": "1"}, {"rank": 2, "ebay_item_id": "2"}],
    )
    mark_search_result(conn, first_result, status="rejected", reason_code="title_mismatch", run_id=run_id)

    explanation = explain_seed(conn, "166671")

    assert explanation["seed"]["dc_product_id"] == "166671"
    assert explanation["search_tasks"][0]["id"] == task_id
    assert explanation["search_tasks"][0]["result_counts"] == {"queued": 1, "rejected": 1}
    assert explanation["queued_results"][0]["id"] == second_result


def test_partial_sold_item_upsert_preserves_existing_values(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    sold_item_id = upsert_sold_item(
        conn,
        {
            "seller_username": seller,
            "run_id": run_id,
            "rank": 1,
            "title": "Old title",
            "price": 11.5,
            "item_url": "https://www.ebay.com/itm/old",
        },
    )
    sold_item_id_again = upsert_sold_item(
        conn,
        {
            "seller_username": seller,
            "run_id": run_id,
            "rank": 1,
            "title": "New title",
        },
    )

    row = conn.execute(
        "SELECT title, price, item_url FROM seller_sold_items WHERE id = ?",
        (sold_item_id,),
    ).fetchone()
    assert sold_item_id_again == sold_item_id
    assert dict(row) == {
        "title": "New title",
        "price": 11.5,
        "item_url": "https://www.ebay.com/itm/old",
    }


def test_sold_item_requires_run_id(conn: sqlite3.Connection) -> None:
    upsert_store(conn, {"seller_username": "thecorner2010"})

    with pytest.raises(FridayError, match="run_id"):
        upsert_sold_item(
            conn,
            {
                "seller_username": "thecorner2010",
                "rank": 1,
                "title": "Sold sample",
            },
        )


def test_record_screenshot_rejects_missing_file(conn: sqlite3.Connection, tmp_path) -> None:
    missing = tmp_path / "missing.png"

    with pytest.raises(FridayError, match="does not exist"):
        record_screenshot(conn, {"entity_type": "store", "file_path": str(missing)})

    assert conn.execute("SELECT COUNT(*) AS count FROM screenshots").fetchone()["count"] == 0


def test_record_screenshot_rejects_directory(conn: sqlite3.Connection, tmp_path) -> None:
    directory = tmp_path / "screenshots"
    directory.mkdir()

    with pytest.raises(FridayError, match="must be a file"):
        record_screenshot(conn, {"entity_type": "store", "file_path": str(directory)})

    assert conn.execute("SELECT COUNT(*) AS count FROM screenshots").fetchone()["count"] == 0


def test_record_screenshot_rejects_empty_file(conn: sqlite3.Connection, tmp_path) -> None:
    screenshot_path = tmp_path / "empty.png"
    screenshot_path.touch()

    with pytest.raises(FridayError, match="empty"):
        record_screenshot(conn, {"entity_type": "store", "file_path": str(screenshot_path)})

    assert conn.execute("SELECT COUNT(*) AS count FROM screenshots").fetchone()["count"] == 0


def test_record_screenshot_stores_absolute_path(conn: sqlite3.Connection, tmp_path) -> None:
    screenshot_path = tmp_path / "listing.png"
    screenshot_path.write_bytes(b"not-empty")

    screenshot_id = record_screenshot(
        conn,
        {
            "entity_type": "store",
            "entity_id": 7,
            "screenshot_type": "listing_page",
            "file_path": str(screenshot_path),
            "source_url": "https://www.ebay.com/itm/123",
        },
    )

    row = conn.execute("SELECT * FROM screenshots WHERE id = ?", (screenshot_id,)).fetchone()
    assert dict(row) == {
        "id": screenshot_id,
        "entity_type": "store",
        "entity_id": 7,
        "screenshot_type": "listing_page",
        "file_path": str(screenshot_path.resolve()),
        "source_url": "https://www.ebay.com/itm/123",
        "captured_at": row["captured_at"],
    }


def test_record_screenshot_cli_rejects_missing_file(tmp_path) -> None:
    runner = CliRunner()
    db_path = tmp_path / "friday.sqlite3"
    missing = tmp_path / "missing.png"
    assert runner.invoke(app, ["init-db", "--db", str(db_path)]).exit_code == 0

    result = runner.invoke(
        app,
        [
            "record",
            "screenshot",
            "--db",
            str(db_path),
            "--entity-type",
            "store",
            "--entity-id",
            "1",
            "--screenshot-type",
            "listing_page",
            "--file-path",
            str(missing),
        ],
    )

    assert result.exit_code != 0
    assert "does not exist" in result.output
    db = connect(db_path)
    assert db.execute("SELECT COUNT(*) AS count FROM screenshots").fetchone()["count"] == 0


def test_record_blocker_requires_existing_run(conn: sqlite3.Connection) -> None:
    with pytest.raises(FridayError, match="Unknown run id 999"):
        record_blocker(conn, 999, "captcha")


def test_assess_updates_stale_no_blocker_check_after_run_blocker(conn: sqlite3.Connection) -> None:
    seller, run_id = make_store_run(conn)
    record_all(conn, seller, run_id)
    assert assess_store(conn, seller, run_id).status == "qualified"

    record_blocker(conn, run_id, "captcha", "captcha shown on eBay")
    assessment = assess_store(conn, seller, run_id)

    row = conn.execute(
        """
        SELECT result, observed_value, evidence_note
        FROM qualification_checks
        WHERE check_name = 'no_blocker'
        """,
    ).fetchone()
    assert assessment.status == "blocked"
    assert assessment.checks["no_blocker"] == "fail"
    assert dict(row) == {
        "result": "fail",
        "observed_value": "captcha",
        "evidence_note": "captcha shown on eBay",
    }


def test_export_only_approved_and_marks_exported(conn: sqlite3.Connection, tmp_path) -> None:
    seller, run_id = make_store_run(conn)
    record_all(conn, seller, run_id)
    assess_store(conn, seller, run_id)
    approve_store(conn, seller)
    upsert_store(conn, {"seller_username": "manual_review_seller"})

    out = tmp_path / "approved.csv"
    export_id = export_approved(conn, out)

    assert export_id == 1
    with out.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    assert rows == [{"seller_username": seller, "store_url": ""}]
    assert store_status(conn, seller) == "exported"
    assert store_status(conn, "manual_review_seller") == "seen"


def qualify_seller(conn: sqlite3.Connection, seller: str) -> None:
    seller_username, run_id = make_store_run(conn, seller=seller)
    record_all(conn, seller_username, run_id)
    assess_store(conn, seller_username, run_id)


def test_handoff_create_returns_limited_pending_batch_without_marking_added(conn: sqlite3.Connection) -> None:
    for seller in ("seller_a", "seller_b", "seller_c"):
        qualify_seller(conn, seller)

    payload = create_store_handoff(conn, limit=2, notes="manual add batch")

    assert payload["handoff"]["status"] == "pending"
    assert payload["handoff"]["requested_count"] == 2
    assert payload["item_count"] == 2
    assert payload["requires_confirmation"] is True
    assert [store["seller_username"] for store in payload["stores"]] == ["seller_a", "seller_b"]
    assert store_status(conn, "seller_a") == "qualified"
    assert store_status(conn, "seller_b") == "qualified"
    assert store_status(conn, "seller_c") == "qualified"
    assert payload["available_qualified_after_confirm"] == 1


def test_handoff_create_all_returns_every_qualified_store(conn: sqlite3.Connection) -> None:
    for seller in ("seller_a", "seller_b", "seller_c"):
        qualify_seller(conn, seller)
    upsert_store(conn, {"seller_username": "seen_seller"})
    reject_store(conn, "seen_seller", "not suitable")

    payload = create_store_handoff(conn, include_all=True)

    assert payload["handoff"]["requested_count"] is None
    assert payload["item_count"] == 3
    assert [store["seller_username"] for store in payload["stores"]] == ["seller_a", "seller_b", "seller_c"]
    assert payload["available_qualified_after_confirm"] == 0


def test_handoff_confirm_marks_exact_batch_manually_added_to_dc(conn: sqlite3.Connection) -> None:
    for seller in ("seller_a", "seller_b", "seller_c"):
        qualify_seller(conn, seller)
    handoff_id = create_store_handoff(conn, limit=2)["handoff"]["id"]

    payload = confirm_store_handoff(conn, handoff_id, note="user confirmed manual add")

    assert payload["handoff"]["status"] == "confirmed"
    assert payload["requires_confirmation"] is False
    assert store_status(conn, "seller_a") == "manually_added_to_dc"
    assert store_status(conn, "seller_b") == "manually_added_to_dc"
    assert store_status(conn, "seller_c") == "qualified"
    assert payload["available_qualified_now"] == 1


def test_handoff_create_blocks_duplicate_pending_batches(conn: sqlite3.Connection) -> None:
    for seller in ("seller_a", "seller_b"):
        qualify_seller(conn, seller)
    first = create_store_handoff(conn, limit=1)

    with pytest.raises(FridayError, match=f"Pending handoff {first['handoff']['id']} already exists"):
        create_store_handoff(conn, limit=1)


def test_handoff_cancel_leaves_stores_available(conn: sqlite3.Connection) -> None:
    for seller in ("seller_a", "seller_b"):
        qualify_seller(conn, seller)
    handoff_id = create_store_handoff(conn, limit=1)["handoff"]["id"]

    cancelled = cancel_store_handoff(conn, handoff_id, note="user did not add")
    next_payload = create_store_handoff(conn, limit=2)

    assert cancelled["handoff"]["status"] == "cancelled"
    assert store_status(conn, "seller_a") == "qualified"
    assert next_payload["item_count"] == 2


def test_handoff_cli_create_all_and_confirm(tmp_path) -> None:
    db_path = tmp_path / "friday.sqlite3"
    db = connect(db_path)
    init_db(db)
    for seller in ("seller_a", "seller_b"):
        qualify_seller(db, seller)
    runner = CliRunner()

    create_result = runner.invoke(app, ["handoff", "create", "--db", str(db_path), "--all"])
    assert create_result.exit_code == 0
    created = json.loads(create_result.output)
    assert created["item_count"] == 2

    confirm_result = runner.invoke(
        app,
        ["handoff", "confirm", "--db", str(db_path), "--handoff-id", str(created["handoff"]["id"])],
    )
    assert confirm_result.exit_code == 0
    confirmed = json.loads(confirm_result.output)
    assert confirmed["handoff"]["status"] == "confirmed"
    reopened = connect(db_path)
    assert store_status(reopened, "seller_a") == "manually_added_to_dc"
    assert store_status(reopened, "seller_b") == "manually_added_to_dc"


def test_handoff_report_pending_returns_latest_pending(conn: sqlite3.Connection) -> None:
    qualify_seller(conn, "seller_a")
    handoff_id = create_store_handoff(conn, limit=1)["handoff"]["id"]

    payload = handoff_report(conn, pending=True)

    assert payload["handoff"]["id"] == handoff_id
    assert payload["handoff"]["status"] == "pending"


def test_status_summary_includes_handoff_counts(conn: sqlite3.Connection) -> None:
    qualify_seller(conn, "seller_a")
    create_store_handoff(conn, limit=1)

    summary = status_summary(conn)

    assert summary["store_handoffs"] == {"pending": 1}
