# Friday Architecture Notes

Friday is a local browser-only research system for finding eBay dropshipping seller candidates from Dropship Calendar seed products.

## Components

- Codex skill: `~/.codex/skills/friday/SKILL.md` after install.
- Python CLI: `uv run friday ...` from the installed project folder.
- SQLite database: `data/friday.sqlite3`, created by `uv run friday init-db`.
- Evidence files: `data/evidence/YYYY-MM-DD/run-{RUN_ID}/`.
- Exports: `data/exports/`.

## Workflow Summary

1. Use the Codex browser to inspect Dropship Calendar and eBay.
2. Record every durable decision with the local CLI.
3. Cache eBay search results before deeper seller vetting.
4. Compare seed and candidate listing images visually before opening seller sold pages.
5. Inspect the first 30 sold-result cards for each seller before passing mixed-inventory checks.
6. Record screenshots, sold samples, qualification gates, and assessment results.
7. Finish each run with `uv run friday report run --run-id "$RUN_ID" --json`.

## Safety Rules

- Do not use the eBay API.
- Do not auto-add sellers to Dropship Calendar.
- Do not click destructive or mutating Dropship Calendar controls unless the user explicitly approves the exact action.
- Do not type or submit user credentials.
- If Dropship Calendar login is needed, make the browser visible and ask the user to log in manually.

## Required Gates

- `not_source_store`
- `same_product_match`
- `price_above_amazon_retail`
- `seller_feedback_100_plus`
- `visible_sold_results_100_plus`
- `mixed_non_niche_inventory`
- `catalog_stock_photo_style`
- `no_blocker`

The CLI applies deterministic status rules:

- blocker -> `blocked`
- any failed gate -> `rejected`
- all gates pass -> `qualified`
- otherwise -> `manual_review`

## Useful Commands

```bash
uv run friday init-db
uv run friday status --json
uv run friday checks
uv run friday record run-start --type discovery --target-count 10 --notes "Codex Friday run"
uv run friday search preflight --limit 1
uv run friday report run --run-id "$RUN_ID" --json
```

