#!/usr/bin/env bash
set -euo pipefail

TARGET="${1:-"$HOME/Desktop/friday"}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SOURCE_PROJECT="$PACKAGE_ROOT/friday"
SOURCE_SKILL="$PACKAGE_ROOT/codex-skill/friday/SKILL.md"
SKILL_DIR="$HOME/.codex/skills/friday"
SKILL_OUT="$SKILL_DIR/SKILL.md"

if ! command -v uv >/dev/null 2>&1; then
  echo "uv is required but was not found on PATH."
  echo "Install it with: curl -LsSf https://astral.sh/uv/install.sh | sh"
  exit 1
fi

if [ ! -d "$SOURCE_PROJECT" ]; then
  echo "Missing source project: $SOURCE_PROJECT"
  exit 1
fi

if [ ! -f "$SOURCE_SKILL" ]; then
  echo "Missing skill template: $SOURCE_SKILL"
  exit 1
fi

if [ -e "$TARGET" ]; then
  echo "Refusing to overwrite existing path: $TARGET"
  echo "Choose a new install path, for example:"
  echo "  bash scripts/install_codex_skill.sh \"$HOME/Desktop/friday-fresh\""
  exit 1
fi

mkdir -p "$(dirname "$TARGET")"
cp -R "$SOURCE_PROJECT" "$TARGET"

mkdir -p "$SKILL_DIR"
TARGET_ESCAPED="${TARGET//\\/\\\\}"
TARGET_ESCAPED="${TARGET_ESCAPED//#/\\#}"
sed "s#__FRIDAY_WORKSPACE__#$TARGET_ESCAPED#g" "$SOURCE_SKILL" > "$SKILL_OUT"

cd "$TARGET"
uv run friday init-db
uv run friday checks
uv run pytest

echo
echo "Friday installed successfully."
echo "Project: $TARGET"
echo "Skill: $SKILL_OUT"
echo
echo "Restart Codex if needed, then verify with:"
echo '  $friday status'

