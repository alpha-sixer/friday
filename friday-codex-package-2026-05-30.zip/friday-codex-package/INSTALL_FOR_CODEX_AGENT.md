# Install Friday For Codex

This package contains the Friday local CLI plus a Codex skill that tells the agent how to use it for Dropship Calendar and eBay seller discovery.

## What Is Included

- `friday/`: the Python project containing the `friday` CLI and SQLite schema.
- `codex-skill/friday/SKILL.md`: the Codex skill template.
- `scripts/install_codex_skill.sh`: a non-destructive installer.

## Requirements

- macOS or Linux shell.
- Python 3.9 or newer.
- `uv` installed and available on `PATH`.
- Codex Desktop/App with browser capability available.
- A Dropship Calendar account. The agent must ask the user to log in manually when needed.
- Network access to Dropship Calendar and eBay.

No eBay API key is required. Do not use the eBay API.

If `uv` is not installed, install it first:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Then open a new shell or reload your shell profile so `uv` is on `PATH`.

## Recommended Install

From the folder containing this file, run:

```bash
bash scripts/install_codex_skill.sh "$HOME/Desktop/friday"
```

The installer will:

1. Copy the clean Friday project to the chosen install path.
2. Install the Codex skill at `~/.codex/skills/friday/SKILL.md`.
3. Replace `__FRIDAY_WORKSPACE__` inside the skill with the chosen install path.
4. Initialize the local SQLite database at `data/friday.sqlite3`.
5. Run the CLI gate listing.
6. Run the test suite.

The installer is intentionally non-destructive. If the target folder already exists, it stops and asks you to choose a different path.

## Manual Install

If you do not want to run the installer:

```bash
cp -R friday "$HOME/Desktop/friday"
mkdir -p "$HOME/.codex/skills/friday"
sed "s#__FRIDAY_WORKSPACE__#$HOME/Desktop/friday#g" \
  codex-skill/friday/SKILL.md \
  > "$HOME/.codex/skills/friday/SKILL.md"
cd "$HOME/Desktop/friday"
uv run friday init-db
uv run friday checks
uv run pytest
```

If the install path contains characters that confuse `sed`, ask Codex to do the placeholder replacement with a small Python or Node script instead.

## Verify In Codex

Start or restart Codex so it can load the new skill, then ask:

```text
$friday status
```

The expected first-run state is an initialized database with no meaningful runs or sellers yet.

## Operational Rules

- Use browser-only research for Dropship Calendar and eBay.
- Do not use the eBay API.
- Do not auto-add sellers to Dropship Calendar.
- Do not click destructive or mutating Dropship Calendar controls unless the user explicitly approves that exact action.
- Durable state must be recorded through `uv run friday ...`.
- Qualified sellers still require manual approval or handoff. The tool does not add them to Dropship Calendar by itself.

## Important Files After Install

- Project: `$HOME/Desktop/friday` or the path passed to the installer.
- Database: `<install-path>/data/friday.sqlite3`.
- Evidence screenshots: `<install-path>/data/evidence/`.
- Skill: `$HOME/.codex/skills/friday/SKILL.md`.

